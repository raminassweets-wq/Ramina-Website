(() => {
    'use strict';
    const widget = document.querySelector('[data-chat-widget]');
    if (!widget) return;

    const toggle = widget.querySelector('[data-chat-toggle]');
    const panel = widget.querySelector('[data-chat-panel]');
    const close = widget.querySelector('[data-chat-close]');
    const form = widget.querySelector('[data-chat-form]');
    const input = widget.querySelector('[data-chat-input]');
    const messages = widget.querySelector('[data-chat-messages]');
    const status = widget.querySelector('[data-chat-status]');
    const endpoint = widget.dataset.endpoint;
    let open = false;
    let timer = null;
    let lastSignature = '';

    const senderLabel = sender => sender === 'customer' ? 'You' : sender === 'admin' ? 'Ramina’s team' : 'Ramina Assistant';

    function render(items) {
        const signature = JSON.stringify(items.map(m => [m.id, m.sender, m.message]));
        if (signature === lastSignature) return;
        lastSignature = signature;
        messages.textContent = '';
        if (!items.length) {
            const intro = document.createElement('div');
            intro.className = 'chat-intro';
            intro.textContent = 'Bula! Ask about products, prices, stock, payments, pickup or your order. Every question is also sent to the owner/admin.';
            messages.appendChild(intro);
        } else {
            items.forEach(item => {
                const row = document.createElement('div');
                row.className = `chat-message chat-${item.sender}`;
                const label = document.createElement('strong');
                label.textContent = senderLabel(item.sender);
                const text = document.createElement('p');
                text.textContent = item.message;
                const time = document.createElement('small');
                time.textContent = item.created_at || '';
                row.append(label, text, time);
                messages.appendChild(row);
            });
        }
        messages.scrollTop = messages.scrollHeight;
    }

    async function load() {
        try {
            const response = await fetch(endpoint, {headers: {'Accept': 'application/json'}, credentials: 'same-origin'});
            const data = await response.json();
            if (data.ok) render(data.messages || []);
        } catch (_) {
            status.textContent = 'Unable to refresh chat right now.';
        }
    }

    function setOpen(value) {
        open = value;
        panel.hidden = !open;
        toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
        if (open) {
            load();
            input.focus();
            clearInterval(timer);
            timer = setInterval(load, 8000);
        } else {
            clearInterval(timer);
            timer = null;
            toggle.focus();
        }
    }

    toggle.addEventListener('click', () => setOpen(!open));
    close.addEventListener('click', () => setOpen(false));

    form.addEventListener('submit', async event => {
        event.preventDefault();
        const text = input.value.trim();
        if (!text) return;
        const button = form.querySelector('button[type="submit"]');
        button.disabled = true;
        status.textContent = 'Sending…';
        try {
            const body = new FormData(form);
            const response = await fetch(endpoint, {method: 'POST', body, headers: {'Accept': 'application/json'}, credentials: 'same-origin'});
            const data = await response.json();
            if (!response.ok || !data.ok) throw new Error(data.error || 'Message could not be sent.');
            input.value = '';
            render(data.messages || []);
            status.textContent = 'Sent. The owner/admin can also see your question.';
        } catch (error) {
            status.textContent = error.message || 'Message could not be sent.';
        } finally {
            button.disabled = false;
            input.focus();
        }
    });

    render([]);
})();
