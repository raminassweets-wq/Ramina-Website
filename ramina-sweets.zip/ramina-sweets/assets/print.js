document.addEventListener('click', function (event) {
  const button = event.target.closest('[data-print-receipt]');
  if (!button) return;
  window.print();
});
