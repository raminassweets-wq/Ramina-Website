// Guest ordering and manual M-PAiSA approval tests. Uses an isolated ramina_test database.
const assert=require('node:assert/strict');
const {createRequire}=require('node:module');
const {spawn,spawnSync}=require('node:child_process');
let pw;try{pw=require('playwright')}catch{pw=createRequire('C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/p.js')('playwright')}
const base='http://127.0.0.1:8031/';const cwd=process.cwd();
const env={...process.env,RAMINA_DB_PORT:'3318',RAMINA_DB_NAME:'ramina_test'};
(async()=>{
 const db=spawn('C:/xampp/mysql/bin/mysqld.exe',['--defaults-file='+cwd+'/.runtime/mysql/my.ini','--bind-address=127.0.0.1','--port=3318','--console'],{windowsHide:true,stdio:'ignore'});
 let php,browser;
 try{
  for(let i=0;i<60;i++){const r=spawnSync('C:/xampp/mysql/bin/mysqladmin.exe',['--host=127.0.0.1','--port=3318','--user=root','ping'],{windowsHide:true});if(r.status===0)break;await new Promise(r=>setTimeout(r,200));}
  const upgrade=spawnSync('C:/xampp/php/php.exe',['tests/upgrade-test.php'],{env,encoding:'utf8',windowsHide:true});assert.equal(upgrade.status,0,upgrade.stderr);console.log(upgrade.stdout.trim());
  php=spawn('C:/xampp/php/php.exe',['-d','session.save_path='+cwd+'/.runtime/sessions','-d','error_log='+cwd+'/.runtime/php-errors.log','-S','127.0.0.1:8031','router.php'],{env,windowsHide:true,stdio:'ignore'});
  for(let i=0;i<40;i++){try{if((await fetch(base)).status===200)break;}catch{}await new Promise(r=>setTimeout(r,200));}
  browser=await pw.chromium.launch({headless:true,channel:'msedge'});
  const context=await browser.newContext({javaScriptEnabled:false}),publicContext=await browser.newContext({javaScriptEnabled:false});
  const p=await context.newPage(),publicPage=await publicContext.newPage();
  await publicPage.goto(base+'about.php');assert.equal(await publicPage.getByRole('heading',{level:1}).textContent(),'About Ramina’s');
  const picture=await publicPage.screenshot({clip:{x:0,y:0,width:300,height:200}});
  await publicPage.goto(base);assert.equal(await publicPage.locator('#about').count(),0);assert((await publicPage.getByRole('link',{name:'About Us',exact:true}).first().getAttribute('href')).endsWith('/about.php'));
  const denied=await publicContext.request.post(base+'admin/product-edit.php',{form:{name:'Unauthorized'}});assert(denied.url().includes('login.php'));
  await p.goto(base+'admin/login.php');await p.locator('[name=email]').fill('owner@example.test');await p.locator('[name=password]').fill('OwnerTest-8291');await p.getByRole('button',{name:'Open owner dashboard',exact:true}).click();
  await p.goto(base+'admin/product-edit.php');assert.equal(await p.locator('main input:not([type=hidden]), main textarea, main select').count(),5);
  const name='Photo test '+Date.now();
  await p.locator('[name=name]').fill(name);await p.locator('[name=category]').fill('Picture test category');await p.locator('[name=price]').fill('12.50');await p.locator('[name=description]').fill('A short test description.');
  await p.locator('[name=picture]').setInputFiles({name:'fake.jpg',mimeType:'image/jpeg',buffer:Buffer.from('<?php echo "not an image"; ?>')});await p.getByRole('button',{name:'Save product'}).click();assert.equal(await p.locator('.error').count(),1);
  await p.locator('[name=picture]').setInputFiles({name:'test.png',mimeType:'image/png',buffer:picture});await p.getByRole('button',{name:'Save product'}).click();await p.waitForURL('**/admin/product-stock.php?id=*');assert((await p.locator('main').textContent()).includes('Product saved.'));await p.goto(base+'admin/products.php');
  const row=p.locator('tbody tr').filter({hasText:name});assert((await row.textContent()).includes('Hidden'));const edit=await row.getByRole('link',{name:'Edit',exact:true}).getAttribute('href');const id=new URL(edit,base).searchParams.get('id');
  assert.equal((await publicPage.goto(base+'product-details.php?id='+id)).status(),404);
  await row.getByRole('link',{name:'Set stock & publish'}).click();assert.equal(await p.locator('[name=stock]').inputValue(),'0');await p.locator('[name=stock]').fill('2');await p.locator('[name=active]').check();await p.getByRole('button',{name:'Save stock & details'}).click();
  await p.goto(base+'admin/index.php');await p.locator('tbody tr').filter({hasText:name}).getByRole('link',{name:'Update stock',exact:true}).click();assert(p.url().includes('product-stock.php?id='+id));
  await publicPage.goto(base+'product-details.php?id='+id);assert((await publicPage.locator('main').textContent()).includes('Not provided. Please ask the owner.'));const photo=await publicPage.locator('.product-image img').getAttribute('src');assert.match(photo,/images\/products\/[a-f0-9]{32}\.png$/);const imageResponse=await publicContext.request.get(base+photo.replace(/^\//,''));assert.equal(imageResponse.status(),200);assert(imageResponse.headers()['content-type'].includes('image/png'));
  await p.goto(base+'admin/product-edit.php?id='+id);await p.locator('[name=description]').fill('Updated brief description.');await p.getByRole('button',{name:'Save product'}).click();assert((await p.locator('tbody tr').filter({hasText:name}).textContent()).includes('Published'));
  await publicPage.reload();assert.equal(await publicPage.locator('.product-image img').getAttribute('src'),photo);
  // A stock change in another tab must not be overwritten by an old editor.
  await p.goto(base+'admin/product-edit.php?id='+id);const stockPage=await context.newPage();await stockPage.goto(base+'admin/product-stock.php?id='+id);await stockPage.locator('[name=stock]').fill('3');await stockPage.getByRole('button',{name:'Save stock & details'}).click();await p.getByRole('button',{name:'Save product'}).click();assert((await p.locator('.error').textContent()).includes('changed'));
  await p.goto(base+'admin/product-edit.php?id='+id);await p.setViewportSize({width:390,height:844});assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);await p.screenshot({path:'.runtime/simple-product-editor.png',fullPage:true});
  await publicPage.setViewportSize({width:390,height:844});await publicPage.goto(base+'about.php');assert.equal(await publicPage.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);await publicPage.screenshot({path:'.runtime/about-mobile.png',fullPage:true});
  await p.goto(base+'admin/product-delete.php?id='+id);await p.getByRole('button',{name:'Delete product',exact:true}).click();
  const fresh=spawnSync('C:/xampp/php/php.exe',['tests/fresh-schema.php'],{env,encoding:'utf8',windowsHide:true});assert.equal(fresh.status,0,fresh.stderr);console.log(fresh.stdout.trim());
  console.log('PASS: five-field product form, category creation, fake-image rejection, picture upload/display/retention, hidden zero-stock drafts, separate stock publishing, stale-edit protection, owner access and separate responsive About Us.');
 }finally{if(browser)await browser.close();if(php)php.kill();spawnSync('C:/xampp/mysql/bin/mysqladmin.exe',['--host=127.0.0.1','--port=3318','--user=root','shutdown'],{windowsHide:true});db.kill();}
})().catch(e=>{console.error(e);process.exit(1)});
