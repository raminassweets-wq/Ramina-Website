<?php
if(PHP_SAPI!=='cli')exit(1);
require __DIR__.'/../app/db.php';
if(db()->query('SELECT DATABASE()')->fetchColumn()!=='ramina_test')exit('Use ramina_test only.');
$name='ramina_fresh_test_'.bin2hex(random_bytes(4));
db()->exec("CREATE DATABASE `$name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
db()->exec("USE `$name`");
db()->exec(file_get_contents(__DIR__.'/../database/schema.sql'));
db()->exec(file_get_contents(__DIR__.'/../database/sample-data.sql'));
$column=query("SHOW COLUMNS FROM orders LIKE 'user_id'")->fetch();
if($column['Null']!=='YES' || (int)one('SELECT COUNT(*) n FROM products')['n']!==6)throw new RuntimeException('Fresh schema check failed.');
echo "PASS: new schema and sample data import; guest user IDs nullable; six sample products.\n";
