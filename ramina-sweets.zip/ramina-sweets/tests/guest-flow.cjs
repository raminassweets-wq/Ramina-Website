// Guest ordering and manual M-PAiSA approval tests. Uses an isolated ramina_test database.
const assert=require('node:assert/strict');
const {createRequire}=require('node:module');
const {spawn,spawnSync}=require('node:child_process');
let pw;try{pw=require('playwright')}catch{pw=createRequire('C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/p.js')('playwright')}
const base='http://127.0.0.1:8031/';const cwd=process.cwd();
const env={...process.env,RAMINA_DB_PORT:'3318',RAMINA_DB_NAME:'ramina_test'};
(async()=>{
 const db=spawn('C:/xampp/mysql/bin/mysqld.exe',['--defaults-file='+cwd+'/.runtime/mysql/my.ini','--bind-address=127.0.0.1','--port=3318','--console'],{windowsHide:true,stdio:'ignore'});
 let php,browser;
 try{
  for(let i=0;i<60;i++){const r=spawnSync('C:/xampp/mysql/bin/mysqladmin.exe',['--host=127.0.0.1','--port=3318','--user=root','ping'],{windowsHide:true});if(r.status===0)break;await new Promise(r=>setTimeout(r,200));}
  const upgrade=spawnSync('C:/xampp/php/php.exe',['tests/upgrade-test.php'],{env,encoding:'utf8',windowsHide:true});assert.equal(upgrade.status,0,upgrade.stderr);console.log(upgrade.stdout.trim());
  php=spawn('C:/xampp/php/php.exe',['-d','session.save_path='+cwd+'/.runtime/sessions','-d','error_log='+cwd+'/.runtime/php-errors.log','-S','127.0.0.1:8031','router.php'],{env,windowsHide:true,stdio:'ignore'});
  for(let i=0;i<40;i++){try{if((await fetch(base)).status===200)break;}catch{}await new Promise(r=>setTimeout(r,200));}
  browser=await pw.chromium.launch({headless:true,channel:'msedge'});
  const guest=await browser.newContext({javaScriptEnabled:false}),owner=await browser.newContext({javaScriptEnabled:false}),stranger=await browser.newContext({javaScriptEnabled:false});
  const g=await guest.newPage(),a=await owner.newPage(),s=await stranger.newPage();
  await g.goto(base+'products.php?q=coconut&category=2&min=9&max=11');assert.equal(await g.locator('.product-card').count(),1);
  await g.getByRole('button',{name:'Add to cart',exact:true}).click();await g.goto(base+'checkout.php');
  await g.locator('[name=name]').fill('Guest Test');await g.locator('[name=email]').fill('guest-'+Date.now()+'@example.test');await g.locator('[name=phone]').fill('1234567');await g.locator('[name=collection_date]').fill(new Date(Date.now()+3*86400000).toISOString().slice(0,10));await g.locator('[name=payment_method]').selectOption('M-PAiSA');
  await g.getByText('Optional details',{exact:true}).click();await g.locator('[name=payer_number]').fill('9123456');await g.locator('[name=contact_viber]').check();await g.locator('[name=requested_time]').fill('14:00');
  const payload=await g.locator('main form').evaluate(form=>Object.fromEntries(new FormData(form)));
  for(const bad of [{...payload,phone:''},{...payload,contact_viber:'1',viber_number:'invalid'},{...payload,requested_time:'99:99'}]) {
    const rejected=await guest.request.post(base+'checkout.php',{form:bad});assert((await rejected.text()).includes('class="notice error"'));
  }
  await g.getByRole('button',{name:'Place order',exact:true}).click();await g.waitForURL('**/order.php?id=*');
  const id=new URL(g.url()).searchParams.get('id');const reference=(await g.locator('.payment-reference').textContent()).trim();const code=(await g.locator('code').textContent()).trim();
  assert.match(reference,/^RS-[A-F0-9]{10}$/);assert.match(code,/^[A-F0-9]{16}$/);
  const repeat=await guest.request.post(base+'checkout.php',{form:payload,maxRedirects:0});assert.equal(repeat.status(),303);assert(repeat.headers().location.endsWith('id='+id));
  assert.equal((await s.goto(base+'order.php?id='+id)).status(),404);
  const blocked=await stranger.request.post(base+'order.php?id='+id,{form:{transaction_reference:'FORGED',payer_number:'9999999'}});assert.equal(blocked.status(),404);
  await g.locator('[name=transaction_reference]').fill('MP-'+Date.now());await g.getByRole('button',{name:'Submit payment details'}).click();assert((await g.locator('main').textContent()).includes('Awaiting owner verification'));
  const evidence=await g.locator('form').filter({has:g.locator('[name=transaction_reference]')}).evaluate(f=>Object.fromEntries(new FormData(f)));
  const csrfFail=await guest.request.post(base+'order.php?id='+id,{form:{...evidence,csrf:'wrong'}});assert.equal(csrfFail.status(),403);
  await s.goto(base+'find-order.php');await s.locator('[name=reference]').fill(reference);await s.locator('[name=access_code]').fill('WRONG');await s.getByRole('button',{name:'Open receipt'}).click();assert((await s.locator('.error').textContent()).includes('incorrect'));
  await s.locator('[name=access_code]').fill(code);await s.getByRole('button',{name:'Open receipt'}).click();await s.waitForURL('**/order.php?id='+id);
  await a.goto(base+'admin/login.php');await a.locator('[name=email]').fill('owner@example.test');await a.locator('[name=password]').fill('OwnerTest-8291');await a.getByRole('button',{name:'Open owner dashboard',exact:true}).click();await a.waitForURL('**/admin/index.php');
  await a.goto(base+'admin/orders.php?q='+reference);assert.equal(await a.locator('tbody tr').count(),1);await a.locator('tbody a').click();
  await a.locator('[name=status]').selectOption('Approved');await a.getByRole('button',{name:'Save order update'}).click();assert((await a.locator('.error').textContent()).includes('before approving'));
  await a.locator('[name=status]').selectOption('Approved');await a.locator('[name=payment_status]').selectOption('Paid');await a.locator('[name=reference]').fill('Verified M-PAiSA transaction TEST-'+Date.now());await a.getByRole('button',{name:'Save order update'}).click();assert.equal(await a.locator('.error').count(),0);
  await g.reload();assert((await g.locator('main').textContent()).includes('approved by the owner'));assert((await g.locator('main').textContent()).includes('Paid'));assert.equal(await g.locator('.timeline').count(),0);
  assert((await a.locator('main').textContent()).includes('9123456'));
  await a.locator('[name=confirmed_time]').fill('15:00');assert.equal(await a.locator('[name=pickup_location]').count(),0);await a.getByRole('button',{name:'Confirm collection',exact:true}).click();assert.equal(await a.locator('.error').count(),0);
  assert((await a.locator('.confirmation-message').inputValue()).includes('15:00'));assert((await a.locator('.confirmation-message').inputValue()).includes('Payment received'));
  const originalMessage=await a.locator('form').filter({has:a.locator('[name=sent_confirmed]')}).evaluate(f=>Object.fromEntries(new FormData(f)));
  await a.locator('[name=sent_confirmed]').check();await a.getByRole('button',{name:'Mark Viber confirmation sent'}).click();assert((await a.locator('main').textContent()).includes('Recorded as sent'));
  await a.locator('[name=confirmed_time]').fill('16:00');await a.getByRole('button',{name:'Confirm collection',exact:true}).click();assert.equal(await a.getByRole('button',{name:'Mark Viber confirmation sent'}).count(),1);
  const staleMessage=await owner.request.post(base+'admin/order.php?id='+id,{form:{...originalMessage,sent_confirmed:'1'}});assert((await staleMessage.text()).includes('details changed'));
  await g.reload();assert((await g.locator('main').textContent()).includes('16:00'));assert.equal(await g.locator('[name=transaction_reference]').count(),0);
  const stale=await guest.request.post(base+'order.php?id='+id,{form:evidence});assert((await stale.text()).includes('can no longer be changed'));
  await a.setViewportSize({width:390,height:844});assert.equal(await a.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);await a.screenshot({path:'.runtime/owner-collection-mobile.png',fullPage:true});await a.setViewportSize({width:1280,height:900});
  await a.locator('[name=status]').selectOption('Completed');await a.getByRole('button',{name:'Save order update'}).click();await g.reload();assert((await g.locator('main').textContent()).includes('purchase is completed'));
  // Removed routes must not remain callable.
  for(const route of ['celebration.php','admin/requests.php','admin/report-download.php'])assert.equal((await owner.request.get(base+route)).status(),404);
  await g.setViewportSize({width:390,height:844});assert.equal(await g.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
  await g.screenshot({path:'.runtime/guest-receipt.png',fullPage:true});
  // Signed-in purchases still qualify for history/reviews.
  const c=await guest.newPage();await c.goto(base+'register.php');const email='account-'+Date.now()+'@example.test';await c.locator('[name=name]').fill('Account Test');await c.locator('[name=email]').fill(email);await c.locator('[name=password]').fill('CustomerTest-912');await c.locator('[name=confirm_password]').fill('CustomerTest-912');await c.getByRole('button',{name:'Register',exact:true}).click();
  await c.goto(base+'products.php?q=coconut');await c.getByRole('button',{name:'Add to cart',exact:true}).click();await c.goto(base+'checkout.php');await c.locator('[name=phone]').fill('1234567');await c.locator('[name=collection_date]').fill(new Date(Date.now()+3*86400000).toISOString().slice(0,10));await c.locator('[name=viber_number]').fill('+679 9234567');await c.locator('[name=contact_preference]').selectOption('Viber');await c.locator('[name=save_details]').check();await c.getByRole('button',{name:'Place order',exact:true}).click();await c.waitForURL('**/order.php?id=*');const accountId=new URL(c.url()).searchParams.get('id');
  await a.goto(base+'admin/order.php?id='+accountId);await a.locator('[name=status]').selectOption('Approved');await a.getByRole('button',{name:'Save order update'}).click();assert.equal(await a.locator('.error').count(),0);await a.locator('[name=status]').selectOption('Completed');await a.locator('[name=payment_status]').selectOption('Paid');await a.locator('[name=reference]').fill('Cash received');await a.getByRole('button',{name:'Save order update'}).click();
  await c.goto(base+'orders.php');assert((await c.locator('main').textContent()).includes('RS-'));await c.goto(base+'review.php?product_id=3');await c.locator('[name=rating]').selectOption('5');await c.locator('[name=comment]').fill('Good sweets');await c.getByRole('button',{name:'Save review'}).click();assert(c.url().includes('orders.php'));
  await c.goto(base+'account.php');assert.equal(await c.locator('[name=viber_number]').inputValue(),'+6799234567');assert.equal(await c.locator('[name=contact_preference]').inputValue(),'Viber');
  await c.goto(base+'products.php?q=coconut');await c.getByRole('button',{name:'Add to cart',exact:true}).click();await c.goto(base+'checkout.php');assert.equal(await c.locator('[name=viber_number]').inputValue(),'+6799234567');assert.equal(await c.locator('[name=phone]').inputValue(),'1234567');
  await c.setViewportSize({width:390,height:844});assert.equal(await c.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);await c.screenshot({path:'.runtime/payment-checkout-mobile.png',fullPage:true});
  const fresh=spawnSync('C:/xampp/php/php.exe',['tests/fresh-schema.php'],{env,encoding:'utf8',windowsHide:true});assert.equal(fresh.status,0,fresh.stderr);console.log(fresh.stdout.trim());
  const race=spawnSync('C:/xampp/php/php.exe',['tests/concurrency.php'],{env,encoding:'utf8',windowsHide:true});assert.equal(race.status,0,race.stderr);console.log(race.stdout.trim());
  console.log('PASS: guest checkout, unique reference/private code, duplicate protection, private receipt lookup, manual payment-gated approval, completion, account history/reviews, removed routes, customer payment evidence, confirmed collection, manual Viber recording/reset, saved checkout details and mobile layout.');
 }finally{if(browser)await browser.close();if(php)php.kill();spawnSync('C:/xampp/mysql/bin/mysqladmin.exe',['--host=127.0.0.1','--port=3318','--user=root','shutdown'],{windowsHide:true});db.kill();}
})().catch(e=>{console.error(e);process.exit(1)});
