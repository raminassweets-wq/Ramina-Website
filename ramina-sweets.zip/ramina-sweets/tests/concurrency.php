<?php
if (PHP_SAPI !== 'cli' || getenv('RAMINA_DB_NAME') !== 'ramina_test') exit(1);
require __DIR__.'/../app/bootstrap.php';
if (db()->query('SELECT DATABASE()')->fetchColumn() !== 'ramina_test') exit('Selected database is not ramina_test.');
$stamp=bin2hex(random_bytes(5));
query("INSERT INTO products(category_id,name,description,pack_size,ingredients,allergens,price_cents,stock) VALUES(1,?,'Concurrency test','One pack','Sample','Unverified',100,1)",['Concurrency '.$stamp]);$productId=(int)db()->lastInsertId();
$ids=[];for($i=0;$i<2;$i++){query('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)',['Concurrency tester',"concurrent-$stamp-$i@example.test",password_hash(bin2hex(random_bytes(16)),PASSWORD_DEFAULT)]);$ids[]=(int)db()->lastInsertId();}
$barrier=__DIR__.'/../.runtime/barrier-'.$stamp;
$processes=[];
foreach($ids as $id){$command=[PHP_BINARY,__DIR__.'/concurrent-worker.php',(string)$productId,(string)$id,bin2hex(random_bytes(32)),$barrier];$proc=proc_open($command,[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes);fclose($pipes[0]);$processes[]=[$proc,$pipes];}
$success=0;
foreach($processes as [$proc,$pipes]){$text=stream_get_contents($pipes[1]);$err=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);$exit=proc_close($proc);$result=json_decode($text,true);if($exit!==0||!is_array($result))throw new RuntimeException('Worker failed: '.$err.' '.$text);if($result['success'])$success++;}
$stock=one('SELECT stock FROM products WHERE id=?',[$productId]);$items=one('SELECT COUNT(*) total FROM order_items WHERE product_id=?',[$productId]);
if($success!==1 || (int)$stock['stock']!==0 || (int)$items['total']!==1)throw new RuntimeException('Concurrent oversell protection failed.');
query('UPDATE products SET active=0,deleted_at=NOW() WHERE id=?',[$productId]);
echo "PASS: two concurrent customers competed for one pack; exactly one order succeeded, stock is zero, and no partial order was saved for the other customer.\n";
