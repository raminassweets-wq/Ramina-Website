<?php
// A separate PHP process tries to reserve one unit. Only used with the isolated test database.
if (PHP_SAPI !== 'cli' || getenv('RAMINA_DB_NAME') !== 'ramina_test') exit(1);
require __DIR__.'/../app/bootstrap.php';
if (db()->query('SELECT DATABASE()')->fetchColumn() !== 'ramina_test') exit('Selected database is not ramina_test.');
$id=(int)$argv[1];$userId=(int)$argv[2];$key=$argv[3];
$_SESSION=['cart'=>[$id=>1],'checkout_key'=>$key];
try{
    $rows=cart_rows();
    // Synchronize both workers so each sees the product before either submits.
    $barrier=$argv[4];file_put_contents($barrier.'.'.$userId,'ready');
    $until=microtime(true)+10;while(count(glob($barrier.'.*'))<2 && microtime(true)<$until)usleep(10000);
    $testUser=one('SELECT * FROM users WHERE id=?',[$userId]);$testUser['phone']='1234567';
    $order=place_order($testUser,$key,cart_fingerprint($rows),date('Y-m-d',strtotime('+2 days')),'Concurrency test','Cash on collection');
    echo json_encode(['success'=>true,'order'=>$order]);
}catch(DomainException $e){echo json_encode(['success'=>false,'message'=>$e->getMessage()]);}
