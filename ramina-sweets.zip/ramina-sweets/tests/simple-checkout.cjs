// Isolated, disposable database on the local MySQL server; never places real orders.
const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const {spawn,spawnSync}=require('node:child_process'),{randomBytes}=require('node:crypto'),{createRequire}=require('node:module');
const pw=createRequire('C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/p.js')('playwright');
const database='ramina_checkout_test_'+randomBytes(6).toString('hex');
const env={...process.env,RAMINA_DB_NAME:database},base='http://127.0.0.1:8032/';
function sql(code,setup=false){const r=spawnSync('C:/xampp/php/php.exe',[],{input:"<?php require 'app/db.php'; "+code,env:setup?process.env:env,encoding:'utf8',windowsHide:true});if(r.status!==0)throw new Error(r.stderr);return r.stdout;}
(async()=>{
 let server,browser;const sessions=fs.mkdtempSync(path.join(os.tmpdir(),'ramina-checkout-'));
 try {
  sql(`db()->exec('CREATE DATABASE ${database}');db()->exec('USE ${database}');db()->exec(file_get_contents('database/schema.sql'));db()->exec(file_get_contents('database/sample-data.sql'));`,true);
  server=spawn('C:/xampp/php/php.exe',['-d','session.save_path='+sessions,'-S','127.0.0.1:8032','router.php'],{env,windowsHide:true,stdio:'ignore'});
  for(let i=0;i<30;i++){try{if((await fetch(base)).ok)break;}catch{}await new Promise(r=>setTimeout(r,200));}
  browser=await pw.chromium.launch({headless:true,channel:'msedge'});
  for(const method of ['Cash on collection','M-PAiSA']){
   const context=await browser.newContext({javaScriptEnabled:false,viewport:{width:390,height:844}}),p=await context.newPage();
   await p.goto(base+'products.php');await p.getByRole('button',{name:'Add to cart',exact:true}).first().click();await p.goto(base+'checkout.php');
   assert.equal(await p.locator('[name=email]').count(),0);assert.equal(await p.locator('main input[required],main select[required]').count(),4);
   assert.equal(await p.locator('main details').getAttribute('open'),null);
   await p.locator('[name=name]').fill('Guest test');await p.locator('[name=phone]').fill('9123456');await p.locator('[name=collection_date]').fill(new Date(Date.now()+3*86400000).toISOString().slice(0,10));await p.locator('[name=payment_method]').selectOption(method);
   if(method==='M-PAiSA')await p.locator('[name=contact_viber]').check();
   const payload=await p.locator('main form').evaluate(f=>Object.fromEntries(new FormData(f)));
   assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
   assert.equal(await p.locator('.footer-social a').count(),4);assert((await p.locator('.footer-social').textContent()).includes('demo'));
   await p.getByRole('button',{name:'Place order',exact:true}).click();await p.waitForURL('**/order.php?id=*');
   const id=Number(new URL(p.url()).searchParams.get('id'));
   const row=JSON.parse(sql(`echo json_encode(one('SELECT o.customer_email,o.customer_phone,o.viber_number,o.contact_preference,p.payer_number,p.status FROM orders o JOIN payments p ON p.order_id=o.id WHERE o.id=?',[${id}]));`));
   assert.equal(row.customer_email,'');assert.equal(row.status,'Unpaid');assert.equal(row.contact_preference,method==='M-PAiSA'?'Viber':'Phone');assert.equal(row.viber_number,method==='M-PAiSA'?'9123456':'');assert.equal(row.payer_number,method==='M-PAiSA'?'9123456':'');
   const repeat=await context.request.post(base+'checkout.php',{form:payload,maxRedirects:0});assert.equal(repeat.status(),303);assert(repeat.headers().location.endsWith('id='+id));
   await context.close();
  }
  console.log('PASS: four required guest fields, no guest email, optional details collapsed, cash/M-PAiSA checkout, explicit Viber consent, payer default, unpaid status, duplicate protection, mobile layout and four labelled demo social links. No real orders placed.');
 }finally{
  if(browser)await browser.close();if(server){server.kill();await new Promise(r=>server.once('exit',r));}
  if(/^ramina_checkout_test_[a-f0-9]{12}$/.test(database))sql(`db()->exec('DROP DATABASE IF EXISTS ${database}');`,true);
  for(const file of fs.readdirSync(sessions))fs.unlinkSync(path.join(sessions,file));fs.rmdirSync(sessions);
 }
})().catch(e=>{console.error(e);process.exit(1)});
