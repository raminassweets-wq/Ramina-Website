// Explicit local acceptance test: adds four requested sample products, no orders.
// A random temporary owner account is removed at the end; real accounts are unchanged.
const assert=require('node:assert/strict');
const {spawnSync}=require('node:child_process');
const {randomBytes}=require('node:crypto');
const {createRequire}=require('node:module');
const pw=createRequire('C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/p.js')('playwright');
function php(code) {
 const r=spawnSync('C:/xampp/php/php.exe',[],{input:"<?php require 'C:/xampp/htdocs/ramina-sweets/app/db.php'; if(one('SELECT DATABASE() db')['db']!=='ramina_sweets')exit(1); "+code,encoding:'utf8',windowsHide:true});
 if(r.status!==0)throw new Error('Local database test setup failed.');
 return r.stdout;
}
(async()=>{
 const credentials={email:'product-check-'+randomBytes(8).toString('hex')+'@example.test',password:randomBytes(24).toString('hex')};
 const encoded=Buffer.from(JSON.stringify(credentials)).toString('base64');
 const id=Number(php(`$c=json_decode(base64_decode('${encoded}'),true);query("INSERT INTO users(name,email,password_hash,role) VALUES ('Temporary product check',?,?,'admin')",[$c['email'],password_hash($c['password'],PASSWORD_DEFAULT)]);echo db()->lastInsertId();`));
 assert(id>0);let browser;
 const before=php("echo json_encode(query(\"SELECT id,stock FROM products WHERE name NOT LIKE 'Sample %' ORDER BY id\")->fetchAll());");
 try {
  browser=await pw.chromium.launch({headless:true,channel:'msedge'});
  const owner=await browser.newContext({javaScriptEnabled:false}),guest=await browser.newContext({javaScriptEnabled:false});
  const p=await owner.newPage(),g=await guest.newPage(),base='http://localhost/ramina-sweets/';
  await g.goto(base+'images/sweets.svg');const picture=await g.locator('svg').screenshot();
  await p.goto(base+'admin/login.php');await p.locator('[name=email]').fill(credentials.email);await p.locator('[name=password]').fill(credentials.password);await p.getByRole('button',{name:'Open owner dashboard',exact:true}).click();await p.waitForURL('**/admin/index.php');
  await p.getByRole('link',{name:'Add product',exact:true}).last().click();
  assert.equal(await p.locator('main input:not([type=hidden]),main textarea,main select').count(),5);
  // Validate the same upload control before using it to add the sample catalogue.
  await p.locator('[name=name]').fill('Rejected upload test');await p.locator('[name=category]').fill('Sample sweets');await p.locator('[name=price]').fill('10');await p.locator('[name=description]').fill('This invalid upload must not save a product.');
  await p.locator('[name=picture]').setInputFiles({name:'bad.jpg',mimeType:'image/jpeg',buffer:Buffer.from('not a real image')});await p.getByRole('button',{name:'Save product'}).click();assert.equal(await p.locator('.error').count(),1);
  // Oversized forms should show a useful message, not a misleading CSRF-expired error.
  const oversized=await owner.request.post(base+'admin/product-edit.php',{multipart:{picture:{name:'too-large.png',mimeType:'image/png',buffer:Buffer.alloc(9*1024*1024)}}});assert((await oversized.text()).includes('picture is too large'));
  let added=0;
  for(const [name,category,price] of [['Sample Coconut Barfi','Sample sweets','10.00'],['Sample Besan Laddoo','Sample sweets','12.00'],['Sample Chocolate Barfi','Sample sweets','15.00'],['Sample Sweet Gift Box','Sample gift boxes','25.00']]) {
   const exists=Number(php(`echo one('SELECT COUNT(*) n FROM products WHERE name=? AND deleted_at IS NULL',[${JSON.stringify(name)}])['n'];`));
   if(exists)continue;
   await p.goto(base+'admin/product-edit.php');await p.locator('[name=name]').fill(name);await p.locator('[name=category]').fill(category);await p.locator('[name=price]').fill(price);await p.locator('[name=description]').fill('Sample product for trying the shop. Picture, price and availability are demonstration data; replace them with your verified product details before taking real orders.');
   await p.locator('[name=picture]').setInputFiles({name:'sample-sweets.png',mimeType:'image/png',buffer:picture});await p.getByRole('button',{name:'Save product'}).click();await p.waitForURL('**/admin/product-stock.php?id=*');
   const productId=new URL(p.url()).searchParams.get('id');
   await p.locator('[name=stock]').fill('10');await p.locator('[name=active]').check();await p.getByRole('button',{name:'Save stock & details'}).click();await p.waitForURL('**/admin/products.php');
   await g.goto(base+'product-details.php?id='+productId);assert((await g.locator('main').textContent()).includes(name));assert(await g.getByRole('button',{name:'Add to cart',exact:true}).isEnabled());assert(await g.locator('.product-image img').evaluate(img=>img.complete && img.naturalWidth>0));await g.getByRole('button',{name:'Add to cart',exact:true}).click();added++;
  }
  await g.goto(base+'products.php');const cards=g.locator('.product-card');assert(await cards.count()>=4);assert(await g.locator('.product-image img').evaluateAll(images=>images.every(i=>i.complete && i.naturalWidth>0)));
  if(added){await g.goto(base+'checkout.php');assert.equal(await g.getByRole('button',{name:'Place order',exact:true}).count(),1);}
  await p.getByRole('button',{name:'Logout',exact:true}).click();
  assert.equal(php("echo json_encode(query(\"SELECT id,stock FROM products WHERE name NOT LIKE 'Sample %' ORDER BY id\")->fetchAll());"),before);
  console.log('PASS: actual XAMPP owner login, Add Product link, five fields, invalid/oversized upload handling, photo upload, stock/publishing, visible images, cart and checkout. Added '+added+' sample products with 10 units each. No orders placed; existing stock unchanged.');
 } finally {
  if(browser)await browser.close();
  php(`query("DELETE FROM users WHERE id=? AND name='Temporary product check'",[${id}]);`);
 }
})().catch(e=>{console.error(e);process.exit(1)});
