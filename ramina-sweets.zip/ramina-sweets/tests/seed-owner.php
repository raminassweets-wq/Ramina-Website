<?php
if (PHP_SAPI !== 'cli' || getenv('RAMINA_DB_NAME') !== 'ramina_test') exit('Test database required.');
require __DIR__.'/../app/db.php';
if (db()->query('SELECT DATABASE()')->fetchColumn() !== 'ramina_test') exit('Selected database is not ramina_test.');
query("INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,'admin')",['Test Owner','owner@example.test',password_hash('OwnerTest-8291',PASSWORD_DEFAULT)]);
echo "Isolated test owner created.\n";
