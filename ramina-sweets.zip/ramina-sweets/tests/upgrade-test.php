<?php
// Isolated development database only; never changes an existing business database.
if(PHP_SAPI!=='cli')exit(1);
require __DIR__.'/../app/db.php';
if(db()->query('SELECT DATABASE()')->fetchColumn()!=='ramina_test')exit('Use ramina_test only.');
if(!query("SHOW COLUMNS FROM orders LIKE 'public_reference'")->fetch()){
    $sql=file_get_contents(__DIR__.'/../database/upgrade-guest-orders.sql');
    db()->exec($sql);
    echo "Existing schema migrated; old orders retained.\n";
}else echo "Guest-order schema already installed.\n";

if(!query("SHOW COLUMNS FROM orders LIKE 'confirmed_date'")->fetch()) {
    db()->exec(file_get_contents(__DIR__.'/../database/upgrade-payment-collection.sql'));
    echo "Payment/contact and collection upgrade installed.\n";
}

if(!query("SHOW COLUMNS FROM products LIKE 'image_path'")->fetch()) {
    db()->exec(file_get_contents(__DIR__.'/../database/upgrade-product-pictures.sql'));
    echo "Product picture upgrade installed.\n";
}

if(!query("SHOW COLUMNS FROM users LIKE 'account_status'")->fetch()) {
    db()->exec(file_get_contents(__DIR__.'/../database/upgrade-v1.4-modern.sql'));
    echo "v1.4 account/email/payment/reporting upgrade installed.
";
}

if(!query("SHOW TABLES LIKE 'email_delivery_log'")->fetch()) {
    db()->exec(file_get_contents(__DIR__.'/../database/upgrade-v1.5-premium.sql'));
    echo "v1.5 premium/email-log upgrade installed.\n";
}
