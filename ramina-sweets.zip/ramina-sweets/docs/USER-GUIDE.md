# Owner and customer guide

## Customers

Customers can browse without an account. Accounts add purchase history, saved contact details and verified-purchase reviews. Guests receive a public order reference plus a private access code; both are required to reopen a guest receipt.

Customer login: `/login.php`. Password recovery: `/forgot-password.php`. Purchase history: `/orders.php`. Support: `/help.php` or the floating chat button.

## Owner

Owner login: `/admin/login.php`. It uses a separate session cookie, so an owner can remain logged in while a customer account is open in another tab in the same browser.

- **Dashboard:** current orders, paid value, customers, unread messages and low stock.
- **Products & stock:** add/edit products, upload photos, set stock/low-stock thresholds, publish/hide and soft-delete.
- **Orders & payments:** verify manual payments, approve/cancel/complete orders, confirm collection, refund provider-paid cancelled online orders.
- **Customers:** search accounts, edit contact details and activate/deactivate access while preserving historical orders/reviews.
- **Sales reports:** filter by date and export CSV.
- **Customer messages:** view chatbot questions and send human replies.
- **System & email:** business details/social links, email delivery health, retry queue, test email and payment/system status.

## Payment rules

A customer-entered bank/M-PAiSA transaction reference is evidence only; the owner verifies the actual received money before marking it Paid. Provider-controlled online payments cannot be manually changed to Paid.

## Email rules

The website attempts transactional delivery immediately. If the external mail service is unavailable, the message is queued rather than losing the order. Owner → System & email shows delivery attempts and retry status.
