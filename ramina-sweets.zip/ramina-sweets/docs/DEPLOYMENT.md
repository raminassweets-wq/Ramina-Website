# Deployment notes

Ramina’s Sweets 2.0 auto-detects its URL/path and uses Fiji time. For a normal XAMPP project under `htdocs/ramina-sweets`, no application URL edit is required.

On live hosting, keep `app/`, `database/`, `storage/` and `tools/` private. The bundled Apache `.htaccess` files deny direct access. If the host uses Nginx or another server, reproduce those deny rules in its configuration.

Use HTTPS in production. Keep the database private, use a dedicated restricted database user, back up the database plus `images/products/`, and test restoring those backups.

The application automatically installs on an empty configured database. Database server credentials themselves are supplied by the hosting platform; they cannot be guessed by application code.

For email, use the hosting mail service or an authorised SMTP credential. For Gmail SMTP, use a Google App Password/OAuth rather than an ordinary account password. Failed transactional messages remain in the protected email queue for retry.

For real online payment, obtain merchant credentials from the chosen provider and test sandbox end-to-end before live mode. The local payment simulator never activates on a public hostname.
