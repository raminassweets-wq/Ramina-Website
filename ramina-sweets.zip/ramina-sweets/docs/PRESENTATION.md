# Presentation guide — v1.5

## Introduction

“Ramina’s Sweets is a PHP/MySQL e-commerce and business-management website. Customers can order with or without an account, receive email receipts, recover passwords, review completed purchases and use customer support. The owner manages products, stock, customers, orders and reports. Manual payment methods remain owner-verified, while configured online payments are verified automatically by the payment provider.”

## Main features to demonstrate

| Feature | What to explain |
| --- | --- |
| Accounts | Password hashing, secure sessions, email verification, password reset and session invalidation after password changes. |
| Catalogue/cart | Search/filter, current database prices, session quantities and stock checks. |
| Checkout | Guest or account checkout; email receipt; atomic stock reservation; duplicate-submission protection. |
| Private receipts | Public order reference plus a separate private guest code. |
| Email | Order receipt, payment receipt, collection/status updates and receipt resend. |
| Online payment | TEST MODE locally; PayPal Orders v2 adapter for sandbox/live credentials. Payment becomes Paid only after provider confirmation. |
| M-PAiSA / bank | Customer submits evidence; owner independently checks funds before marking Paid. |
| Reviews | One editable review per customer/product after a completed account purchase. |
| Chatbot | Rule-based instant help plus saved questions and owner replies. |
| Owner | Products, stock, orders, customers, messages, reports and CSV export. |
| Reports | Paid/refunded/net totals and product quantities for a selected date range. |

## Suggested demo

1. Register a customer and show the generated verification email in `storage/mail` (local test mode).
2. Add a product to cart and place an order with **Pay online (TEST MODE)**.
3. Show the emailed receipt and private guest code if using guest checkout.
4. Complete the test payment and refresh the receipt to show **Paid** plus the automatic payment receipt email.
5. Log in as owner, approve the paid order and confirm collection. Show the customer update email.
6. Complete the order, then leave a product review directly under the product.
7. Show **Reviews**, **Customers**, **Sales reports**, and **Customer messages**.
8. Demonstrate **Forgot password** using the generated reset email.

## Payment point to explain

The localhost TEST MODE moves no money. It exists to prove the website workflow. For real processing, PayPal merchant credentials/webhook configuration are required. Card/PIN/CVV data is never collected by this application. M-PAiSA and bank transfer remain manual unless the business later receives an API integration from those providers.

## Questions to prepare for

- **What prevents duplicate checkout?** A unique submission key returns the existing order instead of reserving stock twice.
- **What prevents overselling?** Checkout locks product rows inside a database transaction before decrementing stock.
- **Why can’t the owner manually mark an online payment Paid?** The provider controls that state; this prevents forged “success” screens from becoming settlements.
- **How are PayPal webhooks protected?** The server verifies the PayPal signature and deduplicates provider event IDs.
- **How are password reset links protected?** A random token is emailed, only its hash is stored, it expires after 60 minutes and can be used once.
- **What happens after password reset?** The account session version increases, invalidating older sessions.
- **How are guest receipts protected?** The public order reference is not enough; a separate private random code is required.
- **What happens on cancellation?** Reserved stock is restored once. Provider-paid online orders use the provider refund action before the site records Refunded.
