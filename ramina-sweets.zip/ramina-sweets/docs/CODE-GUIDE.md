# Code guide — Ramina’s Sweets v1.5

| Area | Main files |
| --- | --- |
| Boot/session/security | `app/bootstrap.php`, `app/db.php`, `app/config.php` |
| Storefront/layout | `index.php`, `products.php`, `product-details.php`, `app/layout.php`, `style.css` |
| Accounts | `register.php`, `login.php`, `account.php`, `forgot-password.php`, `reset-password.php`, `verify-email.php`; owner login uses `admin/login.php` with a separate session cookie |
| Ordering | `cart.php`, `checkout.php`, `order.php`, `orders.php`, `app/orders.php` |
| Collection/manual payment evidence | `app/collection.php`, `admin/order.php` |
| Transactional email | `app/mail.php` |
| Online payment | `app/payments.php`, `payment-start.php`, `payment-return.php`, `payment-webhook.php`, `payment-demo.php` |
| Reviews | `review.php`, `reviews.php`, product review area |
| Chatbot | `app/chat.php`, `api/chat.php`, `assets/chat.js`, `admin/messages.php`, `admin/chat.php` |
| Owner products/stock | `admin/products.php`, `admin/product-edit.php`, `admin/product-stock.php` |
| Owner customers | `admin/customers.php`, `admin/customer-edit.php` |
| Reports/CSV | `admin/reports.php`, `admin/report-export.php` |
| Database | `database/schema.sql`, additive upgrade SQL files |

Keep payment/email credentials in `app/config.local.php` or environment variables. Do not hard-code secrets into PHP pages or JavaScript.
