# Testing — Ramina’s Sweets v1.5

## Automated checks included

- `php -l` should pass for every PHP source file.
- `node --check assets/chat.js` and `node --check assets/print.js` should pass.
- `tests/fresh-schema.php` validates fresh schema/sample installation when run against the isolated `ramina_test` database.
- `tests/upgrade-test.php` applies legacy upgrades followed by the v1.4 and v1.5 upgrades only when required.
- Existing Playwright flows cover guest/account ordering, receipt privacy, manual payment gating, collection, review eligibility, mobile layout and inventory concurrency.

## v1.5 acceptance scenarios


### Separate customer / owner sessions
1. Sign in as a customer at `login.php`.
2. In another tab, sign in as the owner at `admin/login.php`.
3. Confirm both remain signed in at the same time.
4. Log out from the owner dashboard and confirm the customer account is still signed in.
5. Sign the owner back in, then log the customer out and confirm the owner dashboard remains signed in.

### Accounts
1. Register a customer and confirm a verification email is produced.
2. Verify the email; the account should show verified status.
3. Request a password reset for both a valid and invalid email. The public response must be the same.
4. Use the valid one-time link, reset the password and confirm it cannot be reused.
5. Confirm an older authenticated session is invalidated.
6. Deactivate a customer from Owner → Customers and confirm subsequent authenticated requests are rejected while historical orders/reviews remain.

### Email
1. In `log` mode, place an order and inspect the newest `.eml` in `storage/mail`.
2. Confirm the receipt has the order reference, items, quantities and FJD total.
3. Guest receipt email must contain the private access code; the public order reference alone must not unlock the receipt.
4. Change order status / collection details and confirm update emails are generated.
5. Use “Email receipt again”; rapid repeat requests should be throttled.
6. Configure SMTP and run `tools/test-email.php` before claiming live delivery.

### Local online-payment test
1. Choose Online payment on localhost.
2. Confirm the receipt remains Unpaid before the test provider completes.
3. Complete the TEST MODE payment.
4. Confirm `payment_attempts.status=Succeeded`, `payments.status=Paid`, a capture reference is saved, an audit event exists and a payment receipt email is generated.
5. Repeat/refresh the success flow and confirm no second payment/receipt is created.
6. Owner can approve the now-Paid order but cannot manually change the provider-controlled payment status.
7. Cancel the paid order, issue the online refund and confirm Refunded only after the provider action completes.

### PayPal sandbox
1. Create payment and verify customer is redirected to PayPal’s approval URL.
2. Approve with a sandbox buyer.
3. Return to the site; server-side capture must validate amount/currency before Paid.
4. Send/receive `PAYMENT.CAPTURE.COMPLETED` and verify signature before processing.
5. Replay the same webhook event ID; it must not duplicate settlement.
6. Test wrong amount/currency, invalid signature, abandoned payment, cancelled local order and late provider event.
7. Test a full refund for a cancelled provider-paid order.

### Orders/inventory
- Duplicate checkout submission must return the existing order and not reserve stock twice.
- Two buyers competing for the last unit must never produce negative stock.
- Cancellation restores reserved stock once.
- Completed order requires Paid.
- M-PAiSA/bank customer references remain unverified until the owner checks external funds.

### Reports
- Date filters must match CSV export.
- Paid/refunded totals must not be multiplied by item joins.
- CSV must neutralise values beginning with `=`, `+`, `-` or `@`.

## Production-only checks

Before claiming production readiness, repeat authentication, reset-email delivery, payment capture/refund, webhook delivery, backups/restores, receipt privacy and concurrent stock tests on the actual HTTPS host with real service configuration. Local TEST MODE does not prove a real merchant account is configured.
