# Ramina’s Sweets v1.5 — XAMPP, email and payment setup

## 1. Install/start XAMPP

Install XAMPP with Apache, PHP and MySQL/MariaDB. Open the XAMPP Control Panel and start **Apache** and **MySQL**.

## 2. Put the website in htdocs

Extract the project so this file exists:

`C:\xampp\htdocs\ramina-sweets\index.php`

Do not create a second nested `ramina-sweets\ramina-sweets` folder.

## 3. Database — new installation

Open `http://localhost/phpmyadmin`, create database `ramina_sweets` using `utf8mb4_unicode_ci`, then import in this order:

1. `database/schema.sql`
2. `database/sample-data.sql`

Or from the project folder use the CLI installer after creating the empty database:

```powershell
C:\xampp\php\php.exe tools\install.php
```

Use phpMyAdmin imports **or** the installer, not both.

## 4. Database — upgrade an existing v1.3 installation

Back up the database first. Import:

`database/upgrade-v1.5-modern.sql`

Run it once only. It adds account status/session versioning, password reset/email-verification records, payment attempts/webhook events, online payment method support and account auditing while preserving existing accounts/orders/reviews/stock.

Do not import `schema.sql` or `sample-data.sql` over an existing site.

## 5. Create the owner

```powershell
cd C:\xampp\htdocs\ramina-sweets
C:\xampp\php\php.exe tools\create-admin.php
```

Enter owner name, email and a password of at least eight characters.

## 6. Run the website

Open:

`http://localhost/ramina-sweets/`

Owner login uses the separate `admin/login.php` page. Customer and owner sessions use different cookies, so both can remain signed in in the same browser.

## 7. Check the installation

```powershell
C:\xampp\php\php.exe tools\system-check.php
```

It checks the database connection, the new v1.5 tables, current email transport and current online-payment mode.

## 8. Email — local test mode

By default `mail_transport` is `log`. The website still generates the real email contents, but saves them to:

`storage\mail`

This lets you test:

- account verification
- forgot/reset password
- order confirmation
- guest private receipt code email
- payment receipt
- order-status email
- collection confirmation
- receipt resend

Open the newest `.eml` file in a mail client/text editor and use its verification/reset links.

## 9. Email — real SMTP delivery

Copy:

`app\config.example.php`

to:

`app\config.local.php`

Then fill in your SMTP provider details. Example structure:

```php
return [
    'app_url' => 'http://localhost/ramina-sweets',
    'mail_transport' => 'smtp',
    'mail_from_address' => 'orders@yourdomain.com',
    'mail_from_name' => 'Ramina’s Sweets',
    'smtp_host' => 'smtp.yourprovider.com',
    'smtp_port' => 587,
    'smtp_encryption' => 'tls',
    'smtp_username' => 'orders@yourdomain.com',
    'smtp_password' => 'YOUR_SMTP_PASSWORD',
];
```

Test it:

```powershell
C:\xampp\php\php.exe tools\test-email.php your-real-email@example.com
```

Do not put real SMTP passwords in source control or screenshots.

## 10. Online payment — local test mode

On localhost choose **Pay online (TEST MODE)** at checkout.

Flow:

1. customer places order
2. stock is reserved
3. order-confirmation email is generated
4. customer opens Pay online
5. test payment page simulates provider success
6. payment attempt becomes Succeeded
7. payment record becomes Paid automatically
8. audit event is added
9. payment receipt email is generated
10. owner sees Paid but still approves/fulfils the order normally

No real money moves in this mode. The code restricts this demo gateway to localhost/loopback/`.local`/`.test` hostnames.

## 11. PayPal sandbox

Create a PayPal Developer REST app, then add the sandbox values to `app/config.local.php`:

```php
return [
    'app_url' => 'https://YOUR-PUBLIC-TEST-DOMAIN/ramina-sweets',
    'demo_payment_enabled' => false,
    'paypal_enabled' => true,
    'paypal_mode' => 'sandbox',
    'paypal_client_id' => 'YOUR_SANDBOX_CLIENT_ID',
    'paypal_client_secret' => 'YOUR_SANDBOX_SECRET',
    'paypal_webhook_id' => 'YOUR_WEBHOOK_ID',
    'paypal_currency' => 'NZD',
    'paypal_fjd_to_currency_rate' => 0.00,
];
```

Set `paypal_fjd_to_currency_rate` to the current conversion rate your business chooses to use. The application stores/receipts the original FJD order total and separately records the provider amount/currency.

PayPal redirects need an externally reachable return URL for a realistic sandbox test, and PayPal webhooks require an HTTPS URL accessible by PayPal. A plain `localhost` webhook cannot be reached by PayPal.

Register this webhook endpoint in the PayPal app:

`https://YOUR-DOMAIN/ramina-sweets/payment-webhook.php`

Subscribe at minimum to:

`PAYMENT.CAPTURE.COMPLETED`, `PAYMENT.CAPTURE.PENDING`, and `PAYMENT.CAPTURE.DENIED`

The site verifies the webhook signature before processing it.

## 12. PayPal live

Only after sandbox tests pass:

- change `paypal_mode` to `live`
- use live client ID/secret and live webhook ID
- set the real HTTPS `app_url`
- confirm the presentment currency/rate and merchant account configuration
- keep `demo_payment_enabled` false

Never expose the client secret in HTML/JavaScript.

## 13. Refunds

For a provider-paid online order:

1. owner cancels the order (stock is restored once)
2. the order remains Paid until the money is actually refunded
3. owner opens the cancelled order and clicks **Refund online payment**
4. DemoPay refunds immediately; PayPal calls the provider refund endpoint
5. only a provider-confirmed refund changes the payment to Refunded
6. customer receives an update email

Manual M-PAiSA/bank/cash refunds remain external/manual because those payment channels are not API-controlled by this website.

## 14. Password reset test

1. Log out.
2. Open Login → **Forgot your password?**
3. Enter an account email.
4. In log mode, open the newest file in `storage\mail`.
5. Open the reset link.
6. Set a new password.
7. Old authenticated sessions are invalidated.

The UI does not reveal whether an email address exists.

## 15. Owner additions

Owner navigation now includes:

- Orders & payments
- Customers
- Sales reports
- Customer messages

Customer deactivation preserves history but prevents future authenticated use. CSV reports use the same selected date range as the screen and neutralise spreadsheet-formula prefixes in user-controlled cells.

## 16. Before public launch

Use HTTPS, a non-root database account, real business/social details, real SMTP, sandbox-tested merchant credentials, private backups, protected secrets and a public webhook endpoint. Check PHP error logs, file/session permissions, password-reset delivery, payment capture/refund, receipt privacy and stock concurrency on the actual hosting provider.
