<?php
require __DIR__.'/app/bootstrap.php';
$user=current_user();$error=null;$id=filter_var(value('attempt',$_GET),FILTER_VALIDATE_INT) ?: filter_var(value('attempt'),FILTER_VALIDATE_INT) ?: 0;
$attempt=one('SELECT pa.*,o.public_reference,o.total_cents,o.status order_status,p.status payment_status FROM payment_attempts pa JOIN orders o ON o.id=pa.order_id JOIN payments p ON p.order_id=o.id WHERE pa.id=?',[$id]);
if(!$attempt || $attempt['provider']!=='DemoPay'){http_response_code(404);exit('Test payment not found.');}
try{payment_owner((int)$attempt['order_id'],$user);}catch(DomainException $e){http_response_code(404);exit('Payment unavailable.');}
if(post()){
    check_csrf();
    try{$orderId=demo_complete_payment($id,$user);flash('Test payment completed and verified automatically. A payment receipt was generated.');redirect('order.php?id='.$orderId);}catch(DomainException $e){$error=$e->getMessage();}
}
page_header('Test payment');
?>
<section class="form-card payment-card"><p class="eyebrow">PAYMENT SANDBOX</p><h1>Test checkout</h1><?php error_box($error); ?><p class="notice">No real money is charged on this page. It exists so you can demonstrate the complete automatic confirmation workflow locally.</p><p>Order <strong><?= e($attempt['public_reference']) ?></strong><br>Amount <strong><?= money($attempt['total_cents']) ?></strong></p>
<?php if($attempt['payment_status']==='Paid'): ?><p>This test order is already paid.</p><a class="button" href="order.php?id=<?= (int)$attempt['order_id'] ?>">View receipt</a><?php else: ?><form method="post"><?= csrf() ?><input type="hidden" name="attempt" value="<?= $id ?>"><button class="button wide">Simulate successful secure payment</button></form><p><a class="text-link" href="payment-cancel.php?attempt=<?= $id ?>">Cancel and return</a></p><?php endif ?></section>
<?php page_footer(); ?>
