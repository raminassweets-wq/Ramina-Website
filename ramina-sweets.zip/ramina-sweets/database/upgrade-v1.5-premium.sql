-- Ramina's Sweets v1.5 Premium upgrade.
-- Back up the database first. Run this ONCE after upgrading a v1.4 database.

CREATE TABLE email_delivery_log (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 recipient VARCHAR(190) NOT NULL,
 subject VARCHAR(190) NOT NULL,
 transport VARCHAR(20) NOT NULL,
 status ENUM('Sent','Failed') NOT NULL,
 error_message VARCHAR(500) NOT NULL DEFAULT '',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX email_log_created (created_at),
 INDEX email_log_recipient (recipient,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Ensure the configured owner/admin account exists and can log in after the upgrade.
INSERT INTO users (name,email,password_hash,role,account_status,email_verified_at)
VALUES ('Ramina''s Sweets Admin','ryanonlineshopping8989@gmail.com','$2y$12$FMfFkDPmlgT4/mAXWVObmuq3SV6aAiY2xIBRg1X.6tW/zTD15hu9a','admin','Active',NOW())
ON DUPLICATE KEY UPDATE
  password_hash=VALUES(password_hash),
  role='admin',
  account_status='Active',
  email_verified_at=COALESCE(email_verified_at,NOW());

