-- Back up first. Run ONCE after upgrade-guest-orders.sql, on the existing database.
-- Existing orders and payments keep their statuses; new contact fields start empty.
ALTER TABLE users
 ADD mpaisa_number VARCHAR(30) NOT NULL DEFAULT '',
 ADD viber_number VARCHAR(30) NOT NULL DEFAULT '',
 ADD contact_preference ENUM('Phone','Viber') NOT NULL DEFAULT 'Phone';
ALTER TABLE orders
 ADD requested_time TIME NULL,
 ADD viber_number VARCHAR(30) NOT NULL DEFAULT '',
 ADD contact_preference ENUM('Phone','Viber') NOT NULL DEFAULT 'Phone',
 ADD confirmed_date DATE NULL,
 ADD confirmed_time TIME NULL,
 ADD pickup_location VARCHAR(300) NOT NULL DEFAULT '',
 ADD viber_sent_at DATETIME NULL;
ALTER TABLE payments
 ADD payer_number VARCHAR(30) NOT NULL DEFAULT '',
 ADD customer_reference VARCHAR(120) NOT NULL DEFAULT '',
 ADD submitted_at DATETIME NULL;
