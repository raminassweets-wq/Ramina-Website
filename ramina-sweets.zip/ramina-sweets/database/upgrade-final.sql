-- Optional manual final-release upgrade. The website also applies these two additive tables automatically.
CREATE TABLE IF NOT EXISTS app_meta (
 meta_key VARCHAR(64) PRIMARY KEY,
 meta_value VARCHAR(255) NOT NULL,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS email_delivery_log (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 recipient VARCHAR(190) NOT NULL,
 subject VARCHAR(190) NOT NULL,
 transport VARCHAR(20) NOT NULL,
 status ENUM('Sent','Failed') NOT NULL,
 error_message VARCHAR(500) NOT NULL DEFAULT '',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX email_log_created (created_at),
 INDEX email_log_recipient (recipient,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS email_queue (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 recipient VARCHAR(190) NOT NULL,
 subject VARCHAR(190) NOT NULL,
 html_body MEDIUMTEXT NOT NULL,
 text_body MEDIUMTEXT NOT NULL,
 attempts INT UNSIGNED NOT NULL DEFAULT 0,
 last_error VARCHAR(500) NOT NULL DEFAULT '',
 next_attempt_at DATETIME NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 sent_at DATETIME NULL,
 INDEX queue_ready (sent_at,next_attempt_at,created_at),
 INDEX queue_recipient (recipient,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO app_meta (meta_key,meta_value) VALUES ('schema_version','2.0-final')
ON DUPLICATE KEY UPDATE meta_value=VALUES(meta_value);

CREATE TABLE IF NOT EXISTS site_settings (
 setting_key VARCHAR(80) PRIMARY KEY,
 setting_value TEXT NOT NULL,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
