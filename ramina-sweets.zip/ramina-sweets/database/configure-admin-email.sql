-- Run this on an existing v1.5 database if you only need to configure/reset the owner account.
INSERT INTO users (name,email,password_hash,role,account_status,email_verified_at)
VALUES ('Ramina''s Sweets Admin','ryanonlineshopping8989@gmail.com','$2y$12$FMfFkDPmlgT4/mAXWVObmuq3SV6aAiY2xIBRg1X.6tW/zTD15hu9a','admin','Active',NOW())
ON DUPLICATE KEY UPDATE
  password_hash=VALUES(password_hash),
  role='admin',
  account_status='Active',
  email_verified_at=COALESCE(email_verified_at,NOW());
