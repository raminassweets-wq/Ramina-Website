-- Run ONCE on an existing installation. Back up the database first.
-- Do not run this after importing the new schema.sql.
ALTER TABLE orders MODIFY user_id INT UNSIGNED NULL,
 ADD public_reference VARCHAR(32) NULL UNIQUE,
 ADD guest_access_hash CHAR(64) NULL,
 ADD customer_email VARCHAR(190) NOT NULL DEFAULT '';
UPDATE orders SET public_reference=CONCAT('RS-LEGACY-',id);
UPDATE orders o JOIN users u ON u.id=o.user_id SET o.customer_email=u.email;
ALTER TABLE orders MODIFY public_reference VARCHAR(32) NOT NULL;
ALTER TABLE orders MODIFY status ENUM('Pending','Preparing','Ready','Approved','Completed','Cancelled') NOT NULL DEFAULT 'Pending';
UPDATE orders SET status='Approved' WHERE status IN ('Preparing','Ready');
ALTER TABLE orders MODIFY status ENUM('Pending','Approved','Completed','Cancelled') NOT NULL DEFAULT 'Pending';
ALTER TABLE payments MODIFY method ENUM('Cash on collection','Bank transfer','M-PAiSA') NOT NULL;
ALTER TABLE order_events MODIFY actor_id INT UNSIGNED NULL;
-- celebration_requests is intentionally not dropped: old records are preserved.
