-- Back up first. Run once on an existing database; fresh installs already include this column.
ALTER TABLE products ADD image_path VARCHAR(190) NOT NULL DEFAULT '';
