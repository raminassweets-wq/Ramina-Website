-- Ramina's Sweets. Import into an empty MySQL 8 / MariaDB 10.4+ database.
-- InnoDB provides transactions and row locks. Amounts are integer FJD cents.
CREATE TABLE users (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(80) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 phone VARCHAR(30) NOT NULL DEFAULT '',
 mpaisa_number VARCHAR(30) NOT NULL DEFAULT '',
 viber_number VARCHAR(30) NOT NULL DEFAULT '',
 contact_preference ENUM('Phone','Viber') NOT NULL DEFAULT 'Phone',
 password_hash VARCHAR(255) NOT NULL,
 role ENUM('customer','admin') NOT NULL DEFAULT 'customer',
 account_status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
 email_verified_at DATETIME NULL,
 session_version INT UNSIGNED NOT NULL DEFAULT 1,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE categories (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(80) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE products (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 category_id INT UNSIGNED NOT NULL,
 name VARCHAR(100) NOT NULL,
 description TEXT NOT NULL,
 image_path VARCHAR(190) NOT NULL DEFAULT '',
 pack_size VARCHAR(80) NOT NULL,
 ingredients TEXT NOT NULL,
 allergens TEXT NOT NULL,
 price_cents INT UNSIGNED NOT NULL,
 stock INT UNSIGNED NOT NULL DEFAULT 0,
 low_stock_threshold INT UNSIGNED NOT NULL DEFAULT 5,
 active TINYINT(1) NOT NULL DEFAULT 1,
 deleted_at DATETIME NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (category_id) REFERENCES categories(id),
 INDEX catalogue (active, deleted_at, category_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE orders (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id INT UNSIGNED NULL,
 public_reference VARCHAR(32) NOT NULL UNIQUE,
 guest_access_hash CHAR(64) NULL,
 customer_email VARCHAR(190) NOT NULL DEFAULT '',
 submission_key CHAR(64) NOT NULL UNIQUE,
 customer_name VARCHAR(80) NOT NULL,
 customer_phone VARCHAR(30) NOT NULL,
 collection_date DATE NOT NULL,
 requested_time TIME NULL,
 viber_number VARCHAR(30) NOT NULL DEFAULT '',
 contact_preference ENUM('Phone','Viber') NOT NULL DEFAULT 'Phone',
 confirmed_date DATE NULL,
 confirmed_time TIME NULL,
 pickup_location VARCHAR(300) NOT NULL DEFAULT '',
 viber_sent_at DATETIME NULL,
 notes TEXT NOT NULL,
 total_cents INT UNSIGNED NOT NULL,
 status ENUM('Pending','Approved','Completed','Cancelled') NOT NULL DEFAULT 'Pending',
 stock_restored TINYINT(1) NOT NULL DEFAULT 0,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY (user_id) REFERENCES users(id),
 INDEX customer_orders (user_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE order_items (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 order_id INT UNSIGNED NOT NULL,
 product_id INT UNSIGNED NOT NULL,
 product_name VARCHAR(100) NOT NULL,
 pack_size VARCHAR(80) NOT NULL,
 quantity INT UNSIGNED NOT NULL,
 unit_price_cents INT UNSIGNED NOT NULL,
 FOREIGN KEY (order_id) REFERENCES orders(id),
 FOREIGN KEY (product_id) REFERENCES products(id),
 UNIQUE KEY order_product (order_id, product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE payments (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 order_id INT UNSIGNED NOT NULL UNIQUE,
 method ENUM('Cash on collection','Bank transfer','M-PAiSA','Online payment') NOT NULL,
 status ENUM('Unpaid','Paid','Refunded') NOT NULL DEFAULT 'Unpaid',
 reference VARCHAR(120) NOT NULL DEFAULT '',
 provider VARCHAR(30) NOT NULL DEFAULT '',
 payer_number VARCHAR(30) NOT NULL DEFAULT '',
 customer_reference VARCHAR(120) NOT NULL DEFAULT '',
 submitted_at DATETIME NULL,
 recorded_by INT UNSIGNED NULL,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY (order_id) REFERENCES orders(id),
 FOREIGN KEY (recorded_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE order_events (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 order_id INT UNSIGNED NOT NULL,
 actor_id INT UNSIGNED NULL,
 message VARCHAR(255) NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (order_id) REFERENCES orders(id),
 FOREIGN KEY (actor_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE reviews (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id INT UNSIGNED NOT NULL,
 product_id INT UNSIGNED NOT NULL,
 rating TINYINT UNSIGNED NOT NULL,
 comment VARCHAR(1000) NOT NULL,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY (user_id) REFERENCES users(id),
 FOREIGN KEY (product_id) REFERENCES products(id),
 UNIQUE KEY one_review (user_id, product_id),
 CHECK (rating BETWEEN 1 AND 5)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE chat_threads (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 public_token CHAR(64) NOT NULL UNIQUE,
 user_id INT UNSIGNED NULL,
 customer_name VARCHAR(80) NOT NULL DEFAULT '',
 customer_email VARCHAR(190) NOT NULL DEFAULT '',
 status ENUM('Open','Answered','Closed') NOT NULL DEFAULT 'Open',
 last_customer_at DATETIME NULL,
 last_admin_at DATETIME NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY (user_id) REFERENCES users(id),
 INDEX chat_status_updated (status, updated_at),
 INDEX chat_user (user_id, updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE chat_messages (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 thread_id BIGINT UNSIGNED NOT NULL,
 sender ENUM('customer','bot','admin') NOT NULL,
 message VARCHAR(1000) NOT NULL,
 automated TINYINT(1) NOT NULL DEFAULT 0,
 seen_by_admin TINYINT(1) NOT NULL DEFAULT 0,
 seen_by_customer TINYINT(1) NOT NULL DEFAULT 0,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (thread_id) REFERENCES chat_threads(id) ON DELETE CASCADE,
 INDEX chat_thread_messages (thread_id, id),
 INDEX chat_admin_unread (seen_by_admin, sender, thread_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE account_events (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 customer_id INT UNSIGNED NOT NULL,
 actor_id INT UNSIGNED NOT NULL,
 action VARCHAR(120) NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (customer_id) REFERENCES users(id),
 FOREIGN KEY (actor_id) REFERENCES users(id),
 INDEX account_event_customer (customer_id,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE email_verification_requests (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id INT UNSIGNED NOT NULL,
 token_hash CHAR(64) NOT NULL UNIQUE,
 expires_at DATETIME NOT NULL,
 used_at DATETIME NULL,
 created_at DATETIME NOT NULL,
 FOREIGN KEY (user_id) REFERENCES users(id),
 INDEX verify_user (user_id, expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE password_reset_requests (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id INT UNSIGNED NULL,
 request_key CHAR(64) NOT NULL,
 token_hash CHAR(64) NOT NULL UNIQUE,
 expires_at DATETIME NOT NULL,
 used_at DATETIME NULL,
 created_at DATETIME NOT NULL,
 FOREIGN KEY (user_id) REFERENCES users(id),
 INDEX reset_request_window (request_key, created_at),
 INDEX reset_user (user_id, expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE payment_attempts (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 order_id INT UNSIGNED NOT NULL,
 provider VARCHAR(30) NOT NULL,
 idempotency_key CHAR(64) NOT NULL UNIQUE,
 provider_order_id VARCHAR(80) NULL,
 capture_id VARCHAR(80) NULL,
 amount_cents INT UNSIGNED NOT NULL,
 provider_amount_cents INT UNSIGNED NOT NULL,
 provider_currency CHAR(3) NOT NULL,
 status ENUM('Created','Pending','Approved','Succeeded','Failed','Cancelled','Refunded') NOT NULL DEFAULT 'Created',
 approval_url VARCHAR(700) NULL,
 return_token_hash CHAR(64) NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY (order_id) REFERENCES orders(id),
 INDEX payment_order_status (order_id,status),
 INDEX payment_provider_order (provider,provider_order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE payment_notifications (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 provider VARCHAR(30) NOT NULL,
 event_id VARCHAR(190) NOT NULL,
 event_type VARCHAR(100) NOT NULL,
 payload_hash CHAR(64) NOT NULL,
 received_at DATETIME NOT NULL,
 processed_at DATETIME NULL,
 UNIQUE KEY provider_event (provider,event_id),
 INDEX notification_processing (provider,processed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE email_delivery_log (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 recipient VARCHAR(190) NOT NULL,
 subject VARCHAR(190) NOT NULL,
 transport VARCHAR(20) NOT NULL,
 status ENUM('Sent','Failed') NOT NULL,
 error_message VARCHAR(500) NOT NULL DEFAULT '',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX email_log_created (created_at),
 INDEX email_log_recipient (recipient,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE login_attempts (
 attempt_key CHAR(64) PRIMARY KEY,
 attempts INT UNSIGNED NOT NULL DEFAULT 1,
 last_attempt DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Final release metadata and retryable email outbox.
CREATE TABLE app_meta (
 meta_key VARCHAR(64) PRIMARY KEY,
 meta_value VARCHAR(255) NOT NULL,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE email_queue (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 recipient VARCHAR(190) NOT NULL,
 subject VARCHAR(190) NOT NULL,
 html_body MEDIUMTEXT NOT NULL,
 text_body MEDIUMTEXT NOT NULL,
 attempts INT UNSIGNED NOT NULL DEFAULT 0,
 last_error VARCHAR(500) NOT NULL DEFAULT '',
 next_attempt_at DATETIME NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 sent_at DATETIME NULL,
 INDEX queue_ready (sent_at,next_attempt_at,created_at),
 INDEX queue_recipient (recipient,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO app_meta (meta_key,meta_value) VALUES ('schema_version','2.0-final');

CREATE TABLE site_settings (
 setting_key VARCHAR(80) PRIMARY KEY,
 setting_value TEXT NOT NULL,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
