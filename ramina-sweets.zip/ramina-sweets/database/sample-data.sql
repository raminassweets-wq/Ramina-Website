-- Sample catalogue only: no real business prices or default passwords.
INSERT INTO categories (id,name) VALUES (1,'Traditional sweets'),(2,'Coconut treats'),(3,'Gift boxes');
INSERT INTO products (category_id,name,description,pack_size,ingredients,allergens,price_cents,stock) VALUES
(1,'Golden Besan Laddoo','A traditional golden sweet with a nutty flavour.','Box of 6','Sample recipe: chickpea flour, sugar, ghee and nuts.','Contains dairy and nuts. Confirm ingredients and cross-contact with the business.',1200,20),
(1,'Rose & Pistachio Barfi','A delicate rose-inspired sweet with pistachio.','Box of 6','Sample recipe: milk, sugar, rose flavour and pistachio.','Contains dairy and tree nuts.',1500,20),
(2,'Coconut Delights','Soft coconut bites for an afternoon treat.','Box of 6','Sample recipe: coconut, sugar and milk.','Contains coconut and dairy.',1000,20),
(3,'The Celebration Box','A selection of favourites for a celebration.','Assortment of 12','Sample assortment of laddoo, barfi and coconut sweets.','Contains dairy, nuts and coconut.',3000,12),
(3,'A Little Thank You','A small assortment for a thoughtful gift.','Assortment of 6','Sample assortment of homemade sweets.','Contains dairy, nuts and coconut.',1800,4),
(3,'The Family Selection','A larger selection for family gatherings.','Assortment of 18','Sample assortment of homemade sweets.','Contains dairy, nuts and coconut.',4200,10);

-- Default owner/admin account for this installation.
-- The password is stored only as a PHP password_hash; change it after first login if desired.
INSERT INTO users (name,email,password_hash,role,account_status,email_verified_at)
VALUES ('Ramina''s Sweets Admin','ryanonlineshopping8989@gmail.com','$2y$12$FMfFkDPmlgT4/mAXWVObmuq3SV6aAiY2xIBRg1X.6tW/zTD15hu9a','admin','Active',NOW())
ON DUPLICATE KEY UPDATE
  password_hash=VALUES(password_hash),
  role='admin',
  account_status='Active',
  email_verified_at=COALESCE(email_verified_at,NOW());

