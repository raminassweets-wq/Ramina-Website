-- Upgrade an existing Ramina's Sweets v1.3 database to v1.4.
-- Back up the database first. Run this once in phpMyAdmin or mysql.
ALTER TABLE users
  ADD COLUMN account_status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active' AFTER role,
  ADD COLUMN email_verified_at DATETIME NULL AFTER account_status,
  ADD COLUMN session_version INT UNSIGNED NOT NULL DEFAULT 1 AFTER email_verified_at;

ALTER TABLE payments
  MODIFY COLUMN method ENUM('Cash on collection','Bank transfer','M-PAiSA','Online payment') NOT NULL,
  ADD COLUMN provider VARCHAR(30) NOT NULL DEFAULT '' AFTER reference;


CREATE TABLE account_events (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 customer_id INT UNSIGNED NOT NULL,
 actor_id INT UNSIGNED NOT NULL,
 action VARCHAR(120) NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (customer_id) REFERENCES users(id),
 FOREIGN KEY (actor_id) REFERENCES users(id),
 INDEX account_event_customer (customer_id,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE email_verification_requests (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id INT UNSIGNED NOT NULL,
 token_hash CHAR(64) NOT NULL UNIQUE,
 expires_at DATETIME NOT NULL,
 used_at DATETIME NULL,
 created_at DATETIME NOT NULL,
 FOREIGN KEY (user_id) REFERENCES users(id),
 INDEX verify_user (user_id, expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE password_reset_requests (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id INT UNSIGNED NULL,
 request_key CHAR(64) NOT NULL,
 token_hash CHAR(64) NOT NULL UNIQUE,
 expires_at DATETIME NOT NULL,
 used_at DATETIME NULL,
 created_at DATETIME NOT NULL,
 FOREIGN KEY (user_id) REFERENCES users(id),
 INDEX reset_request_window (request_key, created_at),
 INDEX reset_user (user_id, expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE payment_attempts (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 order_id INT UNSIGNED NOT NULL,
 provider VARCHAR(30) NOT NULL,
 idempotency_key CHAR(64) NOT NULL UNIQUE,
 provider_order_id VARCHAR(80) NULL,
 capture_id VARCHAR(80) NULL,
 amount_cents INT UNSIGNED NOT NULL,
 provider_amount_cents INT UNSIGNED NOT NULL,
 provider_currency CHAR(3) NOT NULL,
 status ENUM('Created','Pending','Approved','Succeeded','Failed','Cancelled','Refunded') NOT NULL DEFAULT 'Created',
 approval_url VARCHAR(700) NULL,
 return_token_hash CHAR(64) NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY (order_id) REFERENCES orders(id),
 INDEX payment_order_status (order_id,status),
 INDEX payment_provider_order (provider,provider_order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE payment_notifications (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 provider VARCHAR(30) NOT NULL,
 event_id VARCHAR(190) NOT NULL,
 event_type VARCHAR(100) NOT NULL,
 payload_hash CHAR(64) NOT NULL,
 received_at DATETIME NOT NULL,
 processed_at DATETIME NULL,
 UNIQUE KEY provider_event (provider,event_id),
 INDEX notification_processing (provider,processed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
