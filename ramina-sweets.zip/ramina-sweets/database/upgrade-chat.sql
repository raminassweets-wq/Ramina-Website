-- Add the customer chatbot and admin support inbox to an existing Ramina's Sweets database.
-- Back up the database first. Run this file once only.
CREATE TABLE chat_threads (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 public_token CHAR(64) NOT NULL UNIQUE,
 user_id INT UNSIGNED NULL,
 customer_name VARCHAR(80) NOT NULL DEFAULT '',
 customer_email VARCHAR(190) NOT NULL DEFAULT '',
 status ENUM('Open','Answered','Closed') NOT NULL DEFAULT 'Open',
 last_customer_at DATETIME NULL,
 last_admin_at DATETIME NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY (user_id) REFERENCES users(id),
 INDEX chat_status_updated (status, updated_at),
 INDEX chat_user (user_id, updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE chat_messages (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 thread_id BIGINT UNSIGNED NOT NULL,
 sender ENUM('customer','bot','admin') NOT NULL,
 message VARCHAR(1000) NOT NULL,
 automated TINYINT(1) NOT NULL DEFAULT 0,
 seen_by_admin TINYINT(1) NOT NULL DEFAULT 0,
 seen_by_customer TINYINT(1) NOT NULL DEFAULT 0,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (thread_id) REFERENCES chat_threads(id) ON DELETE CASCADE,
 INDEX chat_thread_messages (thread_id, id),
 INDEX chat_admin_unread (seen_by_admin, sender, thread_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
