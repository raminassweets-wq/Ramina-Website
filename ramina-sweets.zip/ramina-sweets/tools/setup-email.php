<?php
if(PHP_SAPI!=='cli'){http_response_code(404);exit;}
$root=dirname(__DIR__);
$target=$root.'/app/config.local.php';
$existing=is_file($target)?require $target:[];
if(!is_array($existing)) $existing=[];
function ask(string $prompt,string $default=''): string {
    $suffix=$default!==''?' ['.$default.']':'';
    fwrite(STDOUT,$prompt.$suffix.': ');
    $v=trim((string)fgets(STDIN));
    return $v===''?$default:$v;
}
function secretAsk(string $prompt): string {
    fwrite(STDOUT,$prompt.': ');
    // Windows cmd cannot reliably hide input without platform-specific helpers; be explicit.
    $v=trim((string)fgets(STDIN));
    return $v;
}
echo "\nRamina's Sweets — real email setup\n";
echo "This saves SMTP credentials to app/config.local.php, which Apache blocks from web access.\n";
echo "Do not upload/share that file publicly.\n\n";
$provider=strtolower(ask('Provider (gmail / outlook / custom)','gmail'));
$from=ask('Business sender email', (string)($existing['mail_from_address'] ?? ''));
if(!filter_var($from,FILTER_VALIDATE_EMAIL)){fwrite(STDERR,"Invalid sender email.\n");exit(1);}
$name=ask('Sender name',(string)($existing['mail_from_name'] ?? "Ramina’s Sweets"));
if($provider==='gmail'){$host='smtp.gmail.com';$port=587;$enc='tls';}
elseif($provider==='outlook'){$host='smtp.office365.com';$port=587;$enc='tls';}
else{$host=ask('SMTP host',(string)($existing['smtp_host'] ?? ''));$port=(int)ask('SMTP port',(string)($existing['smtp_port'] ?? '587'));$enc=strtolower(ask('Encryption (tls / ssl / none)',(string)($existing['smtp_encryption'] ?? 'tls')));}
$user=ask('SMTP username',(string)($existing['smtp_username'] ?? $from));
$pass=secretAsk($provider==='gmail'?'SMTP password / Google App Password':'SMTP password');
if($pass===''){fwrite(STDERR,"SMTP password cannot be blank.\n");exit(1);}
$appUrl=ask('Website URL',(string)($existing['app_url'] ?? 'http://localhost/ramina-sweets'));
$updated=array_replace($existing,[
    'app_url'=>$appUrl,
    'mail_transport'=>'smtp',
    'mail_from_address'=>$from,
    'mail_from_name'=>$name,
    'mail_reply_to'=>$from,
    'smtp_host'=>$host,
    'smtp_port'=>$port,
    'smtp_encryption'=>$enc,
    'smtp_username'=>$user,
    'smtp_password'=>$pass,
    'smtp_timeout'=>20,
]);
$content="<?php\n// Local secrets. Keep this file private and never commit/share it.\nreturn ".var_export($updated,true).";\n";
if(file_put_contents($target,$content,LOCK_EX)===false){fwrite(STDERR,"Could not write $target\n");exit(1);}
echo "\nSaved real SMTP configuration to app/config.local.php.\n";
echo "Next run:\n  C:\\xampp\\php\\php.exe tools\\test-email.php $from\n\n";
if($provider==='gmail') echo "For Gmail, use a Google App Password rather than your normal account password when required by your Google account security settings.\n";
