<?php
// Owners are provisioned outside the public website; registration always creates customers.
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require __DIR__.'/../app/db.php';
function prompt(string $label): string { echo $label; return trim(fgets(STDIN)); }
$name=trim(getenv('RAMINA_ADMIN_NAME') ?: prompt('Owner name: '));
$email=strtolower(trim(getenv('RAMINA_ADMIN_EMAIL') ?: prompt('Owner email: ')));
$password=getenv('RAMINA_ADMIN_PASSWORD');
if (!$password) {
    echo "Enter a new owner password (input is visible in this terminal; 8–72 characters).\n";
    $password=prompt('Password: ');
}
if (!$name || (function_exists('mb_strlen') ? mb_strlen($name, 'UTF-8') : strlen($name))>80 || !filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($email)>190 || strlen($password)<8 || strlen($password)>72) { fwrite(STDERR,"Invalid name, email or password length.\n"); exit(1); }
if (one('SELECT id FROM users WHERE email=?',[$email])) { fwrite(STDERR,"That email already exists. No account was changed.\n"); exit(1); }
query("INSERT INTO users (name,email,password_hash,role) VALUES (?,?,?,'admin')",[$name,$email,password_hash($password,PASSWORD_DEFAULT)]);
echo "Owner account created. Use admin/login.php to sign in.\n";
