<?php
if(PHP_SAPI!=='cli'){http_response_code(404);exit;}
require __DIR__.'/../app/bootstrap.php';
$email=$argv[1] ?? '';
if(!filter_var($email,FILTER_VALIDATE_EMAIL)){fwrite(STDERR,"Usage: php tools/test-email.php you@example.com\n");exit(1);}
$ok=send_email($email,'Ramina’s Sweets email test',email_shell('Email is working','<p>This test message confirms that the configured mail transport can send Ramina’s Sweets transactional emails.</p>'));
if(!$ok){fwrite(STDERR,"Email could not be queued/sent. Check the PHP error log and app/config.local.php.\n");exit(1);}
$transport=mail_config()['transport'];echo "PASS: email accepted by transport '$transport'.\n";if($transport==='log')echo "Open storage/mail to view the generated .eml file.\n";
