<?php
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require __DIR__.'/../app/bootstrap.php';
try {
    $pdo=db();
    $version=$pdo->query('SELECT VERSION()')->fetchColumn();
    $meta=one("SELECT meta_value FROM app_meta WHERE meta_key='schema_version'");
    $cfg=app_config();
    echo "Ramina's Sweets is ready.\n";
    echo "Database: ".(string)$cfg['db_name']."\n";
    echo "Server: ".$version."\n";
    echo "Schema: ".($meta['meta_value'] ?? 'installed')."\n";
    echo "Owner account: ".(string)$cfg['bootstrap_admin_email']."\n";
    echo "Open the website in your browser; no SQL import is required on a fresh database when auto-install is enabled.\n";
} catch (Throwable $e) {
    fwrite(STDERR,"Setup could not finish: ".$e->getMessage()."\n");
    exit(1);
}
