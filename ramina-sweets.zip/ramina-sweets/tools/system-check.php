<?php
if(PHP_SAPI!=='cli'){http_response_code(404);exit;}
require __DIR__.'/../app/bootstrap.php';
$checks=[]; $failed=false;
$add=function(string $status,string $label,string $detail='') use (&$checks,&$failed){$checks[]=[$status,$label,$detail];if($status==='FAIL')$failed=true;};

$add(extension_loaded('pdo_mysql')?'PASS':'FAIL','PHP PDO MySQL',extension_loaded('pdo_mysql')?'available':'Enable the pdo_mysql extension on the host');
$add(extension_loaded('openssl')?'PASS':'FAIL','PHP OpenSSL',extension_loaded('openssl')?'available':'Required for secure SMTP/HTTPS connections');
$add(is_writable(dirname(__DIR__).'/storage')?'PASS':'FAIL','Storage directory',is_writable(dirname(__DIR__).'/storage')?'writable':'Make storage/ writable by PHP');

try{
    $version=db()->query('SELECT VERSION()')->fetchColumn();$add('PASS','Database connection',(string)$version);
    $required=['users','categories','products','orders','order_items','payments','order_events','reviews','chat_threads','chat_messages','login_attempts','account_events','email_verification_requests','password_reset_requests','payment_attempts','payment_notifications','email_delivery_log','app_meta','email_queue','site_settings'];
    $missing=[];foreach($required as $t){$x=one('SELECT COUNT(*) total FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name=?',[$t]);if(!(int)($x['total']??0))$missing[]=$t;}
    $add($missing?'FAIL':'PASS','Database schema',$missing?'Missing: '.implode(', ',$missing):'final schema present');
    $cfg=app_config();
    $admin=one('SELECT id,role,account_status FROM users WHERE email=?',[(string)$cfg['bootstrap_admin_email']]);
    $add($admin && $admin['role']==='admin' && $admin['account_status']==='Active'?'PASS':'FAIL','Owner account',$admin?'present and checked':'missing');
}catch(Throwable $e){$add('FAIL','Database connection',$e->getMessage());$cfg=app_config();}

$mail=mail_config();$local=mail_local_request();$smtpReady=smtp_credentials_ready($mail);$hostMail=(!$local&&function_exists('mail'));
if($smtpReady)$add('PASS','Email transport','authenticated SMTP ready');
elseif($hostMail && in_array($mail['transport'],['auto','mail'],true))$add('INFO','Email transport','hosting mail() fallback available; send a test from Owner → System');
elseif($local)$add('INFO','Email transport','no internet sender on localhost; undelivered messages are queued and diagnostic copies are saved');
else $add('INFO','Email transport','no confirmed internet sender; messages remain queued until the host/provider accepts mail');
if(strtolower($mail['smtp_host'])==='smtp.gmail.com' && !$smtpReady)$add('INFO','Gmail SMTP','Gmail basic SMTP requires an App Password/OAuth-authorised credential; an ordinary account password is not treated as ready');

$mode=online_payment_mode();
if($mode==='paypal'){
    $add('PASS','Online payment','PayPal '.(string)$cfg['paypal_mode'].' configured');
    $add(!empty($cfg['paypal_webhook_id'])?'PASS':'FAIL','PayPal webhook',!empty($cfg['paypal_webhook_id'])?'webhook ID configured':'webhook ID missing');
}elseif($mode==='demo') $add('PASS','Local payment test','safe TEST MODE available on localhost');
else $add('INFO','Live online payment','merchant credentials not present; cash/bank/M-PAiSA ordering remains available');

$https=request_is_https();
$add($local||$https?'PASS':'INFO','HTTPS',$local?'not required for local testing':($https?'detected':'enable HTTPS on the live host'));

foreach($checks as [$status,$label,$detail]) echo str_pad($status,5).' '.str_pad($label,25).$detail."\n";
exit($failed?1:0);
