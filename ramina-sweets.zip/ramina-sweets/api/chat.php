<?php
require __DIR__.'/../app/bootstrap.php';
require_once __DIR__.'/../app/chat.php';

header('Content-Type: application/json; charset=utf-8');

function chat_json(array $payload, int $status = 200): never {
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

try {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
        $thread = chat_thread(false);
        if (!$thread) chat_json(['ok'=>true,'messages'=>[]]);
        chat_sync_customer($thread);
        query("UPDATE chat_messages SET seen_by_customer=1 WHERE thread_id=? AND sender='admin'", [$thread['id']]);
        chat_json(['ok'=>true,'messages'=>chat_messages((int)$thread['id'])]);
    }

    if (!post()) chat_json(['ok'=>false,'error'=>'Method not allowed.'], 405);
    check_csrf();
    $messages = chat_send_customer_message(value('message'));
    chat_json(['ok'=>true,'messages'=>$messages]);
} catch (DomainException $e) {
    chat_json(['ok'=>false,'error'=>$e->getMessage()], 422);
} catch (Throwable $e) {
    error_log((string)$e);
    chat_json(['ok'=>false,'error'=>'The chat could not be updated. Please try again.'], 500);
}
