<?php
// Transactional email delivery with SMTP, hosting-mail fallback, local outbox and retry queue.

function mail_config(): array {
    $c = app_config();
    return [
        'transport' => strtolower((string)($c['mail_transport'] ?? 'auto')),
        'from_address' => (string)($c['mail_from_address'] ?? 'no-reply@raminas-sweets.local'),
        'from_name' => (string)($c['mail_from_name'] ?? 'Ramina’s Sweets'),
        'reply_to' => (string)($c['mail_reply_to'] ?? ($c['mail_from_address'] ?? '')),
        'smtp_host' => (string)($c['smtp_host'] ?? ''),
        'smtp_port' => (int)($c['smtp_port'] ?? 587),
        'smtp_encryption' => strtolower((string)($c['smtp_encryption'] ?? 'tls')),
        'smtp_username' => (string)($c['smtp_username'] ?? ''),
        'smtp_password' => (string)($c['smtp_password'] ?? ''),
        'smtp_timeout' => max(5, min(60, (int)($c['smtp_timeout'] ?? 20))),
        'fallback_mail' => !empty($c['mail_fallback_to_php_mail']),
        'fallback_log' => !empty($c['mail_fallback_to_log']),
    ];
}

function mail_local_request(): bool {
    $host = strtolower(preg_replace('/:\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? 'localhost')));
    return in_array($host, ['localhost','127.0.0.1','::1',''], true) || str_ends_with($host, '.test') || str_ends_with($host, '.local');
}

function smtp_credentials_ready(array $cfg): bool {
    if ($cfg['smtp_host'] === '' || $cfg['smtp_username'] === '' || $cfg['smtp_password'] === '' || !filter_var($cfg['from_address'], FILTER_VALIDATE_EMAIL)) return false;
    // Google no longer accepts ordinary Gmail account passwords for SMTP clients. A 16-character App Password
    // is the common basic-auth credential. Skipping an obviously ordinary password prevents every order email
    // from waiting on a guaranteed authentication failure; replacing it with an App Password activates SMTP automatically.
    if (strtolower($cfg['smtp_host']) === 'smtp.gmail.com') {
        $compact = preg_replace('/\s+/', '', $cfg['smtp_password']);
        return is_string($compact) && preg_match('/^[A-Za-z0-9]{16}$/D', $compact) === 1;
    }
    return true;
}

function email_header_value(string $value): string {
    return trim(str_replace(["\r", "\n"], '', $value));
}

function email_address_header(string $email, string $name = ''): string {
    $email = email_header_value($email);
    $name = email_header_value($name);
    return $name !== '' ? '=?UTF-8?B?' . base64_encode($name) . '?= <' . $email . '>' : '<' . $email . '>';
}


function host_mail_sender(): string {
    $host = strtolower((string)(parse_url(absolute_url('/'), PHP_URL_HOST) ?: ''));
    $host = preg_replace('/:\d+$/', '', $host);
    if (!is_string($host) || $host === '' || filter_var($host, FILTER_VALIDATE_IP) || !preg_match('/^[a-z0-9.-]+$/D', $host)) return '';
    return 'no-reply@' . ltrim($host, '.');
}

function record_email_delivery(string $to, string $subject, string $transport, string $status, string $error = ''): void {
    try {
        query('INSERT INTO email_delivery_log (recipient,subject,transport,status,error_message,created_at) VALUES (?,?,?,?,?,NOW())', [
            text_slice($to,0,190), text_slice($subject,0,190), text_slice($transport,0,20), $status, text_slice($error,0,500)
        ]);
    } catch (Throwable $ignored) {}
}

function queue_email(string $to, string $subject, string $html, string $text, string $error): void {
    try {
        query('INSERT INTO email_queue (recipient,subject,html_body,text_body,attempts,last_error,next_attempt_at) VALUES (?,?,?,?,1,?,DATE_ADD(NOW(),INTERVAL 5 MINUTE))', [
            text_slice($to,0,190), text_slice($subject,0,190), $html, $text, text_slice($error,0,500)
        ]);
    } catch (Throwable $ignored) {}
}

function queued_email_count(): int {
    try { return (int)(one('SELECT COUNT(*) total FROM email_queue WHERE sent_at IS NULL')['total'] ?? 0); }
    catch (Throwable $ignored) { return 0; }
}

function retry_email_queue(int $limit = 5): array {
    $limit = max(1, min(20, $limit));
    $rows = query('SELECT * FROM email_queue WHERE sent_at IS NULL AND (next_attempt_at IS NULL OR next_attempt_at<=NOW()) ORDER BY id LIMIT ' . $limit)->fetchAll();
    $sent = 0; $failed = 0;
    foreach ($rows as $row) {
        $ok = send_email((string)$row['recipient'], (string)$row['subject'], (string)$row['html_body'], (string)$row['text_body'], false);
        if ($ok) {
            query('DELETE FROM email_queue WHERE id=?', [$row['id']]);
            $sent++;
        } else {
            $attempts = (int)$row['attempts'] + 1;
            $delay = min(1440, 5 * (2 ** min(8, $attempts - 1)));
            query('UPDATE email_queue SET attempts=?,next_attempt_at=DATE_ADD(NOW(),INTERVAL ' . (int)$delay . ' MINUTE),last_error=? WHERE id=?', [
                $attempts, 'Delivery still unavailable. Check System & email.', $row['id']
            ]);
            $failed++;
        }
    }
    return ['sent'=>$sent,'failed'=>$failed,'processed'=>count($rows)];
}

function send_email(string $to, string $subject, string $html, string $text = '', bool $queueOnFailure = true): bool {
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) return false;
    $cfg = mail_config();
    $subject = email_header_value($subject);
    $transport = $cfg['transport'];
    if (!in_array($transport, ['auto','smtp','mail','log'], true)) $transport = 'auto';
    if ($text === '') {
        $plain = preg_replace('/<br\s*\/?\s*>/i', "\n", $html);
        $text = trim(html_entity_decode(strip_tags((string)$plain), ENT_QUOTES|ENT_HTML5, 'UTF-8'));
    }

    $fromValid = filter_var($cfg['from_address'], FILTER_VALIDATE_EMAIL) !== false;
    if (!$fromValid && $transport !== 'log') {
        $error = 'Invalid sender address.';
        record_email_delivery($to,$subject,$transport,'Failed',$error);
        if ($queueOnFailure) queue_email($to,$subject,$html,$text,$error);
        return false;
    }

    $boundary = '=_ramina_' . bin2hex(random_bytes(12));
    $messageId = '<' . bin2hex(random_bytes(12)) . '.' . time() . '@' . preg_replace('/[^A-Za-z0-9.-]/','',parse_url(absolute_url('/'),PHP_URL_HOST) ?: 'ramina.local') . '>';
    $headers = [
        'Date: ' . date(DATE_RFC2822),
        'Message-ID: ' . $messageId,
        'From: ' . email_address_header($cfg['from_address'],$cfg['from_name']),
        'Reply-To: ' . email_address_header($cfg['reply_to'] ?: $cfg['from_address'],$cfg['from_name']),
        'MIME-Version: 1.0',
        'Content-Type: multipart/alternative; boundary="' . $boundary . '"',
        'X-Mailer: Ramina-Sweets-PHP',
    ];
    $body = "--$boundary\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($text),76,"\r\n");
    $body .= "--$boundary\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($html),76,"\r\n") . "--$boundary--\r\n";

    $errors = [];
    $smtpReady = smtp_credentials_ready($cfg);
    $trySmtp = $transport === 'smtp' || ($transport === 'auto' && $smtpReady);
    if ($trySmtp) {
        try {
            smtp_send($to,$subject,$headers,$body,$cfg);
            record_email_delivery($to,$subject,'smtp','Sent');
            return true;
        } catch (Throwable $error) {
            $errors[] = 'SMTP: ' . $error->getMessage();
            record_email_delivery($to,$subject,'smtp','Failed',$error->getMessage());
            if ($transport === 'smtp') {
                if ($queueOnFailure) queue_email($to,$subject,$html,$text,$error->getMessage());
                return false;
            }
        }
    }

    // On a real hosting server, PHP mail() often routes through the host's configured MTA without any app password.
    // Skip this fallback on localhost where XAMPP normally has no production mail relay.
    $tryHostMail = $transport === 'mail' || ($transport === 'auto' && $cfg['fallback_mail'] && !mail_local_request());
    if ($tryHostMail && function_exists('mail')) {
        // A public host is normally allowed to send from its own domain. Using a gmail.com From address
        // through an unrelated web server can fail SPF/DMARC, so host-mail fallback uses a same-domain
        // envelope/from address while keeping the business Gmail in Reply-To. Authenticated SMTP still
        // uses the configured Gmail sender unchanged.
        $hostFrom = host_mail_sender();
        $mailHeaders = $headers;
        if ($hostFrom !== '') {
            foreach ($mailHeaders as $i=>$header) if (str_starts_with($header,'From: ')) $mailHeaders[$i] = 'From: ' . email_address_header($hostFrom,$cfg['from_name']);
        }
        $encodedSubject = '=?UTF-8?B?' . base64_encode($subject) . '?=';
        $ok = $hostFrom !== '' ? @mail($to,$encodedSubject,$body,implode("\r\n",$mailHeaders),'-f'.$hostFrom) : false;
        if (!$ok) $ok = @mail($to,$encodedSubject,$body,implode("\r\n",$mailHeaders));
        if ($ok) {
            record_email_delivery($to,$subject,'mail','Sent');
            return true;
        }
        $errors[] = 'Hosting mail service returned false.';
        record_email_delivery($to,$subject,'mail','Failed','Hosting mail service returned false.');
        if ($transport === 'mail') {
            if ($queueOnFailure) queue_email($to,$subject,$html,$text,implode(' | ',$errors));
            return false;
        }
    }

    // Explicit log mode is a successful local test transport. In auto mode, the copy is only a diagnostic fallback.
    if ($transport === 'log') {
        $ok = log_email($to,$subject,$headers,$body);
        record_email_delivery($to,$subject,'log',$ok?'Sent':'Failed',$ok?'':'Could not write local email file.');
        return $ok;
    }
    if ($cfg['fallback_log']) {
        try { log_email($to,$subject,$headers,$body); } catch (Throwable $ignored) {}
    }

    $message = $errors ? implode(' | ',$errors) : 'No usable real-email transport is configured.';
    if ($queueOnFailure) queue_email($to,$subject,$html,$text,$message);
    return false;
}

function maybe_retry_email_queue(): void {
    if (PHP_SAPI === 'cli') return;
    try {
        $pending = queued_email_count();
        if ($pending < 1) return;
        $row = one("SELECT meta_value FROM app_meta WHERE meta_key='email_queue_last_retry'");
        $last = $row ? strtotime((string)$row['meta_value']) : false;
        if ($last !== false && $last > time()-300) return;
        query("INSERT INTO app_meta (meta_key,meta_value) VALUES ('email_queue_last_retry',?) ON DUPLICATE KEY UPDATE meta_value=VALUES(meta_value)",[date('Y-m-d H:i:s')]);
        retry_email_queue(3);
    } catch (Throwable $ignored) {
        // Delivery retries must never break a customer request.
    }
}

function log_email(string $to, string $subject, array $headers, string $body): bool {
    $dir = dirname(__DIR__) . '/storage/mail';
    if (!is_dir($dir) && !mkdir($dir,0775,true) && !is_dir($dir)) throw new RuntimeException('Could not create local mail outbox.');
    $name = date('Ymd-His') . '-' . bin2hex(random_bytes(5)) . '.eml';
    $message = 'To: ' . email_address_header($to) . "\r\nSubject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\n" . implode("\r\n",$headers) . "\r\n\r\n" . $body;
    return file_put_contents($dir . '/' . $name,$message,LOCK_EX) !== false;
}

function smtp_send(string $to, string $subject, array $headers, string $body, array $cfg): bool {
    if ($cfg['smtp_host'] === '' || $cfg['from_address'] === '') throw new RuntimeException('SMTP is not configured.');
    if (!smtp_credentials_ready($cfg)) throw new RuntimeException(strtolower($cfg['smtp_host']) === 'smtp.gmail.com' ? 'Gmail SMTP requires an App Password or OAuth-authorised mail service.' : 'SMTP credentials are incomplete.');
    if (!in_array($cfg['smtp_encryption'],['tls','ssl','none'],true)) throw new RuntimeException('SMTP encryption must be tls, ssl or none.');
    $sslOptions = ['ssl'=>['verify_peer'=>true,'verify_peer_name'=>true,'allow_self_signed'=>false,'peer_name'=>$cfg['smtp_host']]];
    $context = stream_context_create($sslOptions);
    $scheme = $cfg['smtp_encryption'] === 'ssl' ? 'ssl://' : '';
    $socket = @stream_socket_client($scheme.$cfg['smtp_host'].':'.$cfg['smtp_port'],$errno,$errstr,$cfg['smtp_timeout'],STREAM_CLIENT_CONNECT,$context);
    if (!$socket) throw new RuntimeException("SMTP connection failed: $errstr ($errno)");
    try {
        stream_set_timeout($socket,$cfg['smtp_timeout']);
        smtp_expect($socket,[220]);
        $helo = preg_replace('/[^A-Za-z0-9.-]/','',parse_url(absolute_url('/'),PHP_URL_HOST) ?: 'ramina-sweets.local') ?: 'ramina-sweets.local';
        smtp_command($socket,'EHLO '.$helo,[250]);
        if ($cfg['smtp_encryption'] === 'tls') {
            smtp_command($socket,'STARTTLS',[220]);
            if (!stream_socket_enable_crypto($socket,true,STREAM_CRYPTO_METHOD_TLS_CLIENT)) throw new RuntimeException('SMTP TLS negotiation failed.');
            smtp_command($socket,'EHLO '.$helo,[250]);
        }
        if ($cfg['smtp_username'] !== '') {
            smtp_command($socket,'AUTH LOGIN',[334]);
            smtp_command($socket,base64_encode($cfg['smtp_username']),[334]);
            smtp_command($socket,base64_encode($cfg['smtp_password']),[235]);
        }
        smtp_command($socket,'MAIL FROM:<'.$cfg['from_address'].'>',[250]);
        smtp_command($socket,'RCPT TO:<'.$to.'>',[250,251]);
        smtp_command($socket,'DATA',[354]);
        $subjectHeader = 'Subject: =?UTF-8?B?'.base64_encode($subject).'?=';
        $data = $subjectHeader."\r\nTo: ".email_address_header($to)."\r\n".implode("\r\n",$headers)."\r\n\r\n".$body;
        $data = preg_replace('/(?m)^\./','..',$data);
        if (fwrite($socket,$data."\r\n.\r\n") === false) throw new RuntimeException('Could not send SMTP message body.');
        smtp_expect($socket,[250]);
        try { smtp_command($socket,'QUIT',[221]); } catch (Throwable $ignored) {}
        return true;
    } finally {
        if (is_resource($socket)) fclose($socket);
    }
}

function smtp_command($socket, string $command, array $expected): string {
    if (fwrite($socket,$command."\r\n") === false) throw new RuntimeException('Could not write to SMTP server.');
    return smtp_expect($socket,$expected);
}

function smtp_expect($socket, array $expected): string {
    $response = '';
    while (($line = fgets($socket,515)) !== false) {
        $response .= $line;
        if (strlen($line) >= 4 && $line[3] === ' ') break;
    }
    $meta = stream_get_meta_data($socket);
    if (!empty($meta['timed_out'])) throw new RuntimeException('SMTP server timed out.');
    $code = (int)substr($response,0,3);
    if (!in_array($code,$expected,true)) throw new RuntimeException('SMTP error '.$code.': '.trim($response));
    return $response;
}
function email_shell(string $title,string $content): string {
    return '<!doctype html><html><body style="margin:0;background:#fff8f3;font-family:Arial,sans-serif;color:#38291f">'
        .'<div style="max-width:680px;margin:0 auto;padding:28px">'
        .'<div style="background:#522e22;color:#fff;padding:20px 24px;border-radius:14px 14px 0 0"><strong style="font-size:24px">RAMINA’S SWEETS</strong><div style="opacity:.85">Homemade delights</div></div>'
        .'<div style="background:#fff;padding:26px;border:1px solid #f0ded1;border-top:0;border-radius:0 0 14px 14px"><h1 style="font-size:24px;margin-top:0">'.e($title).'</h1>'.$content.'</div>'
        .'<p style="font-size:12px;color:#76665d;text-align:center">This message was sent by Ramina’s Sweets. Never send your password, card PIN or one-time code by email.</p>'
        .'</div></body></html>';
}
function order_email_data(int $id): ?array {
    $order=one('SELECT o.*,p.method,p.status payment_status,p.reference payment_reference FROM orders o JOIN payments p ON p.order_id=o.id WHERE o.id=?',[$id]);
    if(!$order) return null;
    $order['items']=query('SELECT product_name,pack_size,quantity,unit_price_cents FROM order_items WHERE order_id=? ORDER BY id',[$id])->fetchAll();
    return $order;
}
function receipt_email_html(array $o,string $headline,string $intro=''): string {
    $rows='';
    foreach($o['items'] as $item){
        $rows.='<tr><td style="padding:8px;border-bottom:1px solid #eee">'.e($item['product_name']).'<br><small>'.e($item['pack_size']).'</small></td><td style="padding:8px;border-bottom:1px solid #eee;text-align:center">'.(int)$item['quantity'].'</td><td style="padding:8px;border-bottom:1px solid #eee;text-align:right">'.e(money((int)$item['unit_price_cents']*(int)$item['quantity'])).'</td></tr>';
    }
    $collection=$o['confirmed_date'] ? e($o['confirmed_date']).' at '.e(substr((string)$o['confirmed_time'],0,5)).' (confirmed)' : e($o['collection_date']).($o['requested_time']?' at '.e(substr((string)$o['requested_time'],0,5)):'').' (requested)';
    $content=($intro!==''?'<p>'.$intro.'</p>':'')
        .'<p><strong>Order:</strong> '.e($o['public_reference']).'<br><strong>Order status:</strong> '.e($o['status']).'<br><strong>Payment:</strong> '.e($o['payment_status']).' · '.e($o['method']).'<br><strong>Collection:</strong> '.$collection.'</p>'
        .'<table style="width:100%;border-collapse:collapse"><thead><tr><th style="text-align:left;padding:8px">Item</th><th style="padding:8px">Qty</th><th style="text-align:right;padding:8px">Subtotal</th></tr></thead><tbody>'.$rows.'</tbody></table>'
        .'<p style="font-size:20px;text-align:right"><strong>Total: '.e(money((int)$o['total_cents'])).'</strong></p>'
        .'<p><a href="'.e(absolute_url('find-order.php')).'" style="display:inline-block;background:#e26f46;color:#fff;text-decoration:none;padding:11px 18px;border-radius:8px">View / find your order</a></p>';
    return email_shell($headline,$content);
}
function send_order_confirmation_email(int $id, ?string $guestCode=null): bool {
    $o=order_email_data($id); if(!$o || !filter_var($o['customer_email'],FILTER_VALIDATE_EMAIL)) return false;
    $intro='Thank you, '.e($o['customer_name']).'. Your order has been saved. This is your order confirmation and receipt summary.';
    if($guestCode) $intro.='<br><br><strong>Guest private access code:</strong> <code>'.e($guestCode).'</code><br>Keep this code private. You need it with the order reference to reopen the receipt.';
    return send_email($o['customer_email'],'Order received · '.$o['public_reference'],receipt_email_html($o,'We received your order',$intro));
}
function send_order_update_email(int $id,string $reason='Order update'): bool {
    $o=order_email_data($id); if(!$o || !filter_var($o['customer_email'],FILTER_VALIDATE_EMAIL)) return false;
    return send_email($o['customer_email'],$reason.' · '.$o['public_reference'],receipt_email_html($o,$reason,'Your Ramina’s Sweets order has been updated.'));
}
function send_payment_receipt_email(int $id): bool {
    $o=order_email_data($id); if(!$o || !filter_var($o['customer_email'],FILTER_VALIDATE_EMAIL)) return false;
    $intro=$o['method']==='Online payment'
        ? 'Your online payment has been verified by the payment provider and recorded as <strong>Paid</strong>. Keep this email for your records.'
        : 'Your payment has been confirmed by Ramina’s Sweets and recorded as <strong>Paid</strong>. Keep this email for your records.';
    return send_email($o['customer_email'],'Payment receipt · '.$o['public_reference'],receipt_email_html($o,'Payment successful',$intro));
}
function send_password_reset_email(string $email,string $name,string $token): bool {
    $link=absolute_url('reset-password.php?token='.rawurlencode($token));
    $content='<p>Hello '.e($name).',</p><p>We received a request to reset your password. This link expires in 60 minutes and can be used once.</p>'
        .'<p><a href="'.e($link).'" style="display:inline-block;background:#e26f46;color:#fff;text-decoration:none;padding:11px 18px;border-radius:8px">Reset password</a></p>'
        .'<p style="word-break:break-all"><small>If the button does not work: '.e($link).'</small></p><p>If you did not request this, you can ignore this email.</p>';
    return send_email($email,'Reset your Ramina’s Sweets password',email_shell('Reset your password',$content));
}
function issue_email_verification(int $userId,string $email,string $name): bool {
    query('UPDATE email_verification_requests SET used_at=COALESCE(used_at,NOW()) WHERE user_id=? AND used_at IS NULL',[$userId]);
    $token=bin2hex(random_bytes(32));
    query('INSERT INTO email_verification_requests (user_id,token_hash,expires_at,created_at) VALUES (?,?,DATE_ADD(NOW(),INTERVAL 24 HOUR),NOW())',[$userId,hash('sha256',$token)]);
    $link=absolute_url('verify-email.php?token='.rawurlencode($token));
    $content='<p>Hello '.e($name).',</p><p>Confirm that this email belongs to your Ramina’s Sweets account. The link expires in 24 hours.</p><p><a href="'.e($link).'" style="display:inline-block;background:#e26f46;color:#fff;text-decoration:none;padding:11px 18px;border-radius:8px">Verify email</a></p><p style="word-break:break-all"><small>'.e($link).'</small></p>';
    return send_email($email,'Verify your Ramina’s Sweets email',email_shell('Verify your email',$content));
}

function send_support_reply_email(string $email,string $name,string $message): bool {
    if(!filter_var($email,FILTER_VALIDATE_EMAIL)) return false;
    $content='<p>Hello '.e($name ?: 'there').',</p><p>Ramina’s Sweets replied to your support conversation:</p>'
        .'<div style="padding:16px 18px;border-left:4px solid #d96844;background:#fff7f2;margin:18px 0">'.nl2br(e($message)).'</div>'
        .'<p><a href="'.e(absolute_url('help.php')).'" style="display:inline-block;background:#522e22;color:#fff;text-decoration:none;padding:11px 18px;border-radius:8px">Open support chat</a></p>';
    return send_email($email,'Ramina’s Sweets replied to your message',email_shell('You have a new support reply',$content));
}

