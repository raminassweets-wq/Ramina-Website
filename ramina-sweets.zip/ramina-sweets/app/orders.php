<?php
// Transactions ensure inventory, order items and payment records stay in sync.
function place_order(array $user, string $key, string $quote, string $date, string $notes, string $method, array $details = []): int {
    if (!preg_match('/^[a-f0-9]{64}$/D', $key)) throw new DomainException('Checkout expired. Reload and try again.');
    // Replay the same result if the browser resends a completed checkout. This lookup happens
    // before the live session-key check so a completed POST remains idempotent even after we rotate the key.
    $existing = one('SELECT id FROM orders WHERE submission_key=? AND user_id <=> ?', [$key, $user['id']]);
    if ($existing) return (int)$existing['id'];
    if (!hash_equals($_SESSION['checkout_key'] ?? '', $key)) throw new DomainException('Checkout expired. Reload and try again.');
    future_date($date); valid_text($notes, 1000, 'Order notes', false);
    if (!in_array($method, ['Cash on collection','Bank transfer','M-PAiSA','Online payment'], true)) throw new DomainException('Select a payment method.');
    valid_text($user['name'],80,'Name');
    valid_text($user['phone'],30,'Phone');
    if (!filter_var($user['email'], FILTER_VALIDATE_EMAIL) || strlen($user['email'])>190) throw new DomainException('Enter a valid email.');
    $phone=contact_number($user['phone'],'Phone',true);
    $payer=contact_number($details['payer_number'] ?? '', 'M-PAiSA payer number', $method==='M-PAiSA');
    if (!empty($details['same_number']) && $payer==='') throw new DomainException('Enter your M-PAiSA number to use it as your Viber contact.');
    $viberPayer=$payer;
    if ($method!=='M-PAiSA') $payer='';
    $viber=contact_number(!empty($details['same_number']) ? $viberPayer : ($details['viber_number'] ?? ''),'Viber number');
    $preference=contact_preference($details['contact_preference'] ?? 'Phone',$viber);
    $time=collection_time($details['requested_time'] ?? '',false);
    db()->beginTransaction();
    try {
        $rows = cart_rows(true); // Locks products in ID order, preventing overselling.
        if (!$rows || count($rows) !== count($_SESSION['cart'] ?? [])) throw new DomainException('Your cart contains an unavailable product. Review your cart.');
        if (!hash_equals(cart_fingerprint($rows), $quote)) throw new DomainException('Prices or quantities changed. Review the updated checkout before submitting again.');
        foreach ($rows as $row) {
            if (!$row['active'] || $row['deleted_at'] || $row['stock'] < $row['quantity']) throw new DomainException($row['name'] . ' is no longer available in the requested quantity. Please update your cart.');
        }
        $publicReference = 'RS-' . strtoupper(bin2hex(random_bytes(5)));
        $guestCode = $user['id'] === null ? strtoupper(bin2hex(random_bytes(8))) : null;
        query('INSERT INTO orders (user_id,public_reference,guest_access_hash,customer_email,submission_key,customer_name,customer_phone,collection_date,notes,total_cents) VALUES (?,?,?,?,?,?,?,?,?,?)', [$user['id'],$publicReference,$guestCode ? hash('sha256',$guestCode) : null,$user['email'],$key,$user['name'],$user['phone'],$date,$notes,cart_total($rows)]);
        $id = (int)db()->lastInsertId();
        query('UPDATE orders SET customer_phone=?,requested_time=?,viber_number=?,contact_preference=? WHERE id=?',[$phone,$time,$viber,$preference,$id]);
        // Saving checkout contact details is an explicit account-holder choice.
        if ($user['id'] && !empty($details['save_details'])) {
            query('UPDATE users SET name=?,phone=?,viber_number=?,contact_preference=? WHERE id=?',[$user['name'],$phone,$viber,$preference,$user['id']]);
            if ($method==='M-PAiSA') query('UPDATE users SET mpaisa_number=? WHERE id=?',[$payer,$user['id']]);
        }
        foreach ($rows as $row) {
            query('INSERT INTO order_items (order_id,product_id,product_name,pack_size,quantity,unit_price_cents) VALUES (?,?,?,?,?,?)', [$id,$row['id'],$row['name'],$row['pack_size'],$row['quantity'],$row['price_cents']]);
            query('UPDATE products SET stock=stock-? WHERE id=?', [$row['quantity'],$row['id']]);
        }
        query('INSERT INTO payments (order_id,method,payer_number) VALUES (?,?,?)', [$id,$method,$payer]);
        query('INSERT INTO order_events (order_id,actor_id,message) VALUES (?,?,?)', [$id,$user['id'],'Order received: Pending']);
        db()->commit();
        if ($guestCode) { $_SESSION['guest_orders'][$id] = true; $_SESSION['guest_codes'][$id] = $guestCode; }
        $_SESSION['cart'] = [];
        unset($_SESSION['checkout_key']); // the next checkout gets a fresh submission key
        // Email failure never rolls back a valid order; send_email() logs failures for the owner.
        send_order_confirmation_email($id,$guestCode);
        return $id;
    } catch (Throwable $error) {
        if (db()->inTransaction()) db()->rollBack();
        // Unique submission keys also protect concurrent double submissions.
        if ($error instanceof PDOException && $error->getCode() === '23000') {
            $existing = one('SELECT id FROM orders WHERE submission_key=? AND user_id <=> ?', [$key,$user['id']]);
            if ($existing) { $_SESSION['cart'] = []; return (int)$existing['id']; }
        }
        throw $error;
    }
}
function manage_order(int $id, array $owner, string $status, string $payment, string $reference): void {
    $transitions = ['Pending'=>['Pending','Approved','Cancelled'],'Approved'=>['Approved','Completed','Cancelled'],'Completed'=>['Completed'],'Cancelled'=>['Cancelled']];
    if (!in_array($payment, ['Unpaid','Paid','Refunded'], true)) throw new DomainException('Invalid payment status.');
    valid_text($reference, 120, 'Payment reference / note', false);
    $notify=false; $paymentBecamePaid=false;
    db()->beginTransaction();
    try {
        $order = one('SELECT * FROM orders WHERE id=? FOR UPDATE', [$id]);
        if (!$order || !in_array($status, $transitions[$order['status']], true)) throw new DomainException('Order status changed or this transition is not allowed. Refresh and choose the next status.');
        $oldPayment = one('SELECT * FROM payments WHERE order_id=? FOR UPDATE', [$id]);
        if(!$oldPayment) throw new DomainException('Payment record not found.');
        $paymentTransitions = ['Unpaid'=>['Unpaid','Paid'], 'Paid'=>['Paid','Refunded'], 'Refunded'=>['Refunded']];
        if (!in_array($payment, $paymentTransitions[$oldPayment['status']], true)) throw new DomainException('Payment records progress from Unpaid to Paid to Refunded.');
        if($oldPayment['method']==='Online payment' && $payment!==$oldPayment['status']) throw new DomainException('Online payment status is controlled by the payment provider. Use the online refund action for a cancelled paid order.');
        if ($payment === 'Refunded' && $status !== 'Cancelled') throw new DomainException('Cancel the order before recording a refund.');
        if ($order['status'] === 'Cancelled' && $oldPayment['status'] === 'Unpaid' && $payment === 'Paid') throw new DomainException('A cancelled order cannot receive a new manual payment.');
        if ($status === 'Approved' && $oldPayment['method'] !== 'Cash on collection' && $payment !== 'Paid') throw new DomainException('Confirm payment before approving this order.');
        if ($status === 'Completed' && $payment !== 'Paid') throw new DomainException('Record the collected/confirmed payment before completing the order.');
        if ($oldPayment['method']!=='Online payment' && $payment !== $oldPayment['status'] && $reference === '') throw new DomainException('Enter a note or reference when recording a payment or refund.');
        if ($status === 'Cancelled' && !$order['stock_restored']) {
            $items = query('SELECT product_id,quantity FROM order_items WHERE order_id=? ORDER BY product_id', [$id])->fetchAll();
            foreach ($items as $item) query('UPDATE products SET stock=stock+? WHERE id=?', [$item['quantity'],$item['product_id']]);
            query('UPDATE orders SET stock_restored=1 WHERE id=?', [$id]);
        }
        query('UPDATE orders SET status=? WHERE id=?', [$status,$id]);
        if ($payment!==$oldPayment['status'] || $status==='Cancelled') query('UPDATE orders SET viber_sent_at=NULL WHERE id=?',[$id]);
        if($oldPayment['method']!=='Online payment') {
            query('UPDATE payments SET status=?,reference=?,recorded_by=? WHERE order_id=?', [$payment,$reference,$owner['id'],$id]);
        }
        $referenceChanged=$oldPayment['method']!=='Online payment' && $reference !== '' && $reference !== $oldPayment['reference'];
        if ($status !== $order['status'] || $payment !== $oldPayment['status'] || $referenceChanged) {
            query('INSERT INTO order_events (order_id,actor_id,message) VALUES (?,?,?)', [$id,$owner['id'],"Status: $status; payment: $payment"]);
            $notify=true;
            $paymentBecamePaid=$oldPayment['status']!=='Paid' && $payment==='Paid';
        }
        db()->commit();
    } catch (Throwable $error) { if (db()->inTransaction()) db()->rollBack(); throw $error; }
    if($paymentBecamePaid) send_payment_receipt_email($id);
    elseif($notify) send_order_update_email($id,'Order status updated');
}
