<?php
// Shared validation and small transaction helpers for payment evidence and collection.
function contact_number(string $number, string $label, bool $required=false): string {
    $number=trim($number);
    if ($number==='' && !$required) return '';
    // Permit local and international numbers, spaces and hyphens; never accept free text.
    if (strlen($number)>30 || !preg_match('/^\+?[0-9][0-9 ()-]*$/D',$number)) throw new DomainException("Enter a valid $label.");
    $digits=preg_replace('/\D/','',$number);
    if (strlen($digits)<7 || strlen($digits)>15) throw new DomainException("$label must contain 7–15 digits.");
    return (str_starts_with($number,'+')?'+':'').$digits;
}
function contact_preference(string $preference, string $viber): string {
    if (!in_array($preference,['Phone','Viber'],true)) throw new DomainException('Choose Phone or Viber.');
    if ($preference==='Viber' && $viber==='') throw new DomainException('Enter your Viber number or choose Phone.');
    return $preference;
}
function collection_time(string $time, bool $required=true): ?string {
    if ($time==='' && !$required) return null;
    if (!preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D',$time)) throw new DomainException('Enter a valid collection time.');
    return $time;
}
function receipt_access(array $order, ?array $user): bool {
    return ($order['user_id']!==null && $user && (int)$order['user_id']===(int)$user['id'])
        || ($order['user_id']===null && !empty($_SESSION['guest_orders'][$order['id']]));
}
function submit_payment_details(int $id, ?array $user, string $payer, string $reference): void {
    valid_text($reference,120,'Transaction reference');
    db()->beginTransaction();
    try {
        $order=one('SELECT * FROM orders WHERE id=? FOR UPDATE',[$id]);
        if (!$order || !receipt_access($order,$user)) throw new DomainException('Receipt unavailable.');
        $payment=one('SELECT * FROM payments WHERE order_id=? FOR UPDATE',[$id]);
        if (!in_array($order['status'],['Pending','Approved'],true) || $payment['status']!=='Unpaid' || $payment['method']==='Cash on collection') throw new DomainException('Payment details can no longer be changed for this order.');
        $payer=$payment['method']==='M-PAiSA' ? contact_number($payer,'M-PAiSA payer number',true) : '';
        if ($reference===$order['public_reference']) throw new DomainException('Enter the transaction reference from your payment receipt, not the shop order reference.');
        if ($payer!==$payment['payer_number'] || $reference!==$payment['customer_reference']) {
            query('UPDATE payments SET payer_number=?,customer_reference=?,submitted_at=NOW() WHERE order_id=?',[$payer,$reference,$id]);
            query('INSERT INTO order_events (order_id,actor_id,message) VALUES (?,?,?)',[$id,$user['id'] ?? null,'Customer submitted payment details; awaiting manual verification.']);
        }
        db()->commit();
    } catch (Throwable $error) { if(db()->inTransaction()) db()->rollBack(); throw $error; }
}
function confirm_collection(int $id, array $owner, string $date, string $time): void {
    future_date($date); collection_time($time);
    if (strtotime("$date $time")<=time()) throw new DomainException('Choose a collection time in the future.');
    $changed=false;
    db()->beginTransaction();
    try {
        $order=one('SELECT * FROM orders WHERE id=? FOR UPDATE',[$id]);
        if (!$order || $order['status']!=='Approved') throw new DomainException('Approve the order before confirming collection. Completed and cancelled orders cannot be changed.');
        if ($date!==$order['confirmed_date'] || $time!==substr($order['confirmed_time'] ?? '',0,5)) {
            query('UPDATE orders SET confirmed_date=?,confirmed_time=?,viber_sent_at=NULL WHERE id=?',[$date,$time,$id]);
            query('INSERT INTO order_events (order_id,actor_id,message) VALUES (?,?,?)',[$id,$owner['id'],'Collection details confirmed/updated. Customer email notification queued.']);
            $changed=true;
        }
        db()->commit();
    } catch (Throwable $error) { if(db()->inTransaction()) db()->rollBack(); throw $error; }
    if($changed) send_order_update_email($id,'Collection confirmed');
}
function collection_signature(array $order): string {
    return hash('sha256',collection_message($order).'|'.$order['viber_number'].'|'.$order['contact_preference'].'|'.$order['status']);
}
function mark_viber_sent(int $id, array $owner, string $signature): void {
    db()->beginTransaction();
    try {
        $order=one('SELECT o.*,p.status payment_status FROM orders o JOIN payments p ON p.order_id=o.id WHERE o.id=? FOR UPDATE',[$id]);
        if (!$order || $order['status']!=='Approved' || !$order['confirmed_date'] || !$order['confirmed_time'] || !$order['viber_number'] || $order['contact_preference']!=='Viber') throw new DomainException('An approved order, confirmed collection and customer-selected Viber contact are required.');
        if (!hash_equals(collection_signature($order),$signature)) throw new DomainException('Collection or payment details changed. Reload and send the updated confirmation.');
        if (!$order['viber_sent_at']) {
            query('UPDATE orders SET viber_sent_at=NOW() WHERE id=?',[$id]);
            query('INSERT INTO order_events (order_id,actor_id,message) VALUES (?,?,?)',[$id,$owner['id'],'Owner recorded that the Viber collection confirmation was sent manually.']);
        }
        db()->commit();
    } catch (Throwable $error) { if(db()->inTransaction()) db()->rollBack(); throw $error; }
}
function collection_message(array $order): string {
    $payment=$order['payment_status']==='Paid' ? 'Payment received.' : 'Please pay cash on collection.';
    return "Your Ramina’s Sweets order {$order['public_reference']} is confirmed.\nCollection: {$order['confirmed_date']} at ".substr($order['confirmed_time'] ?? '',0,5)." (Fiji time).\nTotal: ".money($order['total_cents']).". $payment\nPlease bring your order reference.";
}
