<?php
// Only generated local filenames are used as product picture URLs.
function product_picture(array $product): string {
    $path=$product['image_path'] ?? '';
    return preg_match('~^images/products/[a-f0-9]{32}\.(jpg|png|webp)$~D',$path) && is_file(__DIR__.'/../'.$path) ? $path : 'images/sweets.svg';
}
function upload_product_picture(bool $required): ?string {
    $file=$_FILES['picture'] ?? null;
    if (!$file || ($file['error'] ?? UPLOAD_ERR_NO_FILE)===UPLOAD_ERR_NO_FILE) {
        if ($required) throw new DomainException('Choose a picture of your product.');
        return null;
    }
    if (!is_int($file['error']) || $file['error']!==UPLOAD_ERR_OK) throw new DomainException('The picture could not be uploaded. Choose a JPG, PNG or WebP under 2 MB.');
    if (!is_string($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) throw new DomainException('Choose a valid product picture.');
    if (filesize($file['tmp_name'])>2*1024*1024) throw new DomainException('Choose a picture smaller than 2 MB.');
    // Check the contents, not the browser-supplied MIME type or original filename.
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    $extensions=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    $size=@getimagesize($file['tmp_name']);
    if (!isset($extensions[$mime]) || !$size || ($size['mime'] ?? '')!==$mime || $size[0]<1 || $size[1]<1 || $size[0]>6000 || $size[1]>6000 || $size[0]*$size[1]>16000000) throw new DomainException('Choose a JPG, PNG or WebP picture up to 6000 pixels wide/high and 16 megapixels.');
    $path='images/products/'.bin2hex(random_bytes(16)).'.'.$extensions[$mime];
    $folder=__DIR__.'/../images/products';
    if (!is_dir($folder) || !is_writable($folder)) throw new DomainException('Pictures cannot be saved because the product image folder is unavailable. Please ask the website administrator to check it.');
    if (!move_uploaded_file($file['tmp_name'],__DIR__.'/../'.$path)) throw new DomainException('The picture could not be saved. Please try again with a smaller picture.');
    return $path;
}
function discard_product_picture(?string $path): void {
    // Only remove the newly uploaded file if saving the product failed.
    if ($path && preg_match('~^images/products/[a-f0-9]{32}\.(jpg|png|webp)$~D',$path)) @unlink(__DIR__.'/../'.$path);
}
