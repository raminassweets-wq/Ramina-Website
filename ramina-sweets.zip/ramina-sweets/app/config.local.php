<?php
// Private deployment overrides. Apache access is denied by app/.htaccess.
return [
    "app_url" => "",
    "mail_transport" => "auto",
    "mail_from_address" => "ryanonlineshopping8989@gmail.com",
    "mail_from_name" => "Ramina’s Sweets",
    "mail_reply_to" => "ryanonlineshopping8989@gmail.com",
    "smtp_host" => "smtp.gmail.com",
    "smtp_port" => 587,
    "smtp_encryption" => "tls",
    "smtp_username" => "ryanonlineshopping8989@gmail.com",
    "smtp_password" => "",
    "smtp_timeout" => 15,
];
