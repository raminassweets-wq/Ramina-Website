<?php
// Common bootstrapping, validation and session security for every page.
declare(strict_types=1);

$GLOBALS['ramina_config'] = require __DIR__ . '/config.php';
date_default_timezone_set((string)($GLOBALS['ramina_config']['timezone'] ?? 'Pacific/Fiji'));

$logDir = dirname(__DIR__) . '/storage/logs';
if (!is_dir($logDir)) @mkdir($logDir, 0775, true);
if (is_dir($logDir) && is_writable($logDir)) {
    ini_set('log_errors', '1');
    ini_set('error_log', $logDir . '/app.log');
}
ini_set('display_errors', '0');

require_once __DIR__ . '/db.php';

function app_config(): array {
    return $GLOBALS['ramina_config'];
}

function request_is_https(): bool {
    return !empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off';
}

function request_is_local_host(): bool {
    $host = strtolower(preg_replace('/:\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? 'localhost')));
    return in_array($host, ['localhost','127.0.0.1','::1',''], true) || str_ends_with($host, '.test') || str_ends_with($host, '.local');
}

/**
 * Customer and owner authentication intentionally use different session cookies.
 * This allows the same browser to keep a customer signed in on the storefront
 * while an owner is signed in to /admin at the same time.
 */
function request_session_scope(): string {
    $script = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
    $path = str_replace('\\', '/', (string)(parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: ''));
    return str_contains($script, '/admin/') || str_contains($path, '/admin/') ? 'admin' : 'customer';
}
function session_cookie_name(string $scope): string {
    return $scope === 'admin' ? 'ramina_admin_session' : 'ramina_customer_session';
}
function app_session_scope(): string {
    return request_session_scope();
}
if (PHP_SAPI !== 'cli') {
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_name(session_cookie_name(request_session_scope()));
    session_set_cookie_params([
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => request_is_https(),
        'path' => '/',
    ]);
    session_start();
    $_SESSION['session_scope'] ??= request_session_scope();

    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: same-origin');
    header("Permissions-Policy: camera=(), microphone=(), geolocation=()");
    header("Content-Security-Policy: default-src 'self'; style-src 'self'; img-src 'self' data:; script-src 'self'; connect-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'self'; object-src 'none'");
    if (request_is_https() && !request_is_local_host()) header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    header('Cache-Control: no-store');
}

set_exception_handler(function(Throwable $error): void {
    error_log((string)$error);
    http_response_code(500);
    echo '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Ramina’s Sweets</title><body style="font-family:Arial,sans-serif;padding:40px;max-width:720px;margin:auto"><h1>We could not complete this request.</h1><p>Please try again. If you are setting up the project, check the database configuration and installation guide.</p></body></html>';
});

function e(mixed $value): string { return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8'); }
function text_length(string $text): int { return function_exists('mb_strlen') ? mb_strlen($text, 'UTF-8') : strlen($text); }
function text_lower(string $text): string { return function_exists('mb_strtolower') ? mb_strtolower($text, 'UTF-8') : strtolower($text); }
function text_position(string $haystack, string $needle): int|false { return function_exists('mb_strpos') ? mb_strpos($haystack, $needle, 0, 'UTF-8') : strpos($haystack, $needle); }
function text_slice(string $text, int $start, int $length): string { return function_exists('mb_substr') ? mb_substr($text, $start, $length, 'UTF-8') : substr($text, $start, $length); }
function money(int|string $cents): string { return 'FJ$ ' . number_format((int)$cents / 100, 2); }
function absolute_url(string $path): string {
    $configured = trim((string)(app_config()['app_url'] ?? ''));
    if ($configured !== '') return rtrim($configured, '/') . '/' . ltrim($path, '/');
    $https = request_is_https();
    $host = preg_replace('/[^A-Za-z0-9.\-:\[\]]/', '', $_SERVER['HTTP_HOST'] ?? 'localhost');
    return ($https ? 'https' : 'http') . '://' . $host . url($path);
}
function base_path(): string {
    $dir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/index.php'));
    if (str_ends_with($dir, '/admin')) $dir = substr($dir, 0, -6);
    if (str_ends_with($dir, '/api')) $dir = substr($dir, 0, -4);
    return rtrim($dir === '/' ? '' : $dir, '/');
}
function url(string $path): string { return base_path() . '/' . ltrim($path, '/'); }
function redirect(string $path): never { header('Location: ' . url($path), true, 303); exit; }
function post(): bool { return ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST'; }
function value(string $key, array $source = null): string {
    $data = $source ?? $_POST;
    return isset($data[$key]) && is_scalar($data[$key]) ? trim((string)$data[$key]) : '';
}
function csrf(): string {
    $_SESSION['csrf'] ??= bin2hex(random_bytes(32));
    return '<input type="hidden" name="csrf" value="' . e($_SESSION['csrf']) . '">';
}
function check_csrf(): void {
    if (!isset($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], value('csrf'))) {
        http_response_code(403); exit('This form expired. Reload the page and try again.');
    }
}
function flash(string $text): void { $_SESSION['flash'] = $text; }
function current_user(): ?array {
    if (empty($_SESSION['user_id'])) return null;
    $user = one('SELECT id,name,email,phone,mpaisa_number,viber_number,contact_preference,role,password_hash,account_status,session_version,email_verified_at FROM users WHERE id=?', [$_SESSION['user_id']]);
    $scope = request_session_scope();
    $wrongRole = $user && (($scope === 'admin' && $user['role'] !== 'admin') || ($scope === 'customer' && $user['role'] === 'admin'));
    if (!$user || $wrongRole || ($user['account_status'] ?? 'Active') !== 'Active' || (int)($_SESSION['session_version'] ?? 0) !== (int)$user['session_version']) {
        unset($_SESSION['user_id'], $_SESSION['session_version']);
        return null;
    }
    return $user;
}
function require_user(bool $admin = false): array {
    $user = current_user();
    if (!$user) {
        flash($admin ? 'Please sign in as the owner to continue.' : 'Please log in to continue.');
        redirect($admin ? 'admin/login.php' : 'login.php');
    }
    if ($admin && $user['role'] !== 'admin') { http_response_code(403); exit('Owner access is required.'); }
    return $user;
}
function destroy_current_session(): void {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'] ?? '', (bool)$p['secure'], (bool)$p['httponly']);
    }
    session_destroy();
}
function valid_text(string $text, int $max, string $label, bool $required = true): string {
    if (($required && $text === '') || text_length($text) > $max) throw new DomainException("$label must contain " . ($required ? '1' : '0') . "–$max characters.");
    return $text;
}
function integer(string $text, int $min, int $max, string $label): int {
    if (!preg_match('/^\d+$/D', $text) || (float)$text > $max || (int)$text < $min) throw new DomainException("$label must be a whole number from $min to $max.");
    return (int)$text;
}
function cents(string $text): int {
    if (!preg_match('/^\d{1,5}(\.\d{1,2})?$/D', $text)) throw new DomainException('Enter a valid price with at most two decimal places.');
    [$whole, $fraction] = array_pad(explode('.', $text), 2, '');
    $amount = (int)$whole * 100 + (int)str_pad($fraction, 2, '0');
    if ($amount < 1 || $amount > 1000000) throw new DomainException('Price must be between FJ$ 0.01 and FJ$ 10,000.00.');
    return $amount;
}
function future_date(string $text): string {
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $text);
    if (!$date || $date->format('Y-m-d') !== $text || $text < date('Y-m-d') || $text > date('Y-m-d', strtotime('+1 year'))) throw new DomainException('Choose a valid date between today and one year from today.');
    return $text;
}
function password_valid(string $password): void {
    if (strlen($password) < 8 || strlen($password) > 72) throw new DomainException('Use a password between 8 and 72 bytes long.');
}
function error_box(?string $error): void { if ($error) echo '<p class="notice error" role="alert">' . e($error) . '</p>'; }
function cart_rows(bool $lock = false): array {
    $cart = $_SESSION['cart'] ?? [];
    if (!$cart) return [];
    ksort($cart, SORT_NUMERIC);
    $ids = array_keys($cart);
    $rows = query('SELECT * FROM products WHERE id IN (' . implode(',', array_fill(0, count($ids), '?')) . ') ORDER BY id' . ($lock ? ' FOR UPDATE' : ''), $ids)->fetchAll();
    foreach ($rows as &$row) { $row['quantity'] = (int)$cart[$row['id']]; $row['line_total'] = (int)$row['price_cents'] * $row['quantity']; }
    return $rows;
}
function cart_total(array $rows): int { return array_sum(array_column($rows, 'line_total')); }
function cart_fingerprint(array $rows): string {
    return hash('sha256', json_encode(array_map(fn($r) => [$r['id'], $r['quantity'], $r['price_cents']], $rows)));
}

require_once __DIR__ . '/site.php';
require_once __DIR__ . '/mail.php';
require_once __DIR__ . '/payments.php';
require_once __DIR__ . '/layout.php';
require_once __DIR__ . '/collection.php';
require_once __DIR__ . '/orders.php';
require_once __DIR__ . '/products.php';
if (PHP_SAPI !== 'cli') maybe_retry_email_queue();
