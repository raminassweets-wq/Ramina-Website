<?php
// Ramina's Sweets final configuration.
// Safe defaults live here. Secrets and deployment overrides belong in config.local.php or environment variables.
$config = [
    // Leave blank to auto-detect the current host/path. This lets the same ZIP work on localhost and after hosting.
    'app_url' => getenv('RAMINA_APP_URL') ?: '',
    'app_name' => 'Ramina’s Sweets',
    'timezone' => getenv('RAMINA_TIMEZONE') ?: 'Pacific/Fiji',

    // First-run installation. When the configured database exists but is empty, the app creates its own tables.
    // On local XAMPP, it will also try to create the default database automatically when the DB user has permission.
    'auto_install' => filter_var(getenv('RAMINA_AUTO_INSTALL') ?: '1', FILTER_VALIDATE_BOOL),
    'install_sample_data' => filter_var(getenv('RAMINA_SAMPLE_DATA') ?: '1', FILTER_VALIDATE_BOOL),
    'bootstrap_admin_name' => getenv('RAMINA_ADMIN_NAME') ?: 'Ramina’s Sweets Admin',
    'bootstrap_admin_email' => getenv('RAMINA_ADMIN_EMAIL') ?: 'ryanonlineshopping8989@gmail.com',
    // Password hashes are safe to keep in source. This creates the initial owner account only; it never resets an existing password.
    'bootstrap_admin_password_hash' => getenv('RAMINA_ADMIN_PASSWORD_HASH') ?: '$2y$12$FMfFkDPmlgT4/mAXWVObmuq3SV6aAiY2xIBRg1X.6tW/zTD15hu9a',

    'db_host' => getenv('RAMINA_DB_HOST') ?: '127.0.0.1',
    'db_port' => getenv('RAMINA_DB_PORT') ?: '3306',
    'db_name' => getenv('RAMINA_DB_NAME') ?: 'ramina_sweets',
    'db_user' => getenv('RAMINA_DB_USER') ?: 'root',
    'db_password' => getenv('RAMINA_DB_PASSWORD') ?: '',

    // Business/contact details. These can be replaced on the live host without changing application code.
    'business_email' => getenv('RAMINA_BUSINESS_EMAIL') ?: 'ryanonlineshopping8989@gmail.com',
    'business_phone' => getenv('RAMINA_BUSINESS_PHONE') ?: '',
    'mpaisa_recipient' => getenv('RAMINA_MPAISA_RECIPIENT') ?: '',
    'bank_payment_instructions' => getenv('RAMINA_BANK_INSTRUCTIONS') ?: '',

    // Email transport:
    // auto = try authenticated SMTP first, then the host's PHP mail service, then save a local copy if neither works.
    // smtp/mail/log can be forced explicitly.
    'mail_transport' => getenv('RAMINA_MAIL_TRANSPORT') ?: 'auto',
    'mail_from_address' => getenv('RAMINA_MAIL_FROM') ?: 'ryanonlineshopping8989@gmail.com',
    'mail_from_name' => getenv('RAMINA_MAIL_FROM_NAME') ?: 'Ramina’s Sweets',
    'mail_reply_to' => getenv('RAMINA_MAIL_REPLY_TO') ?: 'ryanonlineshopping8989@gmail.com',
    'smtp_host' => getenv('RAMINA_SMTP_HOST') ?: '',
    'smtp_port' => getenv('RAMINA_SMTP_PORT') ?: '587',
    'smtp_encryption' => getenv('RAMINA_SMTP_ENCRYPTION') ?: 'tls',
    'smtp_username' => getenv('RAMINA_SMTP_USERNAME') ?: '',
    'smtp_password' => getenv('RAMINA_SMTP_PASSWORD') ?: '',
    'smtp_timeout' => (int)(getenv('RAMINA_SMTP_TIMEOUT') ?: 20),
    'mail_fallback_to_php_mail' => true,
    'mail_fallback_to_log' => true,

    // The built-in payment simulator is intentionally available only on localhost/test hosts.
    'demo_payment_enabled' => filter_var(getenv('RAMINA_DEMO_PAYMENT') ?: '1', FILTER_VALIDATE_BOOL),

    // PayPal Orders v2. Real online payment turns on only when all required merchant values are supplied.
    'paypal_enabled' => filter_var(getenv('RAMINA_PAYPAL_ENABLED') ?: '0', FILTER_VALIDATE_BOOL),
    'paypal_mode' => getenv('RAMINA_PAYPAL_MODE') ?: 'sandbox',
    'paypal_client_id' => getenv('RAMINA_PAYPAL_CLIENT_ID') ?: '',
    'paypal_client_secret' => getenv('RAMINA_PAYPAL_CLIENT_SECRET') ?: '',
    'paypal_webhook_id' => getenv('RAMINA_PAYPAL_WEBHOOK_ID') ?: '',
    // PayPal does not settle standard checkout in FJD. A business-approved conversion rate must be supplied for live PayPal.
    'paypal_currency' => getenv('RAMINA_PAYPAL_CURRENCY') ?: 'NZD',
    'paypal_fjd_to_currency_rate' => (float)(getenv('RAMINA_PAYPAL_FX_RATE') ?: '0'),

    'social_links_demo' => false,
    // Verified links can be entered in Owner > System & email. Blank links stay hidden from customers.
    'social_links' => [
        'Facebook' => '',
        'Instagram' => '',
        'TikTok' => '',
        'WhatsApp' => '',
        'Viber' => '',
    ],
];

if (is_file(__DIR__ . '/config.local.php')) {
    $local = require __DIR__ . '/config.local.php';
    if (is_array($local)) $config = array_replace($config, $local);
}

return $config;
