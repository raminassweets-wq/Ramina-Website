<?php

declare(strict_types=1);

function ramina_new_pdo(array $c, bool $withDatabase = true): PDO {
    $dsn = "mysql:host={$c['db_host']};port={$c['db_port']};charset=utf8mb4";
    if ($withDatabase) $dsn .= ';dbname=' . $c['db_name'];
    return new PDO($dsn, (string)$c['db_user'], (string)$c['db_password'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::ATTR_TIMEOUT => 8,
    ]);
}

function db(): PDO {
    static $pdo;
    static $booting = false;
    if ($pdo instanceof PDO) return $pdo;

    $c = require __DIR__ . '/config.php';
    try {
        $pdo = ramina_new_pdo($c, true);
    } catch (PDOException $error) {
        // Zero-setup local XAMPP path: create the configured database when it does not yet exist
        // and the supplied database account has CREATE DATABASE permission.
        $unknownDatabase = (string)$error->getCode() === '1049' || str_contains(strtolower($error->getMessage()), 'unknown database');
        if (empty($c['auto_install']) || !$unknownDatabase || !preg_match('/^[A-Za-z0-9_]+$/D', (string)$c['db_name'])) throw $error;
        $server = ramina_new_pdo($c, false);
        $server->exec('CREATE DATABASE IF NOT EXISTS `' . $c['db_name'] . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
        $pdo = ramina_new_pdo($c, true);
    }

    // Keep database timestamps aligned with the website's Fiji timezone where the server permits it.
    try { $pdo->exec("SET time_zone = '+12:00'"); } catch (Throwable $ignored) {}

    if (!$booting && !empty($c['auto_install'])) {
        $booting = true;
        require_once __DIR__ . '/install.php';
        ensure_application_ready($pdo, $c);
        $booting = false;
    }
    return $pdo;
}

function query(string $sql, array $params = []): PDOStatement {
    $statement = db()->prepare($sql);
    $statement->execute($params);
    return $statement;
}

function one(string $sql, array $params = []): ?array {
    return query($sql, $params)->fetch() ?: null;
}
