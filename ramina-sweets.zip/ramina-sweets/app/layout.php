<?php
function page_header(string $title, bool $owner = false): void {
    $user = current_user();
    $cartCount = $owner ? 0 : array_sum($_SESSION['cart'] ?? []);
    $authTitles=['Login','Register','Forgot password','Reset password','Owner login'];
    $pageClass = $title === 'Home' ? 'page-home' : (in_array($title, $authTitles, true) ? 'page-auth' : 'page-inner');
    $pageClass .= $owner ? ' owner-page' : '';
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#5b2f24">
<meta name="description" content="Ramina’s Sweets — homemade sweets in Fiji with easy ordering, secure accounts, customer reviews and order updates.">
<?php if ($owner): ?><meta name="robots" content="noindex,nofollow"><?php endif ?>
<meta property="og:site_name" content="Ramina’s Sweets">
<meta property="og:type" content="website">
<meta property="og:title" content="<?= e($title) ?> | Ramina’s Sweets">
<meta property="og:description" content="Homemade sweets in Fiji with easy ordering, customer reviews and order updates.">
<title><?= e($title) ?> | Ramina’s Sweets</title>
<link rel="icon" href="<?= e(url('images/sweets.svg')) ?>" type="image/svg+xml">
<link rel="stylesheet" href="<?= e(url('style.css')) ?>">
<?php if ($owner): ?><link rel="stylesheet" href="<?= e(url('admin.css')) ?>"><?php endif ?>
</head>
<body class="<?= e($pageClass) ?>">
<a class="skip-link" href="#main-content">Skip to content</a>
<div class="announcement-bar"><span>Freshly made with care</span><span>•</span><span>Secure ordering</span><span>•</span><span>Email confirmations & receipts</span></div>
<header class="site-header">
<a class="logo" href="<?= e(url($owner ? 'admin/index.php' : 'index.php')) ?>" aria-label="Ramina’s Sweets home"><span class="logo-main">RAMINA’S</span><span class="logo-sub">HOMEMADE SWEETS</span></a>
<input class="menu-toggle" id="menu-toggle" type="checkbox">
<label class="menu-label" for="menu-toggle">☰ <span>Menu</span></label>
<nav class="main-nav" aria-label="Main navigation">
<?php if ($owner): ?>
<a href="<?= e(url('index.php')) ?>">View storefront</a>
<a href="<?= e(url('admin/index.php')) ?>">Dashboard</a>
<a href="<?= e(url('admin/orders.php')) ?>">Orders</a>
<a href="<?= e(url('admin/products.php')) ?>">Products</a>
<a href="<?= e(url('admin/messages.php')) ?>">Messages</a>
<a href="<?= e(url('admin/settings.php')) ?>">System</a>
<form action="<?= e(url('admin/logout.php')) ?>" method="post" class="inline-form"><?= csrf() ?><button class="nav-button owner-logout">Owner logout</button></form>
<?php else: ?>
<a href="<?= e(url('index.php')) ?>">Home</a>
<a href="<?= e(url('products.php')) ?>">Shop</a>
<a href="<?= e(url('reviews.php')) ?>">Reviews</a>
<a href="<?= e(url('about.php')) ?>">Our story</a>
<a href="<?= e(url('find-order.php')) ?>">Track order</a>
<a href="<?= e(url('help.php')) ?>">Help</a>
<?php if ($user): ?>
<a class="account-nav-link" href="<?= e(url('account.php')) ?>">Hi, <?= e(explode(' ',trim($user['name']))[0] ?: 'there') ?></a>
<form action="<?= e(url('logout.php')) ?>" method="post" class="inline-form"><?= csrf() ?><button class="nav-button">Logout</button></form>
<?php else: ?>
<a class="account-nav-link" href="<?= e(url('login.php')) ?>">Sign in</a>
<?php endif ?>
<?php endif ?>
</nav>
<?php if (!$owner): ?><a class="cart-link" href="<?= e(url('cart.php')) ?>" aria-label="Cart, <?= $cartCount ?> items"><span class="bag-icon" aria-hidden="true"></span><span class="cart-count"><?= $cartCount ?></span></a><?php endif ?>
</header>
<?php if ($owner): ?>
<nav class="owner-nav" aria-label="Owner navigation">
<a href="<?= e(url('admin/index.php')) ?>">Overview</a>
<a href="<?= e(url('admin/products.php')) ?>">Products & stock</a>
<a href="<?= e(url('admin/product-edit.php')) ?>">Add product</a>
<a href="<?= e(url('admin/orders.php')) ?>">Orders & payments</a>
<a href="<?= e(url('admin/customers.php')) ?>">Customers</a>
<a href="<?= e(url('admin/reports.php')) ?>">Sales reports</a>
<a href="<?= e(url('admin/messages.php')) ?>">Customer messages</a>
<a href="<?= e(url('admin/settings.php')) ?>">System & email</a>
</nav>
<?php endif ?>
<main class="container section" id="main-content">
<?php if (!empty($_SESSION['flash'])): ?><p class="notice flash-notice" role="status"><?= e($_SESSION['flash']) ?></p><?php unset($_SESSION['flash']); endif ?>
<?php }

function page_footer(): void {
    $config=app_config();
    $configuredSocial=[
        'Facebook'=>site_setting('facebook_url',(string)($config['social_links']['Facebook'] ?? '')),
        'Instagram'=>site_setting('instagram_url',(string)($config['social_links']['Instagram'] ?? '')),
        'TikTok'=>site_setting('tiktok_url',(string)($config['social_links']['TikTok'] ?? '')),
        'WhatsApp'=>site_setting('whatsapp_url',(string)($config['social_links']['WhatsApp'] ?? '')),
        'Viber'=>site_setting('viber_url',(string)($config['social_links']['Viber'] ?? '')),
    ];
    $socialLinks=array_filter($configuredSocial, fn($link)=>is_string($link) && filter_var($link,FILTER_VALIDATE_URL) && strtolower(parse_url($link,PHP_URL_SCHEME) ?? '')==='https');
    $footerUser=current_user();
    $isAdminRoute=request_session_scope()==='admin';
    ?>
</main>
<?php if (!$isAdminRoute): ?>
<aside class="chat-widget" data-chat-widget data-endpoint="<?= e(url('api/chat.php')) ?>">
    <button class="chat-toggle" type="button" data-chat-toggle aria-expanded="false" aria-controls="ramina-chat-panel"><span class="chat-online-dot" aria-hidden="true"></span> Need help? <span aria-hidden="true">💬</span></button>
    <section class="chat-panel" id="ramina-chat-panel" data-chat-panel hidden aria-label="Customer support chat">
        <header class="chat-header"><div><strong>Ramina’s Assistant</strong><small>Instant help + owner replies</small></div><button type="button" data-chat-close aria-label="Close chat">×</button></header>
        <div class="chat-messages" data-chat-messages aria-live="polite"></div>
        <form class="chat-form" data-chat-form><?= csrf() ?><label class="sr-only" for="chat-message-input">Your question</label><textarea id="chat-message-input" name="message" data-chat-input rows="2" maxlength="1000" required placeholder="Ask about products, ordering or collection..."></textarea><button class="button" type="submit">Send</button></form>
        <p class="chat-status" data-chat-status role="status"></p>
    </section>
</aside>
<script src="<?= e(url('assets/chat.js')) ?>" defer></script>
<?php endif ?>
<footer class="site-footer">
    <div class="footer-content">
        <div class="footer-brand-block"><a class="footer-logo" href="<?= e(url('index.php')) ?>">RAMINA’S <span>SWEETS</span></a><p>Homemade delights prepared for everyday treats, celebrations and sharing.</p><div class="footer-trust">Secure accounts · Email receipts · Verified reviews</div></div>
        <div class="footer-links"><h3>Shop</h3><a href="<?= e(url('products.php')) ?>">All sweets</a><a href="<?= e(url('reviews.php')) ?>">Customer reviews</a><a href="<?= e(url('find-order.php')) ?>">Track an order</a><a href="<?= e(url('location.php')) ?>">Location</a></div>
        <div class="footer-links"><h3>Support</h3><a href="<?= e(url('help.php')) ?>">Help & chatbot</a><a href="<?= e(url('about.php')) ?>">Our story</a><a href="<?= e(url('privacy.php')) ?>">Privacy</a><a href="<?= e(url('terms.php')) ?>">Ordering terms</a><?php if(!$isAdminRoute): ?><a href="<?= e(url('forgot-password.php')) ?>">Reset password</a><?php endif ?></div>
        <div class="footer-links"><h3>Account</h3><?php if($isAdminRoute): ?><a href="<?= e(url('admin/index.php')) ?>">Owner dashboard</a><a href="<?= e(url('admin/settings.php')) ?>">System & email</a><a href="<?= e(url('index.php')) ?>">Customer storefront</a><?php elseif($footerUser): ?><a href="<?= e(url('account.php')) ?>">My account</a><a href="<?= e(url('orders.php')) ?>">Purchase history</a><?php else: ?><a href="<?= e(url('login.php')) ?>">Customer login</a><a href="<?= e(url('register.php')) ?>">Create account</a><a href="<?= e(url('admin/login.php')) ?>">Owner login</a><?php endif ?></div>
    </div>
    <?php if($socialLinks): ?><nav class="footer-social" aria-label="Social media"><span>Follow Ramina’s</span><?php foreach($socialLinks as $label=>$link): ?><a href="<?= e($link) ?>" target="_blank" rel="noopener noreferrer"><?= e($label) ?></a><?php endforeach ?></nav><?php endif ?>
    <div class="footer-bottom"><span>© <?= date('Y') ?> Ramina’s Sweets</span><span>Homemade with care · Fiji</span></div>
</footer>
</body>
</html>
<?php }

function product_card(array $p): void {
    $rating = array_key_exists('rating_average', $p) ? ['average'=>$p['rating_average'],'total'=>$p['rating_total']] : one('SELECT AVG(rating) average, COUNT(*) total FROM reviews WHERE product_id=?', [$p['id']]);
    $stock=(int)$p['stock'];
    ?>
<article class="product-card">
<a class="product-image <?= empty($p['image_path']) ? 'category-'.(int)$p['category_id'] : 'has-photo' ?>" href="<?= e(url('product-details.php?id='.$p['id'])) ?>">
<img src="<?= e(url(product_picture($p))) ?>" alt="<?= e($p['name']) ?>" loading="lazy">
<span class="product-stock-badge <?= $stock>0?'in-stock':'sold-out' ?>"><?= $stock>0?'In stock':'Sold out' ?></span>
</a>
<div class="card-content">
<span class="category"><?= e($p['category_name'] ?? '') ?></span>
<h3><a href="<?= e(url('product-details.php?id='.$p['id'])) ?>"><?= e($p['name']) ?></a></h3>
<p class="pack-size"><?= e($p['pack_size']) ?></p>
<div class="product-rating"><?php if ($rating['total']): ?><span aria-hidden="true">★</span> <strong><?= number_format((float)$rating['average'], 1) ?></strong> <small>(<?= (int)$rating['total'] ?> review<?= (int)$rating['total']===1?'':'s' ?>)</small><?php else: ?><span aria-hidden="true">☆</span> <small>New — no reviews yet</small><?php endif ?></div>
<div class="card-bottom"><strong class="product-price"><?= money($p['price_cents']) ?></strong><a class="text-link" href="<?= e(url('product-details.php?id='.$p['id'])) ?>">Details →</a></div>
<form action="<?= e(url('cart.php')) ?>" method="post"><?= csrf() ?><input type="hidden" name="product_id" value="<?= (int)$p['id'] ?>"><input type="hidden" name="action" value="add"><input type="hidden" name="quantity" value="1"><button class="button wide" <?= $stock ? '' : 'disabled' ?>><?= $stock ? 'Add to cart' : 'Sold out' ?></button></form>
<a class="product-review-link" href="<?= e(url('product-details.php?id='.$p['id'].'#reviews')) ?>"><?= $rating['total'] ? 'Read customer reviews' : 'Be the first to review' ?></a>
</div>
</article>
<?php }
