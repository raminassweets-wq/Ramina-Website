<?php
// Optional private overrides. Copy to config.local.php only when your host needs values
// that are not supplied through RAMINA_* environment variables.
return [
    'app_url' => '', // normally auto-detected; set an HTTPS URL for live provider callbacks if needed

    // Database (hosting provider supplies these values)
    // 'db_host' => '127.0.0.1',
    // 'db_port' => '3306',
    // 'db_name' => 'ramina_sweets',
    // 'db_user' => 'your_database_user',
    // 'db_password' => 'your_database_password',

    // Email. "auto" tries authorised SMTP, then public-host PHP mail, then queues failures.
    'mail_transport' => 'auto',
    'mail_from_address' => 'ryanonlineshopping8989@gmail.com',
    'mail_from_name' => 'Ramina’s Sweets',
    'mail_reply_to' => 'ryanonlineshopping8989@gmail.com',
    'smtp_host' => 'smtp.gmail.com',
    'smtp_port' => 587,
    'smtp_encryption' => 'tls',
    'smtp_username' => 'ryanonlineshopping8989@gmail.com',
    'smtp_password' => '', // Gmail requires a Google App Password/OAuth credential, not an ordinary account password.

    // Live PayPal: obtain these from the merchant/provider; start in sandbox.
    'paypal_enabled' => false,
    'paypal_mode' => 'sandbox',
    'paypal_client_id' => '',
    'paypal_client_secret' => '',
    'paypal_webhook_id' => '',
    'paypal_currency' => 'NZD',
    'paypal_fjd_to_currency_rate' => 0.0,
];
