<?php
// Automatic, idempotent first-run installer/migrator. It operates on a PDO instance directly
// so database bootstrap never recursively calls db().

declare(strict_types=1);

function ramina_table_exists(PDO $pdo, string $table): bool {
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?');
    $stmt->execute([$table]);
    return (int)$stmt->fetchColumn() > 0;
}

function ramina_run_sql_file(PDO $pdo, string $file): void {
    $sql = file_get_contents($file);
    if ($sql === false) throw new RuntimeException('Could not read installation SQL: ' . basename($file));
    $sql = preg_replace('/^\xEF\xBB\xBF/', '', $sql);
    // The bundled schema uses ordinary semicolon-terminated statements and no procedures/triggers.
    $parts = preg_split('/;\s*(?:\r?\n|$)/', $sql) ?: [];
    foreach ($parts as $statement) {
        $statement = trim($statement);
        if ($statement === '' || preg_match('/^--[^\n]*(?:\n--[^\n]*)*$/', $statement)) continue;
        $pdo->exec($statement);
    }
}

function ramina_ensure_final_tables(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS app_meta (
        meta_key VARCHAR(64) PRIMARY KEY,
        meta_value VARCHAR(255) NOT NULL,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS email_delivery_log (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        recipient VARCHAR(190) NOT NULL,
        subject VARCHAR(190) NOT NULL,
        transport VARCHAR(20) NOT NULL,
        status ENUM('Sent','Failed') NOT NULL,
        error_message VARCHAR(500) NOT NULL DEFAULT '',
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX email_log_created (created_at),
        INDEX email_log_recipient (recipient,created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS email_queue (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        recipient VARCHAR(190) NOT NULL,
        subject VARCHAR(190) NOT NULL,
        html_body MEDIUMTEXT NOT NULL,
        text_body MEDIUMTEXT NOT NULL,
        attempts INT UNSIGNED NOT NULL DEFAULT 0,
        last_error VARCHAR(500) NOT NULL DEFAULT '',
        next_attempt_at DATETIME NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        sent_at DATETIME NULL,
        INDEX queue_ready (sent_at,next_attempt_at,created_at),
        INDEX queue_recipient (recipient,created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS site_settings (
        setting_key VARCHAR(80) PRIMARY KEY,
        setting_value TEXT NOT NULL,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $stmt = $pdo->prepare("INSERT INTO app_meta (meta_key,meta_value) VALUES ('schema_version',?) ON DUPLICATE KEY UPDATE meta_value=VALUES(meta_value)");
    $stmt->execute(['2.0-final']);
}

function ramina_ensure_bootstrap_admin(PDO $pdo, array $config): void {
    $email = strtolower(trim((string)($config['bootstrap_admin_email'] ?? '')));
    $name = trim((string)($config['bootstrap_admin_name'] ?? 'Ramina’s Sweets Admin'));
    $hash = (string)($config['bootstrap_admin_password_hash'] ?? '');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $hash === '') return;

    $check = $pdo->prepare('SELECT id,role FROM users WHERE email=? LIMIT 1');
    $check->execute([$email]);
    $existing = $check->fetch(PDO::FETCH_ASSOC);
    if ($existing) {
        // Do not reset an existing password on each request. Only make sure the configured owner stays an active admin.
        $update = $pdo->prepare("UPDATE users SET role='admin',account_status='Active',email_verified_at=COALESCE(email_verified_at,NOW()) WHERE id=?");
        $update->execute([(int)$existing['id']]);
        return;
    }
    $insert = $pdo->prepare("INSERT INTO users (name,email,password_hash,role,account_status,email_verified_at) VALUES (?,?,?,'admin','Active',NOW())");
    $insert->execute([$name !== '' ? $name : 'Ramina’s Sweets Admin', $email, $hash]);
}

function ensure_application_ready(PDO $pdo, array $config): void {
    if (empty($config['auto_install'])) return;

    // Serialize first-run requests so two simultaneous browser requests cannot install twice.
    $locked = false;
    try {
        $locked = (bool)$pdo->query("SELECT GET_LOCK('ramina_sweets_install', 10)")->fetchColumn();
    } catch (Throwable $ignored) {
        // Some restricted hosts may not permit GET_LOCK; idempotent CREATE/INSERT operations still make installation safe.
    }

    try {
        if (!ramina_table_exists($pdo, 'users')) {
            ramina_run_sql_file($pdo, dirname(__DIR__) . '/database/schema.sql');
            if (!empty($config['install_sample_data'])) {
                ramina_run_sql_file($pdo, dirname(__DIR__) . '/database/sample-data.sql');
            }
        }
        // Final-release tables are additive, so existing v1.5 databases are upgraded automatically.
        ramina_ensure_final_tables($pdo);
        ramina_ensure_bootstrap_admin($pdo, $config);
        $seed = $pdo->prepare("INSERT IGNORE INTO site_settings (setting_key,setting_value) VALUES (?,?)");
        $defaults = [
            'business_email' => (string)($config['business_email'] ?? ''),
            'business_phone' => (string)($config['business_phone'] ?? ''),
            'mpaisa_recipient' => (string)($config['mpaisa_recipient'] ?? ''),
            'bank_payment_instructions' => (string)($config['bank_payment_instructions'] ?? ''),
            'pickup_information' => '',
            'opening_hours' => 'Collection by confirmed appointment',
            'facebook_url' => '', 'instagram_url' => '', 'tiktok_url' => '', 'whatsapp_url' => '', 'viber_url' => '',
        ];
        foreach ($defaults as $key=>$value) $seed->execute([$key,$value]);
    } finally {
        if ($locked) {
            try { $pdo->query("SELECT RELEASE_LOCK('ramina_sweets_install')"); } catch (Throwable $ignored) {}
        }
    }
}
