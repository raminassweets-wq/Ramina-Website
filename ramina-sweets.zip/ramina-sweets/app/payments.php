<?php
// Online payment adapter. Demo mode provides a safe local test flow; PayPal uses server-side Orders v2 + verified webhooks.
function paypal_supported_payment_currency(string $currency): bool {
    return in_array(strtoupper($currency),['AUD','BRL','CAD','CNY','CZK','DKK','EUR','HKD','HUF','ILS','JPY','MYR','MXN','TWD','NZD','NOK','PHP','PLN','GBP','SGD','SEK','CHF','THB','USD'],true);
}
function online_payment_mode(): string {
    $c=app_config();
    $paypalCurrency=(string)($c['paypal_currency'] ?? 'NZD');
    if (!empty($c['paypal_enabled']) && !empty($c['paypal_client_id']) && !empty($c['paypal_client_secret']) && (float)($c['paypal_fjd_to_currency_rate'] ?? 0)>0 && paypal_supported_payment_currency($paypalCurrency)) return 'paypal';
    $host=strtolower(preg_replace('/:\d+$/','',$_SERVER['HTTP_HOST'] ?? 'localhost'));
    $local=in_array($host,['localhost','127.0.0.1','::1',''],true) || str_ends_with($host,'.test') || str_ends_with($host,'.local');
    if (!empty($c['demo_payment_enabled']) && $local) return 'demo';
    return 'none';
}
function online_payment_available(): bool { return online_payment_mode()!=='none'; }
function online_payment_name(): string {
    return online_payment_mode()==='paypal' ? 'Pay online (PayPal)' : (online_payment_mode()==='demo' ? 'Pay online (TEST MODE)' : 'Online payment');
}
function payment_decimal(int $cents): string { return number_format($cents/100,2,'.',''); }
function paypal_zero_decimal_currency(string $currency): bool { return in_array(strtoupper($currency),['HUF','JPY','TWD'],true); }
function paypal_provider_amount_scaled(int $fjdCents,float $rate,string $currency): int {
    // Stored as hundredths for a consistent schema. Zero-decimal payment currencies are rounded to whole units.
    return paypal_zero_decimal_currency($currency)
        ? (int)round(($fjdCents/100)*$rate)*100
        : (int)round($fjdCents*$rate);
}
function paypal_provider_amount_value(int $scaled,string $currency): string {
    return paypal_zero_decimal_currency($currency) ? (string)(int)round($scaled/100) : payment_decimal($scaled);
}
function payment_owner(int $orderId, ?array $user): array {
    $o=one('SELECT o.*,p.method,p.status payment_status,p.reference payment_reference,p.provider FROM orders o JOIN payments p ON p.order_id=o.id WHERE o.id=?',[$orderId]);
    if(!$o || !receipt_access($o,$user)) throw new DomainException('Receipt unavailable.');
    return $o;
}
function create_online_payment(int $orderId, ?array $user): string {
    $order=payment_owner($orderId,$user);
    if($order['method']!=='Online payment') throw new DomainException('This order does not use online payment.');
    if($order['payment_status']==='Paid') return absolute_url('order.php?id='.$orderId);
    if($order['status']==='Cancelled') throw new DomainException('This order is cancelled and cannot be paid.');
    $mode=online_payment_mode();
    if($mode==='none') throw new DomainException('Online payment is not configured yet. Choose another payment method or contact the owner.');
    $attempt=one("SELECT * FROM payment_attempts WHERE order_id=? AND status IN ('Created','Pending','Approved') ORDER BY id DESC LIMIT 1",[$orderId]);
    if(!$attempt){
        $provider=$mode==='paypal'?'PayPal':'DemoPay';
        $cfg=app_config();
        $currency=$mode==='paypal'?strtoupper((string)($cfg['paypal_currency'] ?? 'NZD')):'FJD';
        $rate=$mode==='paypal'?(float)$cfg['paypal_fjd_to_currency_rate']:1.0;
        if($rate<=0) throw new DomainException('The online payment exchange rate is not configured.');
        $providerCents=$mode==='paypal'?paypal_provider_amount_scaled((int)$order['total_cents'],$rate,$currency):(int)$order['total_cents'];
        $key=hash('sha256',$orderId.'|'.$order['public_reference'].'|'.bin2hex(random_bytes(16)));
        $returnToken=bin2hex(random_bytes(32));
        query('INSERT INTO payment_attempts (order_id,provider,idempotency_key,amount_cents,provider_amount_cents,provider_currency,status,return_token_hash) VALUES (?,?,?,?,?,?,?,?)',[$orderId,$provider,$key,$order['total_cents'],$providerCents,$currency,'Created',hash('sha256',$returnToken)]);
        $attempt=one('SELECT * FROM payment_attempts WHERE id=?',[(int)db()->lastInsertId()]);
        $_SESSION['payment_return_tokens'][(int)$attempt['id']]=$returnToken;
    }
    if($mode==='demo'){
        if(!$attempt['provider_order_id']) query("UPDATE payment_attempts SET provider_order_id=?,status='Pending' WHERE id=?",['DEMO-'.strtoupper(bin2hex(random_bytes(6))),$attempt['id']]);
        return absolute_url('payment-demo.php?attempt='.(int)$attempt['id']);
    }
    if($attempt['provider']!=='PayPal') throw new DomainException('This payment attempt was created for another provider. Start a new order or contact the owner.');
    if($attempt['approval_url']) return $attempt['approval_url'];
    $paypal=paypal_create_order($order,$attempt);
    query("UPDATE payment_attempts SET provider_order_id=?,approval_url=?,status='Pending',updated_at=NOW() WHERE id=?",[$paypal['id'],$paypal['approval_url'],$attempt['id']]);
    return $paypal['approval_url'];
}
function paypal_base_url(): string {
    return (app_config()['paypal_mode'] ?? 'sandbox')==='live' ? 'https://api-m.paypal.com' : 'https://api-m.sandbox.paypal.com';
}
function http_json(string $method,string $url,array $headers=[],?string $body=null,?array $basicAuth=null): array {
    $headers[]='Accept: application/json';
    if(function_exists('curl_init')){
        $ch=curl_init($url);
        curl_setopt_array($ch,[CURLOPT_CUSTOMREQUEST=>$method,CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>25,CURLOPT_HTTPHEADER=>$headers,CURLOPT_HEADER=>false]);
        if($body!==null) curl_setopt($ch,CURLOPT_POSTFIELDS,$body);
        if($basicAuth) curl_setopt($ch,CURLOPT_USERPWD,$basicAuth[0].':'.$basicAuth[1]);
        $raw=curl_exec($ch); $status=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE); $error=curl_error($ch); curl_close($ch);
        if($raw===false) throw new RuntimeException('Payment network error: '.$error);
    } else {
        $headerText=implode("\r\n",$headers);
        if($basicAuth) $headerText.="\r\nAuthorization: Basic ".base64_encode($basicAuth[0].':'.$basicAuth[1]);
        $context=stream_context_create(['http'=>['method'=>$method,'header'=>$headerText,'content'=>$body ?? '','ignore_errors'=>true,'timeout'=>25]]);
        $raw=@file_get_contents($url,false,$context);
        if($raw===false) throw new RuntimeException('Payment network request failed. Enable PHP cURL or allow HTTPS streams.');
        $status=0; foreach($http_response_header ?? [] as $line){ if(preg_match('#^HTTP/\S+\s+(\d+)#',$line,$m)) $status=(int)$m[1]; }
    }
    $decoded=json_decode($raw,true);
    if(!is_array($decoded)) $decoded=[];
    if($status<200 || $status>=300){
        $detail=$decoded['message'] ?? ($decoded['error_description'] ?? 'Payment provider returned an error.');
        throw new RuntimeException($detail.' (HTTP '.$status.')');
    }
    return $decoded;
}
function paypal_access_token(): string {
    static $token=null,$expires=0;
    if($token && $expires>time()+30) return $token;
    $c=app_config();
    $body=http_build_query(['grant_type'=>'client_credentials']);
    $response=http_json('POST',paypal_base_url().'/v1/oauth2/token',['Content-Type: application/x-www-form-urlencoded'],$body,[$c['paypal_client_id'],$c['paypal_client_secret']]);
    if(empty($response['access_token'])) throw new RuntimeException('PayPal did not return an access token.');
    $token=$response['access_token']; $expires=time()+(int)($response['expires_in'] ?? 300);
    return $token;
}
function paypal_create_order(array $order,array $attempt): array {
    $returnToken=$_SESSION['payment_return_tokens'][(int)$attempt['id']] ?? '';
    if($returnToken==='' || !hash_equals($attempt['return_token_hash'],hash('sha256',$returnToken))) throw new DomainException('Payment session expired. Return to the receipt and start payment again.');
    $value=paypal_provider_amount_value((int)$attempt['provider_amount_cents'],(string)$attempt['provider_currency']);
    $payload=[
        'intent'=>'CAPTURE',
        'purchase_units'=>[[
            'reference_id'=>'ramina-order-'.$order['id'],
            'custom_id'=>$order['public_reference'],
            'invoice_id'=>$order['public_reference'].'-'.$attempt['id'],
            'description'=>'Ramina’s Sweets '.$order['public_reference'],
            'amount'=>['currency_code'=>$attempt['provider_currency'],'value'=>$value],
        ]],
        'payment_source'=>[
            'paypal'=>[
                'experience_context'=>[
                    'brand_name'=>'Ramina’s Sweets',
                    'shipping_preference'=>'NO_SHIPPING',
                    'user_action'=>'PAY_NOW',
                    'return_url'=>absolute_url('payment-return.php?attempt='.(int)$attempt['id'].'&rt='.rawurlencode($returnToken)),
                    'cancel_url'=>absolute_url('payment-cancel.php?attempt='.(int)$attempt['id']),
                ],
            ],
        ],
    ];
    $response=http_json('POST',paypal_base_url().'/v2/checkout/orders',['Content-Type: application/json','Authorization: Bearer '.paypal_access_token(),'PayPal-Request-Id: '.$attempt['idempotency_key']],json_encode($payload,JSON_UNESCAPED_SLASHES));
    $approval=''; foreach($response['links'] ?? [] as $link){ if(in_array($link['rel'] ?? '',['approve','payer-action'],true)){$approval=$link['href'];break;} }
    if(empty($response['id']) || $approval==='') throw new RuntimeException('PayPal did not return an approval link.');
    return ['id'=>$response['id'],'approval_url'=>$approval];
}
function paypal_capture_return(int $attemptId,string $returnToken,string $paypalOrderId): int {
    $attempt=one('SELECT * FROM payment_attempts WHERE id=?',[$attemptId]);
    if(!$attempt || $attempt['provider']!=='PayPal') throw new DomainException('Payment attempt not found.');
    if(!hash_equals($attempt['return_token_hash'],hash('sha256',$returnToken))) throw new DomainException('Payment return link is invalid or expired.');
    if(!hash_equals((string)$attempt['provider_order_id'],$paypalOrderId)) throw new DomainException('Payment order mismatch.');
    if($attempt['status']==='Succeeded') return (int)$attempt['order_id'];
    $response=http_json('POST',paypal_base_url().'/v2/checkout/orders/'.rawurlencode($paypalOrderId).'/capture',['Content-Type: application/json','Authorization: Bearer '.paypal_access_token(),'PayPal-Request-Id: capture-'.$attempt['idempotency_key']], '{}');
    $capture=$response['purchase_units'][0]['payments']['captures'][0] ?? null;
    if(($response['status'] ?? '')!=='COMPLETED' || !is_array($capture) || ($capture['status'] ?? '')!=='COMPLETED') throw new DomainException('Payment has not completed yet. Please return to your receipt and try again shortly.');
    finalize_online_payment($attemptId,(string)$capture['id'],(string)$paypalOrderId,(string)($capture['amount']['value'] ?? ''),(string)($capture['amount']['currency_code'] ?? ''));
    unset($_SESSION['payment_return_tokens'][$attemptId]);
    return (int)$attempt['order_id'];
}
function finalize_online_payment(int $attemptId,string $captureId,string $providerOrderId,string $amount,string $currency): void {
    $send=false; $orderId=0; $cancelled=false;
    db()->beginTransaction();
    try{
        $attempt=one('SELECT * FROM payment_attempts WHERE id=? FOR UPDATE',[$attemptId]);
        if(!$attempt) throw new DomainException('Payment attempt not found.');
        $orderId=(int)$attempt['order_id'];
        if($attempt['status']==='Succeeded'){ db()->commit(); return; }
        $expected=paypal_provider_amount_value((int)$attempt['provider_amount_cents'],(string)$attempt['provider_currency']);
        if(strtoupper($currency)!==strtoupper($attempt['provider_currency']) || bc_amount_compare($amount,$expected)!==0) throw new DomainException('Payment amount or currency did not match the order. The owner has been alerted.');
        $payment=one('SELECT * FROM payments WHERE order_id=? FOR UPDATE',[$orderId]);
        $order=one('SELECT * FROM orders WHERE id=? FOR UPDATE',[$orderId]);
        if(!$payment || !$order) throw new DomainException('Order payment record not found.');
        query("UPDATE payment_attempts SET provider_order_id=?,capture_id=?,status='Succeeded',updated_at=NOW() WHERE id=?",[$providerOrderId,$captureId,$attemptId]);
        query("UPDATE payments SET status='Paid',reference=?,provider=?,recorded_by=NULL WHERE order_id=?",[$captureId,$attempt['provider'],$orderId]);
        $cancelled=$order['status']==='Cancelled';
        $message=$cancelled?'Online payment captured after cancellation; refund/reconciliation required.':'Online payment verified automatically: Paid.';
        query('INSERT INTO order_events (order_id,actor_id,message) VALUES (?,NULL,?)',[$orderId,$message]);
        db()->commit(); $send=true;
    }catch(Throwable $e){ if(db()->inTransaction())db()->rollBack(); throw $e; }
    if($send) { if($cancelled) send_order_update_email($orderId,'Payment received after cancellation'); else send_payment_receipt_email($orderId); }
}
function bc_amount_compare(string $a,string $b): int {
    // Compare decimal payment values without requiring ext-bcmath.
    $normalize=function(string $v): string { if(!preg_match('/^\d+(?:\.\d{1,2})?$/',$v)) return ''; [$w,$f]=array_pad(explode('.',$v),2,''); return ltrim($w,'0').'.'.str_pad($f,2,'0'); };
    $a=$normalize($a);$b=$normalize($b); if($a===''||$b==='') return 1;
    [$aw,$af]=explode('.',$a);[$bw,$bf]=explode('.',$b); $aw=$aw===''?'0':$aw;$bw=$bw===''?'0':$bw;
    if(strlen($aw)!==strlen($bw)) return strlen($aw)<=>strlen($bw);
    if($aw!==$bw) return $aw<=>$bw;
    return $af<=>$bf;
}
function verify_paypal_webhook(array $headers,string $rawEvent): bool {
    $c=app_config(); $webhookId=(string)($c['paypal_webhook_id'] ?? ''); if($webhookId==='') return false;
    $map=[]; foreach($headers as $k=>$v){$map[strtolower($k)]=is_array($v)?implode(',',$v):(string)$v;}
    foreach(['paypal-transmission-id','paypal-transmission-time','paypal-cert-url','paypal-auth-algo','paypal-transmission-sig'] as $required) if(empty($map[$required])) return false;
    if(!is_array(json_decode($rawEvent,true))) return false;
    // Preserve the original webhook-event JSON bytes inside PayPal's verification request instead of
    // parsing and re-serializing the event. PayPal's current guidance warns that changing the event
    // representation can cause signature verification to fail.
    $verificationFields=[
        'transmission_id'=>$map['paypal-transmission-id'],
        'transmission_time'=>$map['paypal-transmission-time'],
        'cert_url'=>$map['paypal-cert-url'],
        'auth_algo'=>$map['paypal-auth-algo'],
        'transmission_sig'=>$map['paypal-transmission-sig'],
        'webhook_id'=>$webhookId,
    ];
    $prefix=json_encode($verificationFields,JSON_UNESCAPED_SLASHES);
    if(!is_string($prefix) || !str_ends_with($prefix,'}')) return false;
    $body=substr($prefix,0,-1).',"webhook_event":'.$rawEvent.'}';
    $response=http_json('POST',paypal_base_url().'/v1/notifications/verify-webhook-signature',['Content-Type: application/json','Authorization: Bearer '.paypal_access_token()],$body);
    return strtoupper((string)($response['verification_status'] ?? ''))==='SUCCESS';
}
function process_paypal_webhook(array $event): void {
    $eventId=(string)($event['id'] ?? ''); $eventType=(string)($event['event_type'] ?? '');
    if($eventId==='') throw new DomainException('Webhook event has no ID.');
    $payloadHash=hash('sha256',json_encode($event,JSON_UNESCAPED_SLASHES));
    $existing=one('SELECT processed_at FROM payment_notifications WHERE provider=? AND event_id=?',['PayPal',$eventId]);
    if($existing && $existing['processed_at']) return;
    if(!$existing) query('INSERT INTO payment_notifications (provider,event_id,event_type,payload_hash,received_at) VALUES (?,?,?,?,NOW())',['PayPal',$eventId,$eventType,$payloadHash]);
    if(in_array($eventType,['PAYMENT.CAPTURE.COMPLETED','PAYMENT.CAPTURE.PENDING','PAYMENT.CAPTURE.DENIED'],true)){
        $r=$event['resource'] ?? [];
        $providerOrderId=(string)($r['supplementary_data']['related_ids']['order_id'] ?? '');
        $captureId=(string)($r['id'] ?? '');
        $attempt=$providerOrderId!==''?one('SELECT * FROM payment_attempts WHERE provider=? AND provider_order_id=? ORDER BY id DESC LIMIT 1',['PayPal',$providerOrderId]):null;
        if(!$attempt && !empty($r['custom_id'])) $attempt=one('SELECT pa.* FROM payment_attempts pa JOIN orders o ON o.id=pa.order_id WHERE pa.provider=? AND o.public_reference=? ORDER BY pa.id DESC LIMIT 1',['PayPal',$r['custom_id']]);
        if($attempt && $eventType==='PAYMENT.CAPTURE.COMPLETED'){
            finalize_online_payment((int)$attempt['id'],$captureId,$providerOrderId,(string)($r['amount']['value'] ?? ''),(string)($r['amount']['currency_code'] ?? ''));
        } elseif($attempt && $eventType==='PAYMENT.CAPTURE.DENIED' && !in_array($attempt['status'],['Succeeded','Refunded'],true)) {
            query("UPDATE payment_attempts SET status='Failed',updated_at=NOW() WHERE id=?",[(int)$attempt['id']]);
            query('INSERT INTO order_events (order_id,actor_id,message) VALUES (?,NULL,?)',[(int)$attempt['order_id'],'Online payment was denied by PayPal; the order remains Unpaid.']);
            send_order_update_email((int)$attempt['order_id'],'Online payment was not completed');
        } elseif($attempt && $eventType==='PAYMENT.CAPTURE.PENDING' && !in_array($attempt['status'],['Succeeded','Refunded'],true)) {
            query("UPDATE payment_attempts SET status='Pending',updated_at=NOW() WHERE id=?",[(int)$attempt['id']]);
        }
    }
    query('UPDATE payment_notifications SET processed_at=NOW() WHERE provider=? AND event_id=?',['PayPal',$eventId]);
}
function demo_complete_payment(int $attemptId,?array $user): int {
    $attempt=one('SELECT * FROM payment_attempts WHERE id=?',[$attemptId]); if(!$attempt || $attempt['provider']!=='DemoPay') throw new DomainException('Test payment not found.');
    payment_owner((int)$attempt['order_id'],$user);
    finalize_online_payment($attemptId,'DEMO-CAPTURE-'.strtoupper(bin2hex(random_bytes(6))),(string)$attempt['provider_order_id'],payment_decimal((int)$attempt['provider_amount_cents']),(string)$attempt['provider_currency']);
    return (int)$attempt['order_id'];
}
function refund_online_payment(int $orderId,array $owner): void {
    $order=one('SELECT o.*,p.method,p.status payment_status,p.reference,p.provider FROM orders o JOIN payments p ON p.order_id=o.id WHERE o.id=?',[$orderId]);
    if(!$order || $order['method']!=='Online payment' || $order['payment_status']!=='Paid' || $order['status']!=='Cancelled') throw new DomainException('Cancel a paid online order before issuing its full refund.');
    $attempt=one("SELECT * FROM payment_attempts WHERE order_id=? AND status='Succeeded' ORDER BY id DESC LIMIT 1",[$orderId]);
    if(!$attempt || !$attempt['capture_id']) throw new DomainException('The original online capture could not be found.');

    // Call the provider before opening a database transaction. The provider request is idempotent,
    // then the local state is locked and committed atomically.
    if($attempt['provider']==='PayPal'){
        $response=http_json('POST',paypal_base_url().'/v2/payments/captures/'.rawurlencode($attempt['capture_id']).'/refund',[
            'Content-Type: application/json',
            'Authorization: Bearer '.paypal_access_token(),
            'PayPal-Request-Id: refund-'.$attempt['idempotency_key'],
        ], '{}');
        if(!in_array($response['status'] ?? '',['COMPLETED','PENDING'],true)) throw new DomainException('The payment provider did not accept the refund.');
        if(($response['status'] ?? '')==='PENDING') throw new DomainException('The refund is pending at PayPal. Refresh later before recording it as complete.');
    } elseif($attempt['provider']!=='DemoPay') {
        throw new DomainException('This provider does not support automatic refunds.');
    }

    $send=false;
    db()->beginTransaction();
    try {
        $lockedAttempt=one('SELECT * FROM payment_attempts WHERE id=? FOR UPDATE',[(int)$attempt['id']]);
        $lockedPayment=one('SELECT * FROM payments WHERE order_id=? FOR UPDATE',[$orderId]);
        $lockedOrder=one('SELECT * FROM orders WHERE id=? FOR UPDATE',[$orderId]);
        if(!$lockedAttempt || !$lockedPayment || !$lockedOrder) throw new DomainException('Order payment record not found.');
        if($lockedPayment['status']==='Refunded' || $lockedAttempt['status']==='Refunded') { db()->commit(); return; }
        if($lockedOrder['status']!=='Cancelled' || $lockedPayment['status']!=='Paid') throw new DomainException('The order changed while the refund was being processed. Refresh and review it.');
        query("UPDATE payment_attempts SET status='Refunded',updated_at=NOW() WHERE id=?",[$lockedAttempt['id']]);
        query("UPDATE payments SET status='Refunded',recorded_by=? WHERE order_id=?",[$owner['id'],$orderId]);
        query('INSERT INTO order_events (order_id,actor_id,message) VALUES (?,?,?)',[$orderId,$owner['id'],'Full online payment refund confirmed by provider.']);
        db()->commit();
        $send=true;
    } catch(Throwable $e) {
        if(db()->inTransaction()) db()->rollBack();
        throw $e;
    }
    if($send) send_order_update_email($orderId,'Refund completed');
}
