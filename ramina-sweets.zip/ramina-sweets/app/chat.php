<?php
/** Database-backed customer support chat and rule-based automatic replies. */

function chat_session_token(bool $create=true): string {
    $token=(string)($_SESSION['chat_thread_token'] ?? '');
    if (preg_match('/^[a-f0-9]{64}$/D',$token)) return $token;
    if(!$create) return '';
    $token=bin2hex(random_bytes(32));
    $_SESSION['chat_thread_token']=$token;
    return $token;
}

function chat_thread(bool $create = false): ?array {
    $token=chat_session_token(false);
    if($token!==''){
        $thread=one('SELECT * FROM chat_threads WHERE public_token=?',[$token]);
        if($thread) return $thread;
    }

    // Signed-in customers can continue their latest non-closed conversation from another browser/device.
    $user=current_user();
    if($user){
        $thread=one("SELECT * FROM chat_threads WHERE user_id=? AND status<>'Closed' ORDER BY updated_at DESC,id DESC LIMIT 1",[$user['id']]);
        if($thread){$_SESSION['chat_thread_token']=$thread['public_token'];return $thread;}
    }
    if(!$create) return null;

    $token=chat_session_token(true);
    query("INSERT INTO chat_threads (public_token,user_id,customer_name,customer_email,status) VALUES (?,?,?,?,'Open')",[$token,$user['id'] ?? null,$user['name'] ?? '',$user['email'] ?? '']);
    return one('SELECT * FROM chat_threads WHERE public_token=?',[$token]);
}

function chat_sync_customer(array $thread): void {
    $user = current_user();
    if (!$user) return;
    if ((int)($thread['user_id'] ?? 0) === (int)$user['id'] && $thread['customer_name'] === $user['name'] && $thread['customer_email'] === $user['email']) return;
    query('UPDATE chat_threads SET user_id=?,customer_name=?,customer_email=? WHERE id=?', [$user['id'],$user['name'],$user['email'],$thread['id']]);
}

function chat_messages(int $threadId): array {
    return query(
        "SELECT id,sender,message,automated,created_at FROM chat_messages WHERE thread_id=? ORDER BY id ASC LIMIT 200",
        [$threadId]
    )->fetchAll();
}

function chat_product_match(string $message): ?array {
    $products = query('SELECT id,name,price_cents,stock FROM products WHERE active=1 AND deleted_at IS NULL ORDER BY CHAR_LENGTH(name) DESC')->fetchAll();
    $haystack = text_lower($message);
    foreach ($products as $product) {
        $name = text_lower((string)$product['name']);
        if ($name !== '' && text_position($haystack, $name) !== false) return $product;
    }
    return null;
}

function chatbot_reply(string $message): string {
    $text = text_lower(trim($message));

    if (preg_match('/\b(hi|hello|hey|bula|good morning|good afternoon|good evening)\b/u', $text)) {
        return 'Bula! I’m Ramina’s automated assistant. I can help with products, prices, stock, payment, pickup, orders and account questions. Your message is also saved for the owner to review.';
    }

    $product = null;
    if (preg_match('/\b(price|cost|how much|stock|available|availability|have|left)\b/u', $text)) {
        $product = chat_product_match($message);
    }

    if ($product && preg_match('/\b(price|cost|how much)\b/u', $text)) {
        return $product['name'].' is currently '.money($product['price_cents']).'. The owner can also reply here if you need more details.';
    }

    if ($product && preg_match('/\b(stock|available|availability|have|left)\b/u', $text)) {
        $stock = (int)$product['stock'];
        return $stock > 0
            ? $product['name'].' currently shows '.$stock.' in stock on the website. Stock can change as orders are placed.'
            : $product['name'].' is currently shown as sold out. Your question has still been sent to the owner.';
    }

    if (preg_match('/\b(mpaisa|m-paisa|payment|pay|cash|bank transfer|transfer)\b/u', $text)) {
        return online_payment_available() ? 'At checkout you can choose Cash on collection, Bank transfer, M-PAiSA or the available online-payment option. Online payments are marked Paid only after provider confirmation; bank and M-PAiSA payments still require owner verification.' : 'At checkout you can choose Cash on collection, Bank transfer or M-PAiSA. Bank and M-PAiSA payments are verified manually by the owner before the website marks them Paid.';
    }

    if (preg_match('/\b(order status|where is my order|track|tracking|reference|private code|receipt)\b/u', $text)) {
        return 'You can reopen an order from “Find order” using the order reference and private access code. Signed-in purchases also appear in My account. If you need the owner to check something specific, your message is already in the admin inbox.';
    }

    if (preg_match('/\b(deliver|delivery|shipping|ship)\b/u', $text)) {
        return 'The current website is set up for collection rather than automatic delivery. Ask the owner here if you need a special delivery arrangement.';
    }

    if (preg_match('/\b(location|address|where are you|opening|hours|open|pickup|pick up|collect|collection)\b/u', $text)) {
        $pickup=site_setting('pickup_information',''); $hours=site_setting('opening_hours','');
        if($pickup!=='') return 'Pickup information: '.$pickup.($hours!==''?' Hours: '.$hours:'').' Your exact collection date and time still need owner confirmation before you travel.';
        return 'Ramina’s Homemade Delights is based in Fiji. Pickup details are confirmed with each approved order, so please wait for the owner’s confirmed place, date and time before travelling.';
    }

    if (preg_match('/\b(allerg|ingredient|nuts|peanut|dairy|milk|gluten|egg)\b/u', $text)) {
        return 'Product pages list the available ingredient and allergen information. Please confirm allergies and cross-contact risks with the owner before purchasing.';
    }

    if (preg_match('/\b(account|register|login|log in|sign in|password)\b/u', $text)) {
        return 'An account is optional for checkout. Signing in lets you save contact details, view purchase history and leave reviews for completed purchases.';
    }

    if (preg_match('/\b(viber|message me|contact)\b/u', $text)) {
        return 'You can choose Viber as your contact preference and provide the number registered with Viber. Messages are sent manually by the owner, not automatically by the website.';
    }

    if (preg_match('/\b(product|products|sweets|menu|price|cost|how much|stock|available)\b/u', $text)) {
        return 'You can view the current sweets, prices and availability on the Products page. If you tell me the exact product name, I can try to give its current price or stock.';
    }

    if (preg_match('/\b(thank|thanks|thank you)\b/u', $text)) {
        return 'You’re welcome! Your conversation stays available here, and the owner can add a reply if needed.';
    }

    return 'Thanks for your question. I could not answer that confidently, so I’ve sent it to the owner/admin. You can keep this chat open or come back during this browser session to see their reply.';
}

function chat_rate_limit(): void {
    $now = time();
    $times = array_values(array_filter($_SESSION['chat_message_times'] ?? [], fn($t) => is_int($t) && $t > $now - 60));
    if (count($times) >= 8) throw new DomainException('Too many messages were sent at once. Please wait a moment and try again.');
    $times[] = $now;
    $_SESSION['chat_message_times'] = $times;
}

function chat_send_customer_message(string $rawMessage): array {
    chat_rate_limit();
    $message = valid_text(trim($rawMessage), 1000, 'Message');
    $thread = chat_thread(true);
    if (!$thread) throw new RuntimeException('Chat thread could not be created.');
    chat_sync_customer($thread);

    db()->beginTransaction();
    try {
        query(
            "INSERT INTO chat_messages (thread_id,sender,message,automated,seen_by_admin) VALUES (?,'customer',?,0,0)",
            [$thread['id'],$message]
        );
        query("UPDATE chat_threads SET status='Open',last_customer_at=NOW(),updated_at=NOW() WHERE id=?", [$thread['id']]);
        $reply = chatbot_reply($message);
        query(
            "INSERT INTO chat_messages (thread_id,sender,message,automated,seen_by_admin,seen_by_customer) VALUES (?,'bot',?,1,1,1)",
            [$thread['id'],$reply]
        );
        db()->commit();
    } catch (Throwable $e) {
        if (db()->inTransaction()) db()->rollBack();
        throw $e;
    }

    return chat_messages((int)$thread['id']);
}
