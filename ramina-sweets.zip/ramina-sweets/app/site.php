<?php
// Non-secret business settings editable from the owner dashboard.
function site_settings_all(bool $refresh=false): array {
    static $cache=null;
    if($refresh || $cache===null){
        try{
            $rows=query('SELECT setting_key,setting_value FROM site_settings')->fetchAll();
            $cache=[]; foreach($rows as $row) $cache[$row['setting_key']]=$row['setting_value'];
        }catch(Throwable $e){$cache=[];}
    }
    return $cache;
}
function site_setting(string $key,string $fallback=''): string {
    $settings=site_settings_all();
    return array_key_exists($key,$settings)?(string)$settings[$key]:$fallback;
}
function save_site_settings(array $values): void {
    db()->beginTransaction();
    try{
        foreach($values as $key=>$value){
            if(!preg_match('/^[a-z0-9_]{1,80}$/D',(string)$key)) throw new DomainException('Invalid setting key.');
            query('INSERT INTO site_settings (setting_key,setting_value) VALUES (?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)',[$key,(string)$value]);
        }
        db()->commit(); site_settings_all(true);
    }catch(Throwable $e){if(db()->inTransaction())db()->rollBack();throw $e;}
}
function safe_optional_https_url(string $value,string $label): string {
    $value=trim($value); if($value==='') return '';
    if(strlen($value)>500 || !filter_var($value,FILTER_VALIDATE_URL) || strtolower((string)parse_url($value,PHP_URL_SCHEME))!=='https') throw new DomainException($label.' must be a valid HTTPS link.');
    return $value;
}
