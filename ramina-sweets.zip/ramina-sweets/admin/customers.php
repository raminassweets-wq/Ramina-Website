<?php
require __DIR__.'/../app/bootstrap.php'; $owner=require_user(true);
$q=value('q',$_GET); $page=max(1,(int)(value('page',$_GET) ?: 1)); $per=20; $offset=($page-1)*$per;
$where="role='customer'";$params=[];
if($q!==''){ $where.=' AND (name LIKE ? OR email LIKE ? OR phone LIKE ?)'; $like='%'.$q.'%';$params=[$like,$like,$like]; }
$total=(int)one("SELECT COUNT(*) total FROM users WHERE $where",$params)['total'];
$rows=query("SELECT id,name,email,phone,account_status,created_at FROM users WHERE $where ORDER BY id DESC LIMIT $per OFFSET $offset",$params)->fetchAll();
page_header('Customers',true);
?>
<div class="section-heading"><div><p class="eyebrow">OWNER</p><h1>Customers</h1></div></div>
<form method="get" class="filter-bar"><label>Search customers<input name="q" value="<?= e($q) ?>" placeholder="Name, email or phone"></label><button class="button">Search</button><?php if($q!==''): ?><a class="text-link" href="customers.php">Clear</a><?php endif ?></form>
<div class="table-wrap"><table><thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Status</th><th>Joined</th><th></th></tr></thead><tbody><?php foreach($rows as $r): ?><tr><td><?= e($r['name']) ?></td><td><?= e($r['email']) ?></td><td><?= e($r['phone']) ?></td><td><?= e($r['account_status']) ?></td><td><?= e($r['created_at']) ?></td><td><a class="text-link" href="customer-edit.php?id=<?= (int)$r['id'] ?>">Manage</a></td></tr><?php endforeach ?></tbody></table></div>
<?php if(!$rows): ?><p>No customers found.</p><?php endif ?>
<?php if($total>$per): ?><nav class="pagination" aria-label="Customer pages"><?php for($i=1;$i<=ceil($total/$per);$i++): ?><a <?= $i===$page?'aria-current="page"':'' ?> href="?q=<?= urlencode($q) ?>&page=<?= $i ?>"><?= $i ?></a><?php endfor ?></nav><?php endif ?>
<?php page_footer(); ?>
