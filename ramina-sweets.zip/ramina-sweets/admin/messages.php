<?php
require __DIR__.'/../app/bootstrap.php';
$owner=require_user(true);
$status=value('status',$_GET); $q=text_slice(value('q',$_GET),0,100);
$allowed=['','Open','Answered','Closed']; if(!in_array($status,$allowed,true)) $status='';
$page=max(1,(int)(value('page',$_GET) ?: 1)); $per=30; $offset=($page-1)*$per;
$where=[]; $params=[];
if($status!==''){ $where[]='t.status=?'; $params[]=$status; }
if($q!==''){ $where[]='(t.customer_name LIKE ? OR t.customer_email LIKE ? OR u.name LIKE ? OR u.email LIKE ?)'; $like='%'.$q.'%'; array_push($params,$like,$like,$like,$like); }
$whereSql=$where?' WHERE '.implode(' AND ',$where):'';
$total=(int)(one('SELECT COUNT(*) total FROM chat_threads t LEFT JOIN users u ON u.id=t.user_id'.$whereSql,$params)['total'] ?? 0);
$sql="SELECT t.*,u.name account_name,u.email account_email,
    COALESCE(m.unread_count,0) unread_count,COALESCE(m.message_count,0) message_count
    FROM chat_threads t
    LEFT JOIN users u ON u.id=t.user_id
    LEFT JOIN (
        SELECT thread_id,SUM(sender='customer' AND seen_by_admin=0) unread_count,COUNT(*) message_count
        FROM chat_messages GROUP BY thread_id
    ) m ON m.thread_id=t.id".$whereSql.
    ' ORDER BY (unread_count>0) DESC,t.updated_at DESC,t.id DESC LIMIT '.$per.' OFFSET '.$offset;
$threads=query($sql,$params)->fetchAll();
page_header('Customer messages',true);
?>
<p class="eyebrow">CUSTOMER SUPPORT</p>
<div class="section-heading"><div><h1>Customer messages</h1><p>Every chatbot question appears here. Open a conversation to send a personal reply.</p></div><span class="system-pill <?= $total?'good':'warn' ?>"><?= $total ?> conversation<?= $total===1?'':'s' ?></span></div>
<form method="get" class="filter-form">
<label>Search<input name="q" maxlength="100" value="<?= e($q) ?>" placeholder="Customer name or email"></label>
<label>Status<select name="status"><option value="">All statuses</option><?php foreach(['Open','Answered','Closed'] as $s): ?><option value="<?= e($s) ?>" <?= $status===$s?'selected':'' ?>><?= e($s) ?></option><?php endforeach ?></select></label>
<button class="button">Filter</button><?php if($status!==''||$q!==''): ?><a class="text-link" href="messages.php">Clear</a><?php endif ?>
</form>
<?php if(!$threads): ?><p class="notice">No customer conversations match this filter yet.</p><?php endif ?>
<div class="table-wrap"><table>
<thead><tr><th>Customer</th><th>Status</th><th>Messages</th><th>Last activity</th><th>Action</th></tr></thead>
<tbody>
<?php foreach($threads as $thread):
$name=$thread['customer_name'] ?: ($thread['account_name'] ?? '') ?: 'Guest customer';
$email=$thread['customer_email'] ?: ($thread['account_email'] ?? ''); ?>
<tr class="<?= (int)$thread['unread_count']>0?'message-unread':'' ?>">
<td><strong><?= e($name) ?></strong><?php if($email): ?><br><small><?= e($email) ?></small><?php endif ?><?php if((int)$thread['unread_count']>0): ?><br><span class="badge"><?= (int)$thread['unread_count'] ?> new</span><?php endif ?></td>
<td><span class="status-badge <?= $thread['status']==='Open'?'status-warn':($thread['status']==='Answered'?'status-good':'status-neutral') ?>"><?= e($thread['status']) ?></span></td>
<td><?= (int)$thread['message_count'] ?></td>
<td><?= e($thread['updated_at']) ?></td>
<td><a class="button" href="chat.php?id=<?= (int)$thread['id'] ?>">Open chat</a></td>
</tr>
<?php endforeach ?>
</tbody></table></div>
<?php if($total>$per): ?><nav class="pagination" aria-label="Message pages"><?php for($i=1,$pages=(int)ceil($total/$per);$i<=$pages;$i++): ?><a <?= $i===$page?'aria-current="page"':'' ?> href="?q=<?= urlencode($q) ?>&status=<?= urlencode($status) ?>&page=<?= $i ?>"><?= $i ?></a><?php endfor ?></nav><?php endif ?>
<?php page_footer(); ?>
