<?php
require __DIR__.'/../app/bootstrap.php';require_user(true);
$from=value('from',$_GET);$to=value('to',$_GET);$valid=function($d){$x=DateTimeImmutable::createFromFormat('!Y-m-d',$d);return $x&&$x->format('Y-m-d')===$d;};if(!$valid($from)||!$valid($to)||$from>$to){http_response_code(400);exit('Invalid date range.');}
$rows=query("SELECT o.public_reference,o.customer_name,o.customer_email,o.status,p.method,p.status payment_status,o.total_cents,o.created_at FROM orders o JOIN payments p ON p.order_id=o.id WHERE DATE(o.created_at) BETWEEN ? AND ? ORDER BY o.id",[$from,$to])->fetchAll();
header('Content-Type: text/csv; charset=UTF-8');header('Content-Disposition: attachment; filename="ramina-sales-'.$from.'-to-'.$to.'.csv"');
$out=fopen('php://output','w');fwrite($out,"\xEF\xBB\xBF");fputcsv($out,['Order','Customer','Email','Order status','Payment method','Payment status','Total FJD','Created']);
$clean=function($v){$s=(string)$v;return preg_match('/^[=+\-@]/',$s)?"'".$s:$s;};foreach($rows as $r)fputcsv($out,[$clean($r['public_reference']),$clean($r['customer_name']),$clean($r['customer_email']),$r['status'],$r['method'],$r['payment_status'],number_format($r['total_cents']/100,2,'.',''),$r['created_at']]);fclose($out);exit;
