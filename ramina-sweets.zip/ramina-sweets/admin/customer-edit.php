<?php
require __DIR__.'/../app/bootstrap.php'; $owner=require_user(true);$error=null;$id=filter_var(value('id',$_GET),FILTER_VALIDATE_INT) ?: 0;
$customer=one("SELECT * FROM users WHERE id=? AND role='customer'",[$id]); if(!$customer){http_response_code(404);exit('Customer not found.');}
if(post()){
 check_csrf();
 try{
   $name=valid_text(value('name'),80,'Name');$email=strtolower(value('email'));$emailChanged=$email!==$customer['email'];if(!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($email)>190)throw new DomainException('Enter a valid email.');
   $phone=contact_number(value('phone'),'Phone');$mpaisa=contact_number(value('mpaisa_number'),'M-PAiSA number');$viber=contact_number(value('viber_number'),'Viber number');$pref=contact_preference(value('contact_preference'),$viber);$status=value('account_status');
   if(!in_array($status,['Active','Inactive'],true))throw new DomainException('Choose a valid account status.');
   query('UPDATE users SET name=?,email=?,phone=?,mpaisa_number=?,viber_number=?,contact_preference=?,account_status=?,email_verified_at=IF(?,NULL,email_verified_at),session_version=session_version+? WHERE id=?',[$name,$email,$phone,$mpaisa,$viber,$pref,$status,$emailChanged?1:0,$status!==$customer['account_status']?1:0,$id]);
   if($emailChanged && $status==='Active') issue_email_verification($id,$email,$name);
   query('INSERT INTO account_events (customer_id,actor_id,action) VALUES (?,?,?)',[$id,$owner['id'],'Owner updated customer profile/status to '.$status]);
   flash('Customer account updated.');redirect('admin/customer-edit.php?id='.$id);
 }catch(DomainException $e){$error=$e->getMessage();}catch(PDOException $e){if($e->getCode()==='23000')$error='That email is already used by another account.';else throw $e;}
}
$customer=one("SELECT * FROM users WHERE id=?",[$id]);$orders=query('SELECT id,public_reference,status,total_cents,created_at FROM orders WHERE user_id=? ORDER BY id DESC LIMIT 20',[$id])->fetchAll();$events=query('SELECT ae.*,u.name actor_name FROM account_events ae JOIN users u ON u.id=ae.actor_id WHERE ae.customer_id=? ORDER BY ae.id DESC LIMIT 20',[$id])->fetchAll();
page_header('Manage customer',true);
?>
<a class="text-link" href="customers.php">← Customers</a><h1><?= e($customer['name']) ?></h1><?php error_box($error); ?>
<div class="account-grid"><section class="form-card"><h2>Account details</h2><form method="post"><?= csrf() ?><label>Name<input name="name" required maxlength="80" value="<?= e($customer['name']) ?>"></label><label>Email<input name="email" type="email" required maxlength="190" value="<?= e($customer['email']) ?>"></label><label>Phone<input name="phone" maxlength="30" value="<?= e($customer['phone']) ?>"></label><label>M-PAiSA<input name="mpaisa_number" maxlength="30" value="<?= e($customer['mpaisa_number']) ?>"></label><label>Viber<input name="viber_number" maxlength="30" value="<?= e($customer['viber_number']) ?>"></label><label>Preferred contact<select name="contact_preference"><?php foreach(['Phone','Viber'] as $x): ?><option <?= $customer['contact_preference']===$x?'selected':'' ?>><?= $x ?></option><?php endforeach ?></select></label><label>Account status<select name="account_status"><?php foreach(['Active','Inactive'] as $x): ?><option <?= $customer['account_status']===$x?'selected':'' ?>><?= $x ?></option><?php endforeach ?></select></label><p class="muted">Deactivating prevents future authenticated actions and invalidates existing sessions. Historical orders and reviews are preserved.</p><button class="button">Save customer</button></form></section>
<section class="form-card"><h2>Recent orders</h2><?php foreach($orders as $o): ?><div class="summary-row"><span><a href="order.php?id=<?= (int)$o['id'] ?>"><?= e($o['public_reference']) ?></a><small class="block"><?= e($o['status']) ?> · <?= e($o['created_at']) ?></small></span><strong><?= money($o['total_cents']) ?></strong></div><?php endforeach ?><?php if(!$orders): ?><p>No orders yet.</p><?php endif ?></section></div>
<section class="form-card spaced"><h2>Account audit</h2><?php if(!$events): ?><p>No owner account changes recorded.</p><?php else: ?><ol class="timeline"><?php foreach($events as $ev): ?><li><?= e($ev['action']) ?><small class="block"><?= e($ev['actor_name']) ?> · <?= e($ev['created_at']) ?></small></li><?php endforeach ?></ol><?php endif ?></section>
<?php page_footer(); ?>
