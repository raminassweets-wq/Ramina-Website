<?php
require __DIR__.'/../app/bootstrap.php'; require_user(true); $error=null; $uploaded=null;
$id=filter_var(value('id',$_GET),FILTER_VALIDATE_INT) ?: 0;
$p=$id?one('SELECT p.*,c.name category_name FROM products p JOIN categories c ON c.id=p.category_id WHERE p.id=? AND p.deleted_at IS NULL',[$id]):['name'=>'','category_name'=>'','description'=>'','image_path'=>'','price_cents'=>0];
if (!$p) { http_response_code(404); exit('Product not found.'); }
// PHP discards the entire form when its post size limit is exceeded.
$tooLarge=post() && empty($_POST) && (int)($_SERVER['CONTENT_LENGTH'] ?? 0)>0;
if ($tooLarge) $error='The uploaded picture is too large. Choose a JPG, PNG or WebP under 2 MB and try again.';
if (post() && !$tooLarge) {
    check_csrf();
    try {
        $name=valid_text(value('name'),100,'Product name');
        $categoryName=valid_text(value('category'),80,'Product category');
        $description=valid_text(value('description'),3000,'Brief description');
        $price=cents(value('price'));
        $uploaded=upload_product_picture(!$id);
        db()->beginTransaction();
        if ($id) {
            $latest=one('SELECT p.*,c.name category_name FROM products p JOIN categories c ON c.id=p.category_id WHERE p.id=? AND p.deleted_at IS NULL FOR UPDATE',[$id]);
            if (!$latest || !hash_equals(hash('sha256',json_encode($latest)),value('version'))) throw new DomainException('This product changed while you were editing. Reload before saving.');
        }
        // Reuse an existing category, or create the name typed by the owner.
        query('INSERT INTO categories (name) VALUES (?) ON DUPLICATE KEY UPDATE id=LAST_INSERT_ID(id)',[$categoryName]);
        $category=(int)db()->lastInsertId();
        if ($id) {
            query('UPDATE products SET category_id=?,name=?,description=?,price_cents=?,image_path=? WHERE id=?',[$category,$name,$description,$price,$uploaded ?? $p['image_path'],$id]);
        } else {
            // A draft never invents inventory or ingredient/allergen claims.
            query("INSERT INTO products (category_id,name,description,image_path,pack_size,ingredients,allergens,price_cents,stock,low_stock_threshold,active) VALUES (?,?,?,?,'Per item','','',?,0,5,0)",[$category,$name,$description,$uploaded,$price]);
            $createdId=(int)db()->lastInsertId();
        }
        db()->commit(); $uploaded=null;
        flash($id?'Product updated.':'Product saved. Set the available quantity and tick Show this product in the shop when you are ready to sell.');
        redirect($id?'admin/products.php':'admin/product-stock.php?id='.$createdId);
    } catch(DomainException $ex) { if(db()->inTransaction())db()->rollBack(); discard_product_picture($uploaded); $error=$ex->getMessage(); }
    catch(Throwable $ex) { if(db()->inTransaction())db()->rollBack(); discard_product_picture($uploaded); throw $ex; }
}
function field(string $key,array $p): string { return post()?value($key):(string)($p[$key] ?? ''); }
page_header($id?'Edit product':'Add product',true);
?>
<section class="form-card product-editor">
<h1><?= $id?'Edit product':'Add product' ?></h1>
<p>Just the basics. You can manage stock and extra details separately.</p>
<?php if($id): ?><p><a class="text-link" href="product-stock.php?id=<?= $id ?>">Change stock or show/hide this product</a></p><?php endif ?>
<?php error_box($error); ?>
<form method="post" enctype="multipart/form-data">
<?= csrf() ?>
<input type="hidden" name="version" value="<?= e(post()?value('version'):hash('sha256',json_encode($p))) ?>">
<label>Product Name<input name="name" required maxlength="100" value="<?= e(field('name',$p)) ?>" placeholder="Example: Coconut sweets"></label>
<label>Product category<input name="category" list="category-options" required maxlength="80" value="<?= e(post()?value('category'):$p['category_name']) ?>" placeholder="Choose or type a category"></label>
<datalist id="category-options"><?php foreach(query('SELECT name FROM categories ORDER BY name')->fetchAll() as $c): ?><option value="<?= e($c['name']) ?>"><?php endforeach ?></datalist>
<label>Picture of the product<input name="picture" type="file" accept="image/jpeg,image/png,image/webp" <?= $id?'':'required' ?>></label>
<p class="muted">JPG, PNG or WebP, up to 2 MB. <?= $id?'Leave empty to keep the current picture.':'' ?></p>
<?php if($id): ?><img class="product-photo-preview" src="<?= e(url(product_picture($p))) ?>" alt="<?= e($p['name']) ?>"><?php endif ?>
<label>Price (FJD)<input name="price" type="number" required min="0.01" max="10000" step="0.01" value="<?= e(post()?value('price'):($id?number_format($p['price_cents']/100,2,'.',''):'')) ?>" placeholder="Example: 12.00"></label>
<label>Brief description<textarea name="description" required maxlength="3000" rows="3" placeholder="Tell customers what they will receive."><?= e(field('description',$p)) ?></textarea></label>
<div class="actions"><button class="button">Save product</button><a class="text-link" href="products.php">Cancel</a></div>
</form>
</section>
<?php page_footer(); ?>
