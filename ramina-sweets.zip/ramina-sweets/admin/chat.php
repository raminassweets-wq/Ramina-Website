<?php
require __DIR__.'/../app/bootstrap.php';
$owner=require_user(true);
$id=filter_var(value('id',$_GET),FILTER_VALIDATE_INT) ?: 0;
$thread=one('SELECT t.*,u.name account_name,u.email account_email FROM chat_threads t LEFT JOIN users u ON u.id=t.user_id WHERE t.id=?',[$id]);
if(!$thread){ http_response_code(404); page_header('Conversation not found',true); echo '<h1>Conversation not found</h1><p><a class="text-link" href="messages.php">← Back to messages</a></p>'; page_footer(); exit; }
$error=null;
if(post()){
    try{
        check_csrf();
        $action=value('action');
        if($action==='reply'){
            $message=valid_text(value('message'),1000,'Reply');
            query("INSERT INTO chat_messages (thread_id,sender,message,automated,seen_by_admin,seen_by_customer) VALUES (?,'admin',?,0,1,0)",[$id,$message]);
            query("UPDATE chat_threads SET status='Answered',last_admin_at=NOW(),updated_at=NOW() WHERE id=?",[$id]);
            $recipient=$thread['customer_email'] ?: ($thread['account_email'] ?? '');
            $recipientName=$thread['customer_name'] ?: ($thread['account_name'] ?? 'Customer');
            $emailSent=$recipient!=='' ? send_support_reply_email($recipient,$recipientName,$message) : false;
            flash('Reply saved. '.($emailSent?'An email notification was also accepted for delivery.':($recipient!==''?'The email notification is queued or unavailable; the reply is still visible in chat.':'This guest did not provide an account email, so the reply is available in chat only.')));
            redirect('admin/chat.php?id='.$id);
        }
        if($action==='status'){
            $new=value('status');
            if(!in_array($new,['Open','Answered','Closed'],true)) throw new DomainException('Choose a valid conversation status.');
            query('UPDATE chat_threads SET status=?,updated_at=NOW() WHERE id=?',[$new,$id]);
            flash('Conversation status updated.');
            redirect('admin/chat.php?id='.$id);
        }
        throw new DomainException('Unknown action.');
    } catch(DomainException $e){ $error=$e->getMessage(); }
}
query("UPDATE chat_messages SET seen_by_admin=1 WHERE thread_id=? AND sender='customer'",[$id]);
$thread=one('SELECT t.*,u.name account_name,u.email account_email FROM chat_threads t LEFT JOIN users u ON u.id=t.user_id WHERE t.id=?',[$id]);
$messages=query('SELECT * FROM chat_messages WHERE thread_id=? ORDER BY id ASC',[$id])->fetchAll();
$name=$thread['customer_name'] ?: ($thread['account_name'] ?? '') ?: 'Guest customer';
$email=$thread['customer_email'] ?: ($thread['account_email'] ?? '');
page_header('Customer conversation',true);
?>
<a class="text-link" href="messages.php">← Back to customer messages</a>
<div class="section-heading"><div><p class="eyebrow">CUSTOMER SUPPORT</p><h1><?= e($name) ?></h1><p><?= $email?e($email).' · ':'' ?>Status: <strong><?= e($thread['status']) ?></strong></p></div></div>
<?php error_box($error); ?>
<section class="admin-chat-log" aria-label="Conversation">
<?php foreach($messages as $message): ?>
<article class="admin-chat-message sender-<?= e($message['sender']) ?>">
<header><strong><?= $message['sender']==='customer'?e($name):($message['sender']==='admin'?'Ramina’s team':'Automated assistant') ?></strong><?php if($message['automated']): ?> <span class="badge">Automatic</span><?php endif ?></header>
<p><?= nl2br(e($message['message'])) ?></p><small><?= e($message['created_at']) ?></small>
</article>
<?php endforeach ?>
</section>
<div class="admin-chat-actions">
<form method="post" class="form-card">
<?= csrf() ?><input type="hidden" name="action" value="reply">
<h2>Reply to customer</h2>
<label>Message<textarea name="message" rows="5" maxlength="1000" required placeholder="Type your reply here..."><?= e(value('message')) ?></textarea></label>
<button class="button">Send reply</button>
<p class="muted">Signed-in customers can reopen their conversation from their account on another browser. When an email is available, the website also attempts to send a reply notification.</p>
</form>
<form method="post" class="form-card">
<?= csrf() ?><input type="hidden" name="action" value="status">
<h2>Conversation status</h2>
<label>Status<select name="status"><?php foreach(['Open','Answered','Closed'] as $option): ?><option value="<?= $option ?>" <?= $thread['status']===$option?'selected':'' ?>><?= $option ?></option><?php endforeach ?></select></label>
<button class="secondary-button">Update status</button>
</form>
</div>
<?php page_footer(); ?>
