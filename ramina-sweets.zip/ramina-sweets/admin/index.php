<?php
require __DIR__.'/../app/bootstrap.php';
$owner=require_user(true);
$orderStats=one("SELECT COUNT(*) total_orders,COALESCE(SUM(status='Pending'),0) pending_orders,COALESCE(SUM(status='Approved'),0) approved_orders FROM orders");
$productStats=one("SELECT COUNT(*) products,COALESCE(SUM(active=1 AND deleted_at IS NULL AND stock<=low_stock_threshold),0) low_stock FROM products WHERE deleted_at IS NULL");
$customerStats=one("SELECT COUNT(*) customers FROM users WHERE role='customer'");
$messageStats=one("SELECT COUNT(*) unread FROM chat_messages WHERE sender='customer' AND seen_by_admin=0");
$revenue=one("SELECT COALESCE(SUM(CASE WHEN p.status='Paid' AND o.status<>'Cancelled' THEN o.total_cents ELSE 0 END),0) paid_total FROM orders o JOIN payments p ON p.order_id=o.id");
$refunds=one("SELECT COUNT(*) total FROM orders o JOIN payments p ON p.order_id=o.id WHERE o.status='Cancelled' AND p.status='Paid'");
$low=query('SELECT * FROM products WHERE active=1 AND deleted_at IS NULL AND stock<=low_stock_threshold ORDER BY stock,id LIMIT 6')->fetchAll();
$recent=query('SELECT o.*,p.status payment_status,p.method FROM orders o JOIN payments p ON p.order_id=o.id ORDER BY o.id DESC LIMIT 7')->fetchAll();
$mail=mail_config();
$smtpReady=smtp_credentials_ready($mail);
$emailReady=($mail['transport']==='smtp' && $smtpReady) || ($mail['transport']==='auto' && ($smtpReady || (!mail_local_request() && function_exists('mail')))) || ($mail['transport']==='mail' && !mail_local_request() && function_exists('mail'));
$mailQueue=queued_email_count();
page_header('Owner overview',true);
?>
<div class="admin-page-heading">
<div><p class="eyebrow">OWNER DASHBOARD</p><h1>Good to see you, <?= e(explode(' ',trim($owner['name']))[0] ?: 'Owner') ?>.</h1><p>Here’s what is happening across orders, customers and stock.</p></div>
<div class="dashboard-heading-actions"><a class="secondary-button" href="settings.php">System health</a><a class="button" href="product-edit.php">+ Add product</a></div>
</div>

<div class="dashboard-metrics">
<article class="metric-card"><span class="metric-icon">🧾</span><div><small>Total orders</small><strong><?= (int)$orderStats['total_orders'] ?></strong><a href="orders.php">View orders →</a></div></article>
<article class="metric-card"><span class="metric-icon">⏳</span><div><small>Awaiting review</small><strong><?= (int)$orderStats['pending_orders'] ?></strong><a href="orders.php">Process orders →</a></div></article>
<article class="metric-card"><span class="metric-icon">💰</span><div><small>Currently paid</small><strong><?= money((int)$revenue['paid_total']) ?></strong><a href="reports.php">Open reports →</a></div></article>
<article class="metric-card"><span class="metric-icon">👥</span><div><small>Customers</small><strong><?= (int)$customerStats['customers'] ?></strong><a href="customers.php">Manage customers →</a></div></article>
<article class="metric-card"><span class="metric-icon">💬</span><div><small>Unread messages</small><strong><?= (int)$messageStats['unread'] ?></strong><a href="messages.php">Open inbox →</a></div></article>
<article class="metric-card"><span class="metric-icon">📦</span><div><small>Low-stock items</small><strong><?= (int)$productStats['low_stock'] ?></strong><a href="products.php">Update stock →</a></div></article>
</div>

<?php if ($refunds['total']): ?><p class="notice error"><strong>Action needed:</strong> <?= (int)$refunds['total'] ?> cancelled order(s) are still recorded as Paid. Review and refund them where required.</p><?php endif ?>

<div class="dashboard-two-column">
<section class="dashboard-panel">
<div class="section-heading"><div><p class="eyebrow">LATEST ACTIVITY</p><h2>Recent orders</h2></div><a class="text-link" href="orders.php">All orders →</a></div>
<?php if(!$recent): ?><p class="muted">No orders yet.</p><?php else: ?><div class="table-wrap clean-table"><table><thead><tr><th>Order</th><th>Customer</th><th>Order</th><th>Payment</th><th>Total</th></tr></thead><tbody><?php foreach($recent as $o): ?><tr><td><a class="text-link strong-link" href="order.php?id=<?= (int)$o['id'] ?>"><?= e($o['public_reference']) ?></a><small class="block"><?= e(date('d M Y',strtotime($o['created_at']))) ?></small></td><td><?= e($o['customer_name']) ?></td><td><span class="status-badge status-<?= strtolower($o['status']) ?>"><?= e($o['status']) ?></span></td><td><span class="status-badge <?= $o['payment_status']==='Paid'?'status-good':($o['payment_status']==='Refunded'?'status-neutral':'status-warn') ?>"><?= e($o['payment_status']) ?></span></td><td><strong><?= money($o['total_cents']) ?></strong></td></tr><?php endforeach ?></tbody></table></div><?php endif ?>
</section>

<aside class="dashboard-side-stack">
<section class="dashboard-panel">
<div class="section-heading"><div><p class="eyebrow">STOCK WATCH</p><h2>Low stock</h2></div></div>
<?php if(!$low): ?><div class="mini-success">✓ All published products are above their alert levels.</div><?php else: ?><div class="low-stock-list"><?php foreach($low as $p): ?><a href="product-stock.php?id=<?= (int)$p['id'] ?>"><span><strong><?= e($p['name']) ?></strong><small><?= (int)$p['stock'] ?> left · alert at <?= (int)$p['low_stock_threshold'] ?></small></span><b>Update →</b></a><?php endforeach ?></div><?php endif ?>
</section>
<section class="dashboard-panel system-health-panel">
<div class="section-heading"><div><p class="eyebrow">SYSTEM HEALTH</p><h2>Customer services</h2></div></div>
<div class="health-row"><span><i class="health-dot <?= $emailReady?'good':'warn' ?>"></i> Email delivery</span><strong><?= $emailReady?'Delivery path ready':'Needs provider' ?></strong></div>
<div class="health-row"><span><i class="health-dot <?= $mailQueue===0?'good':'warn' ?>"></i> Email queue</span><strong><?= (int)$mailQueue ?> waiting</strong></div>
<div class="health-row"><span><i class="health-dot good"></i> Separate sessions</span><strong>Active</strong></div>
<div class="health-row"><span><i class="health-dot <?= online_payment_mode()==='paypal'?'good':'warn' ?>"></i> Online payment</span><strong><?= e(ucfirst(online_payment_mode())) ?></strong></div>
<a class="secondary-button wide" href="settings.php">Open system settings</a>
</section>
</aside>
</div>
<?php page_footer(); ?>
