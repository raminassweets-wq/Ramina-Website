<?php
require __DIR__.'/../app/bootstrap.php'; require_user(true);
$id=filter_var(value('id',$_GET),FILTER_VALIDATE_INT) ?: 0;
$p=one('SELECT * FROM products WHERE id=? AND deleted_at IS NULL',[$id]);
if (!$p) { http_response_code(404); exit('Product not found.'); }
if (post()) { check_csrf(); query('UPDATE products SET active=0,deleted_at=NOW() WHERE id=?',[$id]); flash('Product deleted from the catalogue. Previous orders and reviews are preserved.'); redirect('admin/products.php'); }
page_header('Delete product',true);
?>
<section class="form-card narrow">
<h1>Delete product?</h1>
<p>Remove <strong>
<?= e($p['name']) ?>
</strong> from the shop and inventory list?</p>
<p>The database keeps a historical record for orders and reviews. This cannot be undone through the dashboard.</p>
<form method="post">
<?= csrf() ?>
<div class="actions">
<button class="danger-button">Delete product</button>
<a class="text-link" href="products.php">Keep product</a>
</div>
</form>
</section>
<?php page_footer(); ?>
