<?php
require __DIR__.'/../app/bootstrap.php'; require_user(true); $error=null;
$id=filter_var(value('id',$_GET),FILTER_VALIDATE_INT) ?: 0;
$p=one('SELECT * FROM products WHERE id=? AND deleted_at IS NULL',[$id]);
if(!$p){http_response_code(404);exit('Product not found.');}
if(post()) {
    check_csrf();
    try {
        $stock=integer(value('stock'),0,100000,'Available quantity');
        $threshold=integer(value('threshold'),0,100000,'Low-stock alert');
        $pack=valid_text(value('pack_size'),80,'Selling unit',false) ?: 'Per item';
        $ingredients=valid_text(value('ingredients'),2000,'Ingredients',false);
        $allergens=valid_text(value('allergens'),2000,'Allergens',false);
        $active=value('active')==='1'?1:0;
        if($active && $stock===0 && !$p['active']) throw new DomainException('Enter an available quantity greater than zero before publishing, or leave the product hidden.');
        db()->beginTransaction();
        $latest=one('SELECT * FROM products WHERE id=? AND deleted_at IS NULL FOR UPDATE',[$id]);
        if(!$latest || !hash_equals(hash('sha256',json_encode($latest)),value('version'))) throw new DomainException('This product or its stock changed. Reload before saving so an order is not overwritten.');
        query('UPDATE products SET stock=?,low_stock_threshold=?,pack_size=?,ingredients=?,allergens=?,active=? WHERE id=?',[$stock,$threshold,$pack,$ingredients,$allergens,$active,$id]);
        db()->commit();flash('Stock and extra details saved.');redirect('admin/products.php');
    } catch(DomainException $ex){if(db()->inTransaction())db()->rollBack();$error=$ex->getMessage();}
    catch(Throwable $ex){if(db()->inTransaction())db()->rollBack();throw $ex;}
}
function stock_field(string $key,array $p): string {return post()?value($key):(string)$p[$key];}
page_header('Stock & details',true);
?>
<section class="form-card product-editor">
<a class="text-link" href="products.php">Back to products</a>
<h1>Stock & details</h1><p><?= e($p['name']) ?></p>
<?php if(!$p['stock']): ?><p class="notice">This product has no available stock. Enter the quantity you can sell, then tick Show this product in the shop.</p><?php endif ?>
<?php error_box($error); ?>
<form method="post"><?= csrf() ?>
<input type="hidden" name="version" value="<?= e(post()?value('version'):hash('sha256',json_encode($p))) ?>">
<label>Available quantity<input name="stock" type="number" min="0" max="100000" required value="<?= e(stock_field('stock',$p)) ?>"></label>
<p class="muted">Enter how many you can sell now. Orders automatically reduce this number.</p>
<label class="check-label"><input name="active" type="checkbox" value="1" <?= (post()?value('active')==='1':$p['active'])?'checked':'' ?>> Show this product in the shop</label>
<details><summary>Extra details (optional)</summary>
<label>Selling unit<input name="pack_size" maxlength="80" value="<?= e(stock_field('pack_size',$p)) ?>" placeholder="Example: Box of 6"></label>
<label>Low-stock alert<input name="threshold" type="number" min="0" max="100000" required value="<?= e(post()?value('threshold'):$p['low_stock_threshold']) ?>"></label>
<label>Ingredients<textarea name="ingredients" rows="3" maxlength="2000"><?= e(stock_field('ingredients',$p)) ?></textarea></label>
<label>Allergen information<textarea name="allergens" rows="3" maxlength="2000"><?= e(stock_field('allergens',$p)) ?></textarea></label>
<p class="muted">Only enter information you have checked. When blank, customers are asked to contact you.</p>
</details>
<button class="button">Save stock & details</button>
</form>
</section>
<?php page_footer(); ?>
