<?php
require __DIR__.'/../app/bootstrap.php'; require_user(true);
$filter=value('status',$_GET); $q=text_slice(value('q',$_GET),0,100);
$page=max(1,(int)(value('page',$_GET) ?: 1)); $per=30; $offset=($page-1)*$per;
$where='1=1'; $params=[];
if(in_array($filter,['Pending','Approved','Completed','Cancelled'],true)) { $where.=' AND o.status=?';$params[]=$filter; }
if($q!=='') {
    $where.=' AND (o.customer_name LIKE ? OR o.customer_email LIKE ? OR o.public_reference LIKE ? OR p.reference LIKE ? OR p.customer_reference LIKE ?)';
    $like='%'.$q.'%'; array_push($params,$like,$like,$like,$like,$like);
}
$total=(int)(one('SELECT COUNT(*) total FROM orders o JOIN payments p ON p.order_id=o.id WHERE '.$where,$params)['total'] ?? 0);
$orders=query('SELECT o.*,p.status payment_status,p.submitted_at,p.reference payment_reference,p.customer_reference FROM orders o JOIN payments p ON p.order_id=o.id WHERE '.$where.' ORDER BY o.id DESC LIMIT '.$per.' OFFSET '.$offset,$params)->fetchAll();
page_header('Manage orders',true);
?>
<div class="section-heading"><div><p class="eyebrow">FULFILMENT</p><h1>Orders & payments</h1><p><?= $total ?> order<?= $total===1?'':'s' ?> match this view.</p></div></div>
<form class="filter-form" method="get">
<label>Search order, customer or payment reference<input name="q" maxlength="100" value="<?= e($q) ?>" placeholder="RS-…, name, email or transaction reference"></label>
<label>Status<select name="status">
<option value="">All statuses</option>
<?php foreach(['Pending','Approved','Completed','Cancelled'] as $s): ?><option value="<?= e($s) ?>" <?= $filter===$s?'selected':'' ?>><?= e($s) ?></option><?php endforeach ?>
</select></label>
<button class="button">Filter orders</button><?php if($q!==''||$filter!==''): ?><a class="text-link" href="orders.php">Clear</a><?php endif ?>
</form>
<div class="table-wrap"><table>
<thead><tr><th>Order</th><th>Customer</th><th>Collection</th><th>Status</th><th>Payment</th><th>Total</th></tr></thead>
<tbody>
<?php foreach($orders as $o): ?>
<tr>
<td><a class="text-link" href="order.php?id=<?= (int)$o['id'] ?>"><?= e($o['public_reference']) ?> · Manage</a><small class="block"><?= e($o['created_at']) ?></small></td>
<td><?= e($o['customer_name']) ?><small class="block"><?= e($o['customer_email']) ?></small></td>
<td><?= e($o['confirmed_date'] ?: $o['collection_date']) ?><small class="block"><?= $o['confirmed_date']?'Confirmed '.e(substr((string)$o['confirmed_time'],0,5)):'Requested' ?></small></td>
<td><span class="status-pill status-<?= e(strtolower($o['status'])) ?>"><?= e($o['status']) ?></span></td>
<td><strong><?= e($o['payment_status']) ?></strong><?php if($o['submitted_at'] && $o['payment_status']==='Unpaid' && $o['status']!=='Cancelled'): ?><small class="block">Details submitted — verify payment</small><?php endif ?><?php if($o['payment_reference']): ?><small class="block">Ref: <?= e($o['payment_reference']) ?></small><?php endif ?></td>
<td><?= money($o['total_cents']) ?></td>
</tr>
<?php endforeach ?>
</tbody></table></div>
<?php if(!$orders): ?><p class="notice">No orders match this view.</p><?php endif ?>
<?php if($total>$per): ?><nav class="pagination" aria-label="Order pages"><?php for($i=1,$pages=(int)ceil($total/$per);$i<=$pages;$i++): ?><a <?= $i===$page?'aria-current="page"':'' ?> href="?q=<?= urlencode($q) ?>&status=<?= urlencode($filter) ?>&page=<?= $i ?>"><?= $i ?></a><?php endfor ?></nav><?php endif ?>
<?php page_footer(); ?>
