<?php
require __DIR__.'/../app/bootstrap.php'; $owner=require_user(true); $error=null;
$id=filter_var(value('id',$_GET),FILTER_VALIDATE_INT) ?: 0;
if (post()) {
    check_csrf();
    try {
        if(value('action')==='collection') {
            confirm_collection($id,$owner,value('confirmed_date'),value('confirmed_time'));
            flash('Collection confirmed. Send the updated details to the customer.');
        } elseif(value('action')==='viber_sent') {
            if(value('sent_confirmed')!=='1') throw new DomainException('Confirm that you sent the message first.');
            mark_viber_sent($id,$owner,value('message_signature')); flash('Manual Viber confirmation recorded.');
        } elseif(value('action')==='order') {
            manage_order($id,$owner,value('status'),value('payment_status'),value('reference'));
            flash('Order and payment record updated. Customer email notification was queued when relevant.');
        } elseif(value('action')==='refund_online') {
            refund_online_payment($id,$owner);
            flash('Online refund completed and the customer was notified.');
        } else throw new DomainException('Unknown action.');
        redirect('admin/order.php?id='.$id);
    } catch(DomainException $ex) { $error=$ex->getMessage(); }
}
$o=one('SELECT o.*,o.customer_email email,p.method,p.status payment_status,p.reference,p.provider,p.payer_number,p.customer_reference,p.submitted_at FROM orders o JOIN payments p ON p.order_id=o.id WHERE o.id=?',[$id]);
if(!$o){http_response_code(404);exit('Order not found.');}
$allowed=['Pending'=>['Pending','Approved','Cancelled'],'Approved'=>['Approved','Completed','Cancelled'],'Completed'=>['Completed'],'Cancelled'=>['Cancelled']];
page_header('Manage order #'.$id,true);
?>
<a class="text-link" href="orders.php">← All orders</a>
<h1>Order <?= e($o['public_reference']) ?>
</h1>
<?php error_box($error); ?>
<div class="account-grid">
<section class="form-card">
<h2>Customer & items</h2>
<p>
<?= e($o['customer_name']) ?>
<br>
<?= e($o['email']) ?>
<br>
<?= e($o['customer_phone']) ?>
</p>
<p>Preferred collection: <?= e($o['collection_date']) ?> <?= e(substr($o['requested_time'] ?? '',0,5)) ?> (Fiji time)
</p>
<p>
<?= nl2br(e($o['notes'])) ?>
</p>
<?php foreach(query('SELECT * FROM order_items WHERE order_id=?',[$id])->fetchAll() as $item): ?>
<div class="summary-row">
<span>
<?= $item['quantity'] ?> × <?= e($item['product_name']) ?>
</span>
<strong>
<?= money($item['quantity']*$item['unit_price_cents']) ?>
</strong>
</div>
<?php endforeach ?>
<p class="total">Total: <?= money($o['total_cents']) ?>
</p>
</section>
<section class="form-card">
<h2>Approve order & record payment</h2>
<?php if($o['method']==='M-PAiSA'): ?><p>Payer number supplied by customer: <strong><?= e($o['payer_number'] ?: 'Not supplied') ?></strong></p><?php endif ?>
<?php if($o['submitted_at']): ?><div class="notice">Customer-submitted transaction reference: <strong><?= e($o['customer_reference']) ?></strong><br>Submitted <?= e($o['submitted_at']) ?> (Fiji time). Check this against your actual received transactions; this is not verified evidence of payment.</div><?php endif ?>
<p>Method: <?= e($o['method']) ?>
</p>
<form method="post">
<?= csrf() ?><input type="hidden" name="action" value="order">
<label>Order status<select name="status">
<?php foreach($allowed[$o['status']] as $s): ?>
<option <?= $o['status']===$s?'selected':'' ?>>
<?= $s ?>
</option>
<?php endforeach ?>
</select>
</label>
<label>Payment status<select name="payment_status" <?= $o['method']==='Online payment'?'disabled':'' ?>>
<?php foreach(($o['method']==='Online payment'?[$o['payment_status']]:['Unpaid','Paid','Refunded']) as $s): ?>
<option <?= $o['payment_status']===$s?'selected':'' ?>><?= e($s) ?></option>
<?php endforeach ?>
</select></label>
<?php if($o['method']==='Online payment'): ?><input type="hidden" name="payment_status" value="<?= e($o['payment_status']) ?>"><p class="muted">Online payment status is provider-controlled and cannot be manually changed here.</p><?php endif ?>
<label>Payment reference / note<input name="reference" maxlength="120" value="<?= e($o['reference']) ?>" placeholder="Example: cash received at collection" <?= $o['method']==='Online payment'?'readonly':'' ?>>
</label>
<p class="notice">Match the payment reference above, exact amount and recipient against your own transaction records. For M-PAiSA, enter the verified transaction ID in the note. Select Paid and Approved only after checking the funds. Cash orders may be Approved before payment. Manual payment methods must be verified by the owner. Online payments are updated only after provider confirmation. Completed orders must be Paid. Cancelling restores stock once and cannot be reversed. Manual-method refunds are arranged externally; provider-paid online orders show a provider refund button after cancellation.</p>
<button class="button">Save order update</button>
</form>
<?php if($o['method']==='Online payment' && $o['status']==='Cancelled' && $o['payment_status']==='Paid'): ?>
<form method="post" class="spaced"><?= csrf() ?><input type="hidden" name="action" value="refund_online"><p class="notice">This cancelled order has a provider-confirmed online payment. The button below requests a full refund from the original provider.</p><button class="button danger" type="submit">Refund online payment</button></form>
<?php endif ?>
</section>
</div>
<div class="account-grid spaced">
<section class="form-card">
<h2>Confirm collection</h2>
<p>Requested: <?= e($o['collection_date']) ?> <?= e(substr($o['requested_time'] ?? '',0,5)) ?> (Fiji time).</p>
<?php if($o['confirmed_date']): ?><p>Confirmed: <?= e($o['confirmed_date']) ?> at <?= e(substr($o['confirmed_time'],0,5)) ?></p><?php endif ?>
<?php if($o['status']==='Approved'): ?>
<form method="post"><?= csrf() ?><input type="hidden" name="action" value="collection">
<label>Confirmed collection date<input name="confirmed_date" type="date" required min="<?= date('Y-m-d') ?>" max="<?= date('Y-m-d',strtotime('+1 year')) ?>" value="<?= e(value('action')==='collection'?value('confirmed_date'):($o['confirmed_date'] ?: $o['collection_date'])) ?>"></label>
<label>Confirmed collection time (Fiji time)<input name="confirmed_time" type="time" required value="<?= e(value('action')==='collection'?value('confirmed_time'):substr($o['confirmed_time'] ?? $o['requested_time'] ?? '',0,5)) ?>"></label>
<p class="muted">Saving a changed date or time clears the previous Viber-sent record so you can send a new confirmation.</p>
<button class="button">Confirm collection</button>
</form>
<?php else: ?><p>Approve the order first to set collection. Completed and cancelled orders cannot be changed.</p><?php endif ?>
</section>
<section class="form-card">
<h2>Customer confirmation</h2>
<p>Preferred contact: <strong><?= e($o['contact_preference']) ?></strong></p>
<p>Phone: <?= e($o['customer_phone']) ?><br>Viber: <?= e($o['viber_number'] ?: 'Not supplied') ?></p>
<?php if($o['status']==='Approved' && $o['confirmed_date']): ?>
<label>Confirmation message<textarea readonly rows="9" class="confirmation-message"><?= e(collection_message($o)) ?></textarea></label>
<?php if($o['contact_preference']==='Viber' && $o['viber_number']): ?>
<p>Select and copy the message, then send it to the Viber number above. The website does not send messages automatically.</p>
<?php if($o['viber_sent_at']): ?><p>Recorded as sent: <?= e($o['viber_sent_at']) ?> (Fiji time). Delivery has not been verified.</p>
<?php else: ?><form method="post"><?= csrf() ?><input type="hidden" name="action" value="viber_sent"><input type="hidden" name="message_signature" value="<?= e(collection_signature($o)) ?>"><label class="check-label"><input type="checkbox" name="sent_confirmed" value="1" required> I sent the current confirmation to this customer on Viber.</label><button class="button">Mark Viber confirmation sent</button></form><?php endif ?>
<?php else: ?><p>Contact this customer by phone with these details.</p><?php endif ?>
<?php else: ?><p>Approve the order and confirm collection to prepare the message.</p><?php endif ?>
</section>
</div>
<h2>Audit timeline</h2>
<ol class="timeline">
<?php foreach(query('SELECT * FROM order_events WHERE order_id=? ORDER BY id',[$id])->fetchAll() as $event): ?>
<li>
<?= e($event['message']) ?>
<small class="block">
<?= e($event['created_at']) ?>
</small>
</li>
<?php endforeach ?>
</ol>
<?php page_footer(); ?>