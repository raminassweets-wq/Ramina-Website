<?php
require __DIR__.'/../app/bootstrap.php'; require_user(true); $error=null;
if (post()) { check_csrf(); try {
    $id=integer(value('id'),1,2147483647,'Product');
    if (value('action')==='visibility') {
        // Publication needs real available stock; route an empty draft to its stock form.
        $product=one('SELECT active,stock FROM products WHERE id=? AND deleted_at IS NULL',[$id]);
        if (!$product) throw new DomainException('Product not found.');
        if (!$product['active'] && !$product['stock']) {
            flash('Set the available quantity before publishing this product.');
            redirect('admin/product-stock.php?id='.$id);
        }
        query('UPDATE products SET active=IF(active=1,0,1) WHERE id=? AND deleted_at IS NULL',[$id]);
    }
    else throw new DomainException('Unknown action.');
    flash('Product visibility updated.'); redirect('admin/products.php');
} catch(DomainException $ex) { $error=$ex->getMessage(); } }
$q=value('q',$_GET); $filter=value('filter',$_GET);
$page=max(1,(int)(value('page',$_GET) ?: 1)); $per=30; $offset=($page-1)*$per;
$where='p.deleted_at IS NULL'; $args=[];
if ($q!=='') { $where.=' AND p.name LIKE ?'; $args[]='%'.text_slice($q,0,100).'%'; }
if ($filter==='low') $where.=' AND p.stock<=p.low_stock_threshold';
if ($filter==='hidden') $where.=' AND p.active=0';
$total=(int)(one('SELECT COUNT(*) total FROM products p WHERE '.$where,$args)['total'] ?? 0);
$products=query('SELECT p.*,c.name category_name FROM products p JOIN categories c ON c.id=p.category_id WHERE '.$where.' ORDER BY p.id DESC LIMIT '.$per.' OFFSET '.$offset,$args)->fetchAll(); page_header('Products & stock',true);
?>
<div class="section-heading">
<h1>Products & inventory</h1>
<a class="button" href="product-edit.php">Add product</a>
</div>
<?php error_box($error); ?>
<form class="filter-form" method="get">
<label>Search<input name="q" value="<?= e($q) ?>" maxlength="100">
</label>
<label>Show<select name="filter">
<option value="">All products</option>
<option value="low" <?= $filter==='low'?'selected':'' ?>>Low stock</option>
<option value="hidden" <?= $filter==='hidden'?'selected':'' ?>>Hidden</option>
</select>
</label>
<button class="button">Apply</button>
</form>
<div class="table-wrap">
<table>
<thead>
<tr>
<th>Product</th>
<th>Price</th>
<th>Stock</th>
<th>Visibility</th>
<th>Actions</th>
</tr>
</thead>
<tbody>
<?php foreach($products as $p): ?>
<tr>
<td>
<?= e($p['name']) ?>
<small class="block">
<?= e($p['category_name']) ?>
</small>
</td>
<td>
<?= money($p['price_cents']) ?>
</td>
<td>
<?= $p['stock'] ?>
<?= $p['stock']<=$p['low_stock_threshold']?' · Low':'' ?>
<?php if(!$p['stock']): ?><small class="block">Customers cannot order until stock is added.</small><?php endif ?>
</td>
<td>
<?= $p['active']?'Published':'Hidden' ?>
</td>
<td>
<div class="table-actions">
<a class="text-link" href="product-edit.php?id=<?= $p['id'] ?>">Edit</a>
<a class="text-link" href="product-stock.php?id=<?= $p['id'] ?>">Stock & details</a>
<?php if(!$p['active'] && !$p['stock']): ?><a class="text-link" href="product-stock.php?id=<?= $p['id'] ?>">Set stock & publish</a><?php else: ?>
<form method="post" class="inline-form">
<?= csrf() ?>
<input type="hidden" name="id" value="<?= $p['id'] ?>">
<input type="hidden" name="action" value="visibility">
<button class="secondary-button">
<?= $p['active']?'Hide':'Publish' ?>
</button>
</form>
<?php endif ?>
<a class="danger-link" href="product-delete.php?id=<?= $p['id'] ?>">Delete</a>
</div>
</td>
</tr>
<?php endforeach ?>
</tbody>
</table>
</div>
<?php if (!$products): ?>
<p>No products found.</p>
<?php endif ?>
<?php if($total>$per): ?><nav class="pagination" aria-label="Product pages"><?php for($i=1,$pages=(int)ceil($total/$per);$i<=$pages;$i++): ?><a <?= $i===$page?'aria-current="page"':'' ?> href="?q=<?= urlencode($q) ?>&filter=<?= urlencode($filter) ?>&page=<?= $i ?>"><?= $i ?></a><?php endfor ?></nav><?php endif ?>
<?php page_footer(); ?>
