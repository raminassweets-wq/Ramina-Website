<?php
require __DIR__.'/../app/bootstrap.php';
if (current_user()) redirect('admin/index.php');
$error=null;
if (post()) {
    check_csrf();
    $email=strtolower(value('email'));
    $password=is_string($_POST['password'] ?? null)?$_POST['password']:'';
    $key=hash('sha256','admin|'.($_SERVER['REMOTE_ADDR'] ?? '').'|'.$email);
    $attempt=one('SELECT attempts FROM login_attempts WHERE attempt_key=? AND last_attempt > DATE_SUB(NOW(), INTERVAL 15 MINUTE)',[$key]);
    if ($attempt && $attempt['attempts']>=5) $error='Too many owner-login attempts. Wait 15 minutes before trying again.';
    else {
        $candidate=one('SELECT * FROM users WHERE email=?',[$email]);
        $hash=$candidate['password_hash'] ?? '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.';
        if (strlen($password)<=72 && password_verify($password,$hash) && $candidate && $candidate['role']==='admin' && ($candidate['account_status'] ?? 'Active')==='Active') {
            query('DELETE FROM login_attempts WHERE attempt_key=?',[$key]);
            if (password_needs_rehash($hash,PASSWORD_DEFAULT)) query('UPDATE users SET password_hash=? WHERE id=?',[password_hash($password,PASSWORD_DEFAULT),$candidate['id']]);
            session_regenerate_id(true);
            $_SESSION['user_id']=(int)$candidate['id'];
            $_SESSION['session_version']=(int)($candidate['session_version'] ?? 1);
            $_SESSION['csrf']=bin2hex(random_bytes(32));
            flash('Owner session started. Your customer session, if any, remains signed in separately.');
            redirect('admin/index.php');
        } else {
            query('INSERT INTO login_attempts (attempt_key,attempts,last_attempt) VALUES (?,1,NOW()) ON DUPLICATE KEY UPDATE attempts=IF(last_attempt < DATE_SUB(NOW(),INTERVAL 15 MINUTE),1,attempts+1),last_attempt=NOW()',[$key]);
            $error='Owner email or password is incorrect.';
        }
    }
}
page_header('Owner login');
?>
<div class="auth-layout premium-auth owner-login-layout">
<div class="auth-intro owner-login-intro">
<p class="eyebrow">RAMINA’S OWNER PORTAL</p>
<h1>Run the shop without leaving the storefront.</h1>
<p>Manage orders, stock, customers, reviews, payments, support messages, reports and system health from one protected area.</p>
<div class="trust-list"><span>✓ Separate owner session</span><span>✓ Customer login stays active</span><span>✓ Protected admin tools</span></div>
</div>
<section class="form-card auth-card">
<div class="admin-login-mark">OWNER</div>
<h2>Owner sign in</h2>
<p class="muted center-text">This uses a separate secure session from customer accounts.</p>
<?php error_box($error); ?>
<form method="post">
<?= csrf() ?>
<label for="email">Owner email</label>
<input id="email" name="email" type="email" required maxlength="190" value="<?= e(value('email')) ?>" autocomplete="username">
<label for="password">Password</label>
<input id="password" name="password" type="password" required maxlength="72" autocomplete="current-password">
<button class="button wide">Open owner dashboard</button>
</form>
<div class="auth-help-row"><a class="text-link" href="../forgot-password.php?owner=1">Forgot password?</a><a class="text-link" href="../login.php">← Customer login</a></div>
</section>
</div>
<?php page_footer(); ?>
